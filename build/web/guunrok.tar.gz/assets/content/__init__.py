# game_stage.py
