#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
플레이어 클래스: 6대 근본 스탯 시스템 적용 버전
"""

import random
from cards import Card


class Player:
    def __init__(self, name="무인"):
        self.name = name

        # --- [1. 6대 근본 스탯: 수련으로 영구 상승] ---
        self.base_geungol = 100  # 근골(根骨): 생명력의 바탕
        self.base_simbeop = 5  # 심법(心法): 내공(행동력)의 바탕
        self.base_oegong = 0  # 외공(外功): 기본 방어력의 바탕
        self.base_gyeonggong = 0  # 경공(輕功): 회피 확률의 바탕
        self.base_jajil = 0  # 자질(資質): 무공 이해도 및 위력 보너스
        self.base_haengun = 5  # 행운(幸運): 치명타 확률의 바탕

        # --- [2. 실전 수치: 매 전투/턴 시작 시 근본 스탯에 의해 결정] ---
        self.max_hp = self.base_geungol
        self.hp = self.max_hp
        self.max_energy = self.base_simbeop
        self.energy = self.max_energy
        self.defense = self.base_oegong  # 매 턴 수련한 외공 수치만큼 기본 방어

        # --- [3. 보상 및 성장 관련] ---
        self.gold = 0
        self.exp = 0
        self.realm = "삼류"
        self.collection = []
        self.last_rewards = []

        # --- [4. 카드 덱 시스템] ---
        self.deck = []  # 전체 무공 목록
        self.draw_pile = []  # 전투 중 뽑을 더미
        self.hand = []  # 손패
        self.discard_pile = []  # 사용 후 버린 더미

        # --- [5. 버프 시스템] ---
        self.food_buff = None  # {name, stat, value, duration}
        self.drink_buff = None  # {name, stat, value, duration}

    # --- [전투 효율 관련 메서드] ---

    def get_understanding_bonus(self):
        """무공 자질(이해도)에 따른 피해량 증폭 배율을 반환합니다. (1당 2% 증가)"""
        return 1 + (self.base_jajil * 0.02)

    def get_crit_chance(self):
        """행운에 따른 치명타 확률(%)을 반환합니다."""
        return self.base_haengun

    def get_evade_chance(self):
        """경공에 따른 회피 확률(%)을 반환합니다."""
        return self.base_gyeonggong

    # --- [상태 관리 메서드] ---

    def take_damage(self, amount: int):
        """적의 공격에서 최종 방어력을 차감한 뒤 체력을 깎습니다."""
        # [핵심 수정] 이제 버프가 포함된 최종 방어력을 사용합니다!
        effective_def = self.get_effective_defense()

        actual_dmg = max(1, amount - effective_def)
        self.hp -= actual_dmg
        return actual_dmg

    def add_defense(self, amount: int):
        """카드 효과 등으로 방어도를 추가합니다."""
        self.defense += amount

    def restore_energy(self, amount: int):
        """내공(행동력)을 회복합니다."""
        self.energy = min(self.max_energy, self.energy + amount)

    def is_alive(self) -> bool:
        """생존 여부 확인"""
        return self.hp > 0

    def apply_buff(self, buff_data, category):
        """음식(FOOD) 또는 술(DRINK) 버프를 적용합니다."""
        if category == "FOOD":
            self.food_buff = buff_data
        elif category == "DRINK":
            self.drink_buff = buff_data

    def get_effective_defense(self):
        """기본 외공에 음식 버프를 합산한 실시간 방어력을 반환합니다."""
        total_def = self.defense  # 기본 외공 수치

        # 음식 버프가 있고, 스탯 종류가 'def'인 경우 합산
        if self.food_buff and self.food_buff.get("stat") == "def":
            total_def += self.food_buff.get("val", 0)

        return total_def

    def get_buffed_stat(self, stat_name):
        """기본 스탯에 음식/술 버프를 합산한 최종 수치를 반환합니다."""
        base_val = getattr(self, f"base_{stat_name}", 0)
        bonus = 0

        # 음식 버프 체크 (예: stat이 'def'인 경우)
        if self.food_buff and self.food_buff.get("stat") == stat_name:
            bonus += self.food_buff.get("val", 0)

        return base_val, bonus

    def update_buffs(self):
        """전투 종료 후 버프 지속 시간을 차감합니다."""
        if self.food_buff:
            self.food_buff["duration"] -= 1
            if self.food_buff["duration"] <= 0:
                self.food_buff = None
        if self.drink_buff:
            self.drink_buff["duration"] -= 1
            if self.drink_buff["duration"] <= 0:
                self.drink_buff = None

    # --- [카드 전투 로직] ---

    def draw_card(self):
        """전투용 뽑기 더미에서 카드를 한 장 뽑습니다."""
        if len(self.draw_pile) == 0:
            if len(self.discard_pile) > 0:
                self.draw_pile = self.discard_pile.copy()
                self.discard_pile = []
                random.shuffle(self.draw_pile)
            else:
                return None

        if len(self.draw_pile) > 0:
            card = self.draw_pile.pop(0)
            if len(self.hand) < 5:
                self.hand.append(card)
                return card
            else:
                self.discard_pile.append(card)
                return None
        return None

    def discard(self, card):
        """카드를 손패에서 제거하고 버린 카드 더미로 옮깁니다."""
        if card in self.hand:
            self.hand.remove(card)
            self.discard_pile.append(card)

    def start_turn(self):
        """턴 시작 시 내공 회복 및 외공(방어) 복구"""
        self.energy = self.max_energy
        # base_defense 대신 base_oegong을 사용하여 방어력을 복구합니다.
        self.defense = self.base_oegong

        while len(self.hand) < 5 and (len(self.draw_pile) + len(self.discard_pile) > 0):
            self.draw_card()
