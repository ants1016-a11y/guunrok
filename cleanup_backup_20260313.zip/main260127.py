import pygame, sys, random, json, os, traceback
from datetime import datetime
from infra.config import *
from infra.loader import load_content
from entities.player import Player
from entities.enemy import Enemy
from core.combat.battle_manager import BattleManager
from ui.widgets import (
    draw_stat_bar,
    draw_card_advanced,
    draw_enemy_intent_box,
    draw_battle_log,
)
from content.registry import CARD_REGISTRY


class GuunrokGame:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
        pygame.display.set_caption("구운록 v2 - 대천세상")

        # [핵심 수선] 현재 전개 중인 초식 번호를 저장하는 변수를 초기화합니다.
        # -1은 현재 아무 초식도 전개하고 있지 않다는 뜻입니다.
        self.current_clash_idx = -1

        # [수정] 슬롯 시스템을 위한 필수 혈맥 추가
        self.player_slots = []  # 장전된 카드들 (최대 5장)
        self.card_rects = []  # 손패 카드들의 클릭 감지 영역
        self.clock = pygame.time.Clock()
        self.setup_font()
        load_content("content")
        self.flash_color = COLOR_WHITE
        self.player = Player("무인")

        # [핵심] 덱 인스턴스 초기화 추가
        self.player.initialize_deck(CARD_REGISTRY)

        self.temp_surf = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
        self.flash_surf = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
        self.flash_surf.fill((255, 255, 255))
        self.screen_shake = 0
        self.flash_alpha = 0

        self.battle_log = []
        self.phase = Phase.WORLD
        self.chapter, self.encounter = 1, 1
        self.ui_buttons_active = {}
        self.ui_buttons_next = {}
        self.clashes_count = 0
        self.btn_end_turn_rect = pygame.Rect(1000, 710, 140, 50)
        self.last_battle_rewards = None
        self.run_history = []
        self.death_novel = []
        os.makedirs("debug/snapshots", exist_ok=True)

    def setup_font(self):
        """[수선] 누락된 font_small을 추가하여 연출 오류를 방지합니다."""
        for f in ["applesdgothicneo", "malgungothic", "nanumgothic", "arial"]:
            try:
                self.font = pygame.font.SysFont(f, 18)
                self.font_small = pygame.font.SysFont(
                    f, 14
                )  # <--- 이 줄이 반드시 필요합니다!
                self.font_name = pygame.font.SysFont(f, 26, bold=True)
                self.font_novel = pygame.font.SysFont(f, 20, italic=True)
                if self.font.render("한글", True, (0, 0, 0)).get_width() > 0:
                    break
            except:
                continue

    def add_history(self, msg):
        """무인의 중요한 행적을 기록으로 남깁니다."""
        self.run_history.append(msg)

    def generate_death_novel(self):
        """[신설] 이번 생의 기록을 바탕으로 소설을 집필합니다."""
        intro = f"강호의 어느 이름 모를 산길, {self.player.name}이라 불리던 한 무인이 첫 발을 내디뎠다."

        # 수련 행적 분석
        training_count = sum(1 for h in self.run_history if "연무장" in h)
        if training_count > 0:
            stats_msg = f"그는 {training_count}번의 수련을 통해 {self.player.stats['근골']}의 근골과 {self.player.stats['심법']}의 심법을 얻었으나, "
        else:
            stats_msg = (
                "그는 기틀을 닦기도 전에 가혹한 강호의 풍파를 정면으로 마주했다."
            )

        # 전투 행적 요약
        battle_summary = f"출도 이후 총 {self.encounter}번의 조우를 거치며 {self.chapter}장의 경지까지 도달했으나, "

        # 최후
        outro = f"마지막 순간, {self.enemy.name}의 공세를 이기지 못하고 고요히 눈을 감았다. "
        outro += "그가 남긴 투지는 먼지처럼 흩어졌으나, 그의 이름은 강호의 전설로 기억되리라."

        return [intro, stats_msg, battle_summary, outro]

    def dump_snapshot(self, tag):
        snap = {"phase": str(self.phase), "hp": self.player.hp, "xp": self.player.xp}
        with open(f"debug/snapshots/snap_{tag}.json", "w") as f:
            json.dump(snap, f)

    def start_kangho_chuldo(self):
        """[수선] 초반 조우 시 산적 무리를 우선 등장시킵니다."""
        level = self.encounter

        # 1. 산적/녹림 세력 분기 (5회 조우까지는 산적들이 등장)
        if self.encounter <= 5:
            if self.encounter == 5:  # 5회차 보스
                self.enemy = Enemy("산적 부두목", hp=45, atk=7, level=level)
            elif self.encounter == 3:  # 3회차 정예
                self.enemy = Enemy("산적 행동대장", hp=30, atk=5, level=level)
            else:  # 일반 산적
                self.enemy = Enemy("산적", hp=20, atk=4, level=level)
        else:
            # 6회차 이후: 기존 녹림 세력 등장
            if self.encounter % 5 == 0:
                self.enemy = Enemy("녹림왕", hp=120, atk=15, level=level + 2)
            elif self.encounter % 3 == 0:
                self.enemy = Enemy("녹림 행동대장", hp=60, atk=10, level=level + 1)
            else:
                self.enemy = Enemy("산채 졸개", hp=40, atk=7, level=level)

        # 2. 비무 초기화 로직 동일
        self.battle_mgr = BattleManager(self.player, self.enemy, self)
        self.player.start_battle(CARD_REGISTRY)
        self.clashes_count = 0
        self.new_hap()

        self.phase = Phase.PLAYER_TURN
        self.battle_log = [f"⚔️ {self.enemy.name}이(가) 길을 막아섭니다!"]
        self.add_history(f"{self.enemy.name}와(과) 조우함.")

    def calculate_crit(self, card_type):
        """[수선] 치명타 확률을 합리적으로 낮추고 섬광 투명도를 하향합니다."""
        # 확률 공식 하향: $3 + \lfloor \frac{행운}{4} \rfloor - 적 레벨$
        crit_chance = 5 + (self.player.stats["행운"] * 0.8) - (self.enemy.level * 2)
        crit_chance = max(1, crit_chance)  # 최소 확률 1%

        if random.randint(1, 100) <= crit_chance:
            # 섬광 투명도 하향: 150 -> 70 (뒤쪽 전장이 비치도록 설정)
            self.flash_alpha = 50

            if card_type == "공격":
                self.screen_shake = 15
                self.flash_color = FLASH_RED
            elif card_type == "방어":
                self.flash_color = FLASH_BLUE
            else:
                self.flash_color = FLASH_GREEN
            return True
        return False

    def new_hap(self):
        """[수선] 페이즈를 PLAYER_TURN으로 돌려주고 슬롯을 비웁니다."""
        self.player.discard_pile.extend(self.player.hand)
        self.player.hand = []
        self.player.start_turn_regen()
        self.player.defense = self.player.stats["외공"] // 2
        self.player.draw_cards(5)
        self.clashes_count = 0

        # [핵심] 장전 슬롯을 비우고 페이즈를 플레이어 차례로 전환합니다.
        self.player_slots = []
        self.phase = Phase.PLAYER_TURN

        self.battle_mgr.prepare_enemy_intents()

    def upgrade_stat(self, stat_name):
        if self.player.xp >= 50:
            self.player.xp -= 50
            self.player.stats[stat_name] += 1
            # 행적 기록
            self.add_history(f"연무장에서 {stat_name}을(를) 연마함.")

    def handle_input(self, event):
        """[수선] 슬롯 클릭 시 카드를 소멸시키지 않고 다시 손패로 안전하게 돌려보냅니다."""
        if event.type == pygame.MOUSEBUTTONDOWN:
            mx, my = pygame.mouse.get_pos()

            # 1. UI 버튼 처리
            for bid in sorted(self.ui_buttons_active.keys(), reverse=True):
                btn = self.ui_buttons_active[bid]
                if btn["rect"].collidepoint(mx, my) and btn["enabled"]:
                    btn["on_click"]()
                    return

            # 2. 플레이어 차례 로직
            if self.phase == Phase.PLAYER_TURN:
                # [교정] 슬롯 클릭 시 장전 취소 및 손패 복귀
                if hasattr(self, "slot_rects"):
                    for i, rect in enumerate(self.slot_rects):
                        if rect.collidepoint(mx, my) and i < len(self.player_slots):
                            removed_card = self.player_slots.pop(i)
                            # [핵심] 기본 초식(UI 버튼 생성)이 아닌 경우에만 손패로 되돌려줍니다.
                            if removed_card.name not in [
                                "기본 공격",
                                "기본 방어",
                                "운기조식",
                            ]:
                                self.player.hand.append(removed_card)
                            return

                # 카드 클릭 시 슬롯 장전
                if hasattr(self, "card_rects"):
                    for i, rect in enumerate(self.card_rects):
                        if rect.collidepoint(mx, my):
                            self.add_card_to_slot(i)
                            return

    def start_sequential_clash(self):
        """[수선] 적의 HP가 0이 되면 즉시 전개를 중단하여 '시체의 역습'을 방지합니다."""
        self.phase = Phase.ENEMY_TURN
        self.current_clash_idx = -1

        for i in range(5):
            # [핵심] 매 초식 전개 전 적의 생사 확인
            if self.enemy.hp <= 0:
                self.battle_log.append(
                    f"✨ {self.enemy.name}이(가) 완전히 무력화되었습니다. 비무를 종료합니다."
                )
                break

            self.current_clash_idx = i
            player_card = self.player_slots[i] if i < len(self.player_slots) else None
            enemy_intent = self.enemy.intent_queue[i]

            if player_card:
                self.player.energy -= player_card.base_cost

            res_msg = self.battle_mgr.resolve_single_clash(player_card, enemy_intent)
            self.battle_log.append(f"[{i+1}초식] {res_msg}")

            self.render()
            pygame.time.delay(50)
            self.flash_alpha = 0
            self.render()
            pygame.time.delay(1000)

        # 후속 정산 로직 (주인님 코드 유지)
        self.current_clash_idx = -1
        for s_card in self.player_slots:
            if s_card.name not in ["기본 공격", "기본 방어", "운기조식"]:
                self.player.discard_pile.append(s_card)
        self.player_slots.clear()

        if self.player.hp <= 0:
            self.phase = Phase.GAMEOVER
        elif self.enemy.hp <= 0:
            # 적이 죽었을 경우 즉시 승리 정산으로
            self.process_victory()
        else:
            self.new_hap()

    def draw_mini_card(self, card, rect):
        """[신설] 슬롯에 장전된 카드를 작게 표시합니다."""
        pygame.draw.rect(self.screen, card.color, rect)  # 카드 타입 색상
        # 카드 이름 일부 표시
        name_surf = self.font_small.render(card.name[:3], True, COLOR_WHITE)
        self.screen.blit(name_surf, (rect.x + 5, rect.y + 5))

    def draw_intent_icon(self, intent, center_pos):
        """[신설] 적의 의도(공격, 방어 등)를 아이콘으로 그립니다."""
        color = (
            COLOR_RED
            if "공격" in intent
            else COLOR_BLUE if "방어" in intent else COLOR_GRAY
        )
        pygame.draw.circle(self.screen, color, center_pos, 20)
        # 의도 명칭 표시
        intent_surf = self.font_small.render(intent[:2], True, COLOR_WHITE)
        self.screen.blit(intent_surf, (center_pos[0] - 10, center_pos[1] - 10))

    def render(self):
        """[완성] 깜빡임과 렉을 제거하고 연출(흔들림, 섬광)을 완벽히 적용합니다."""
        try:
            self.ui_buttons_next = {}

            # 1. 화면 흔들림 오프셋 계산
            render_offset = [0, 0]
            if self.screen_shake > 0:
                render_offset = [
                    random.randint(-SCREEN_SHAKE_POWER, SCREEN_SHAKE_POWER),
                    random.randint(-SCREEN_SHAKE_POWER, SCREEN_SHAKE_POWER),
                ]
                self.screen_shake -= 1

            # 2. 도화지(self.temp_surf) 초기화 및 통합 그리기
            # (__init__에서 미리 생성한 temp_surf를 사용해 성능을 높였습니다)
            self.temp_surf.fill(COLOR_DARK_GRAY)
            self.draw_to_surface(self.temp_surf)

            # 3. 실제 화면(self.screen) 정비 후 도화지 부착
            self.screen.fill(COLOR_BLACK)  # 잔상 방지용 배경색
            self.screen.blit(self.temp_surf, render_offset)

            if self.flash_alpha > 0:
                self.flash_surf.fill(self.flash_color)
                self.flash_surf.set_alpha(self.flash_alpha)
                self.screen.blit(self.flash_surf, (0, 0))
                # 감쇄 속도 상향: 10 -> 25 (약 3~4프레임 만에 사라짐)
                self.flash_alpha -= 50

            # 5. UI 버튼 활성화 및 최종 출력 (단 한 번만 실행!)
            # [교정] 들여쓰기를 정렬하여 문법 오류와 노란색 경고를 해결했습니다.
            self.ui_buttons_active = self.ui_buttons_next
            pygame.display.flip()

        except Exception:
            self.dump_snapshot("render_error")
            print(traceback.format_exc())

    def render_battle_screen(self):
        """여신전생 스타일: 적의 의도(상단 5칸)와 나의 초식(하단 5칸)을 배치합니다."""
        # 1. 배경 및 캐릭터 기본 정보 (기존 UI 활용)
        self.draw_battle_base_ui()

        # 2. 적 상세 스탯 패널 (우측 상단)
        # 적의 근골, 외공 등 상세 스탯을 텍스트로 노출합니다.
        self.draw_enemy_detail_stats()

        # 3. 중앙 격돌 슬롯 (Clash Slots)
        slot_width, slot_height = 100, 120
        start_x = (SCREEN_WIDTH - (slot_width * 5 + 40)) // 2

        for i in range(5):
            x = start_x + i * (slot_width + 10)

            # (A) 적의 의도 슬롯 (Enemy Intent)
            intent = (
                self.enemy.intent_queue[i] if i < len(self.enemy.intent_queue) else None
            )
            intent_rect = pygame.Rect(x, 250, slot_width, slot_height)
            pygame.draw.rect(self.screen, COLOR_DARK_GRAY, intent_rect, 2)
            if intent:
                self.draw_intent_icon(intent, intent_rect.center)  # 아이콘 렌더링

            # (B) 플레이어 배치 슬롯 (Player Action)
            action_rect = pygame.Rect(x, 380, slot_width, slot_height)
            pygame.draw.rect(
                self.screen,
                COLOR_GOLD if i == len(self.player_slots) else COLOR_GRAY,
                action_rect,
                2,
            )

            if i < len(self.player_slots):
                card = self.player_slots[i]
                self.draw_mini_card(card, action_rect)  # 슬롯에 담긴 미니 카드

        # 4. [비무 시작] 버튼 활성화 제어
        # 5칸이 모두 차면 버튼을 금색으로 빛나게 합니다.
        is_ready = len(self.player_slots) == 5
        self.update_start_button(is_ready)

    def draw_enemy_detail_stats(self, surf):
        """[신설] 적의 상세 스탯(근골, 심법 등)을 우측 상단에 노출합니다."""
        stats_x = 850
        stats_y = 150
        stats_str = " | ".join(
            [
                f"{k}:{v}"
                for k, v in self.enemy.stats.items()
                if k in ["근골", "심법", "외공"]
            ]
        )
        surf.blit(self.font.render(stats_str, True, COLOR_GRAY), (stats_x, stats_y))

    def render_training_to(self, surf):
        """[개정] 가상 도화지에 연무장을 그립니다."""
        surf.blit(
            self.font_name.render("연무장: 기틀을 다집니다", True, COLOR_GOLD),
            (400, 50),
        )
        for i, (s, v) in enumerate(self.player.stats.items()):
            r = pygame.Rect(450, 150 + i * 60, 300, 45)
            self.ui_buttons_next[f"train_{s}"] = {
                "rect": r,
                "enabled": self.player.xp >= 50,
                "on_click": lambda name=s: self.upgrade_stat(name),
            }
            pygame.draw.rect(
                surf, COLOR_BLUE if self.player.xp >= 50 else COLOR_GRAY, r
            )
            surf.blit(
                self.font.render(f"{s}: {v}", True, COLOR_WHITE), (r.x + 20, r.y + 10)
            )

    def render_meditation_to(self, surf):
        """[수선] deck_instances를 deck으로 교정하여 AttributeError를 해결하고 명상 기능을 복구합니다."""
        surf.blit(
            self.font_name.render(
                "🧘 명상: 무공의 깨달음을 얻습니다", True, COLOR_GOLD
            ),
            (400, 50),
        )
        surf.blit(
            self.font.render(f"보유 공력(XP): {self.player.xp}", True, COLOR_WHITE),
            (500, 100),
        )

        # [수정] Player 객체에 없는 속성인 deck_instances 대신 실제 속성인 deck을 순회합니다.
        for i, card in enumerate(self.player.deck):
            cost = card.get_upgrade_cost()
            r = pygame.Rect(100, 160 + i * 80, 1000, 60)
            can_upgrade = self.player.xp >= cost and card.mastery < card.mastery_max

            def do_upgrade(c=card, price=cost):
                if self.player.xp >= price and c.upgrade():
                    self.player.xp -= price
                    self.battle_log = [
                        f"✨ 명상을 통해 {c.name}이(가) {c.mastery}성이 되었습니다."
                    ]

            self.ui_buttons_next[f"meditate_{card.name}"] = {
                "rect": r,
                "enabled": can_upgrade,
                "on_click": do_upgrade,
            }

            pygame.draw.rect(
                surf, (40, 40, 60) if can_upgrade else (20, 20, 20), r, border_radius=5
            )
            pygame.draw.rect(
                surf, COLOR_GOLD if can_upgrade else COLOR_GRAY, r, 1, border_radius=5
            )

            info = f"{card.name} ({card.mastery}성) -> 다음 단계 소모 XP: {cost}"
            if card.mastery >= card.mastery_max:
                info = f"{card.name} ({card.mastery}성) - [극의 도달]"
            surf.blit(self.font.render(info, True, COLOR_WHITE), (r.x + 20, r.y + 20))

    def render_death_scene_to(self, surf):
        """[개정] 죽음의 회한이 담긴 소설을 도화지에 그립니다."""
        surf.fill((30, 10, 10))  # 핏빛 어둠

        center_x = SCREEN_WIDTH // 2
        title = self.font_name.render(
            "무인의 마지막 기록: 죽음(死亡)", True, COLOR_WHITE
        )
        surf.blit(title, (center_x - title.get_width() // 2, 120))

        # [복구] 생성된 소설 렌더링
        for i, line in enumerate(self.death_novel):
            l_surf = self.font_novel.render(line, True, (230, 200, 200))
            surf.blit(l_surf, (center_x - l_surf.get_width() // 2, 220 + i * 45))

        # 다시 태어나기 버튼 등록
        r = pygame.Rect(center_x - 100, 580, 200, 70)
        self.ui_buttons_next["resurrection"] = {
            "rect": r,
            "enabled": True,
            "on_click": self.resurrect_player,
        }
        pygame.draw.rect(surf, (60, 20, 20), r, border_radius=10)
        pygame.draw.rect(surf, COLOR_WHITE, r, 2, border_radius=10)
        btn_txt = self.font.render("다시 태어나기", True, COLOR_WHITE)
        surf.blit(
            btn_txt,
            (
                r.centerx - btn_txt.get_width() // 2,
                r.centery - btn_txt.get_height() // 2,
            ),
        )

    def draw_to_surface(self, surf):
        """[수선] 페이즈에 따른 화면 그리기 혈맥을 다시 짚습니다."""
        if self.phase == Phase.WORLD:
            self.render_world_to(surf)
        # 정산 중(ENEMY_TURN)에도 비무 화면과 슬롯 정보가 계속 보여야 합니다.
        elif self.phase in [Phase.PLAYER_TURN, Phase.ENEMY_TURN]:
            self.render_battle_screen_to(surf)
        elif self.phase == Phase.TRAINING:
            self.render_training_to(surf)
        elif self.phase == Phase.VICTORY_PANEL:
            self.render_victory_to(surf)
        elif self.phase == Phase.GAMEOVER:
            self.render_death_scene_to(surf)
        elif self.phase == Phase.INN:
            self.render_meditation_to(surf)

        if self.phase in [Phase.TRAINING, Phase.INN]:
            r = pygame.Rect(500, 650, 200, 60)
            # 귀환 시 연승 초기화 로직은 필요에 따라 VictoryPanel에서 처리하거나 여기서 수행
            self.ui_buttons_next["back"] = {
                "rect": r,
                "enabled": True,
                "on_click": lambda: setattr(self, "phase", Phase.WORLD),
            }
            pygame.draw.rect(surf, COLOR_GRAY, r, border_radius=10)
            pygame.draw.rect(surf, COLOR_WHITE, r, 2, border_radius=10)
            txt = self.font.render("강호 귀환", True, COLOR_WHITE)
            surf.blit(
                txt,
                (r.centerx - txt.get_width() // 2, r.centery - txt.get_height() // 2),
            )

    def draw_battle_base_ui_to(self, surf):
        """[수선] 능력치를 세로로 배치하고, 스탯 기반 공격력을 실시간으로 반영합니다."""
        hdr = f"PHASE={self.phase.value}  chapter={self.chapter}  encounter={self.encounter}"
        surf.blit(self.font.render(hdr, True, COLOR_WHITE), (20, 15))

        # 1. 플레이어 정보
        surf.blit(self.font_name.render(self.player.name, True, COLOR_WHITE), (100, 70))
        draw_stat_bar(
            surf,
            100,
            115,
            280,
            22,
            self.player.hp,
            self.player.max_hp,
            COLOR_GREEN,
            "기혈",
            self.font,
        )

        # 2. 내공 정보
        energy_txt = f"기본 내공: {self.player.energy}/{self.player.max_energy}"
        surf.blit(self.font.render(energy_txt, True, COLOR_GOLD), (100, 150))

        # 3. [교정] 능력치 세로 배치 및 실시간 공격력 계산
        # 공격력 공식: $AttackPower = \lfloor 근골 \times 0.5 \rfloor + 외공$
        self.player.attack_power = (self.player.stats["근골"] // 2) + self.player.stats[
            "외공"
        ]

        atk_txt = f"현재 공격력: {self.player.attack_power}"
        def_txt = f"호신강기: {self.player.defense}"

        # 세로로 간격을 두어 출력 (185, 210)
        surf.blit(self.font.render(atk_txt, True, (255, 100, 100)), (100, 185))
        surf.blit(self.font.render(def_txt, True, (100, 150, 255)), (100, 210))

        # 4. 적 정보
        surf.blit(self.font_name.render(self.enemy.name, True, COLOR_WHITE), (850, 70))
        draw_stat_bar(
            surf,
            850,
            115,
            280,
            22,
            self.enemy.hp,
            self.enemy.max_hp,
            COLOR_RED,
            "적 기혈",
            self.font,
        )

    def render_battle_screen_to(self, surf):
        """[수선] 줄 간격(18)과 초식 간격(55)을 적용하여 2줄 서사를 하단에 정갈하게 배치합니다."""
        self.draw_battle_base_ui_to(surf)
        self.render_basic_technique_panel(surf)

        slot_w, slot_h = 100, 130
        start_x = (surf.get_width() - (slot_w * 5 + 40)) // 2
        self.slot_rects = []

        # 1. 내공 시뮬레이션 (주인님 코드 유지)
        temp_energy = self.player.energy
        for card in self.player_slots:
            temp_energy -= card.base_cost
            if "운기조식" in card.name:
                temp_energy = min(self.player.max_energy, temp_energy + 2)
        self.current_rem_energy = temp_energy

        # 2. 중앙 초식 슬롯 (적: 140, 나: 280)
        for i in range(5):
            x = start_x + i * (slot_w + 10)
            is_active = i == self.current_clash_idx
            is_finished = self.current_clash_idx != -1 and i < self.current_clash_idx
            is_next = self.current_clash_idx == -1 and i == len(self.player_slots)
            border_color = COLOR_GOLD if (is_active or is_next) else (40, 40, 40)
            border_width = 4 if is_active else (2 if is_next else 1)

            intent = (
                self.enemy.intent_queue[i]
                if i < len(self.enemy.intent_queue)
                else "???"
            )
            i_rect = pygame.Rect(x, 140, slot_w, slot_h)
            pygame.draw.rect(surf, (20, 20, 20), i_rect, border_radius=5)
            pygame.draw.rect(surf, border_color, i_rect, border_width, border_radius=5)
            self.draw_intent_icon_to(surf, intent, i_rect.center)

            p_rect = pygame.Rect(x, 280, slot_w, slot_h)
            self.slot_rects.append(p_rect)
            pygame.draw.rect(surf, (20, 20, 20), p_rect, border_radius=5)
            pygame.draw.rect(surf, border_color, p_rect, border_width, border_radius=5)
            if i < len(self.player_slots):
                self.draw_mini_card(surf, self.player_slots[i], p_rect, is_finished)

        # 3. [핵심] 2줄 소설형 로그 출력 (간격 밀착 정련)
        log_y_start = 430
        display_logs = self.battle_log[-2:]  # 최신 2합만 표시
        for i, full_msg in enumerate(display_logs):
            lines = full_msg.split("\n")
            if len(lines) >= 2:
                # 첫 줄: 수치 정보 (금색) - 초식 간 간격 i * 55
                header_surf = self.font_small.render(lines[0], True, COLOR_GOLD)
                surf.blit(header_surf, (start_x, log_y_start + i * 55))

                # 둘째 줄: 소설 서사 (연회색) - 첫 줄 바로 아래(+18)에 밀착
                narrative_surf = self.font_small.render(lines[1], True, (180, 180, 180))
                surf.blit(narrative_surf, (start_x, log_y_start + i * 55 + 18))
            else:
                # 단문 로그 (전투 시작 등) - 간격 55
                single_surf = self.font_small.render(full_msg, True, (240, 240, 240))
                surf.blit(single_surf, (start_x, log_y_start + i * 55))

        # 4. 잔여 내공 및 버튼 처리 (주인님 코드 유지)
        energy_rect = pygame.Rect(start_x + (slot_w + 10) * 5 + 10, 350, 200, 60)
        pygame.draw.rect(surf, (30, 30, 50), energy_rect, border_radius=10)
        e_color = COLOR_GOLD if self.current_rem_energy >= 0 else COLOR_RED
        e_surf = self.font.render(f"잔여 氣: {self.current_rem_energy}", True, e_color)
        surf.blit(e_surf, (energy_rect.x + 15, energy_rect.y + 18))

        if self.phase == Phase.PLAYER_TURN:
            ready = len(self.player_slots) > 0 and self.current_rem_energy >= 0
            btn_rect = pygame.Rect(1000, 710, 160, 65)
            btn_label = (
                "초식 전개"
                if ready
                else ("내공 부족" if self.current_rem_energy < 0 else "초식 대기")
            )
            self.ui_buttons_next["start_clash"] = {
                "rect": btn_rect,
                "enabled": ready,
                "on_click": self.start_sequential_clash,
            }
            pygame.draw.rect(
                surf, COLOR_GOLD if ready else COLOR_GRAY, btn_rect, border_radius=10
            )
            txt = self.font.render(btn_label, True, COLOR_WHITE)
            surf.blit(
                txt,
                (
                    btn_rect.centerx - txt.get_width() // 2,
                    btn_rect.centery - txt.get_height() // 2,
                ),
            )

        self.render_player_hand_to(surf)

    def draw_intent_icon_to(self, surf, intent, center_pos):
        """[신설] 적의 의도를 원형 아이콘으로 표시합니다."""
        color = (
            COLOR_RED
            if "공격" in intent
            else COLOR_BLUE if "방어" in intent else COLOR_GRAY
        )
        pygame.draw.circle(surf, color, center_pos, 25)
        # 의도 첫 글자 표시
        txt = self.font.render(intent[:2], True, COLOR_WHITE)
        surf.blit(
            txt,
            (
                center_pos[0] - txt.get_width() // 2,
                center_pos[1] - txt.get_height() // 2,
            ),
        )

    def draw_mini_card(self, surf, card, rect, is_finished=False):
        """[수선] 슬롯 내 초식의 시각 효과를 image_9c141a.png 스타일에 맞게 보강합니다."""
        # 1. 초식 타입별 배경색
        bg_color = (
            (160, 40, 40)
            if card.type.value == "공격"
            else (40, 100, 40) if card.type.value == "방어" else (40, 40, 150)
        )

        # 2. 카드 배경 및 세련된 테두리
        pygame.draw.rect(surf, bg_color, rect, border_radius=5)
        pygame.draw.rect(
            surf, (200, 200, 200), rect, 1, border_radius=5
        )  # 얇은 밝은 테두리

        # 3. 초식 명칭 (상단 배치)
        name_txt = self.font_small.render(card.name[:3], True, COLOR_WHITE)
        surf.blit(name_txt, (rect.x + 6, rect.y + 8))

        # 4. 위력/방어 수치 (하단 배치, image_9c141a.png 스타일)
        # 운기조식 같은 경우 0 대신 '회복' 등으로 표시 가능
        val_display = "회복" if "운기조식" in card.name else f"{card.base_value}"
        val_surf = self.font_small.render(val_display, True, (240, 240, 240))
        surf.blit(val_surf, (rect.x + 6, rect.y + rect.height - 25))

        # 5. 전개 완료 시 (is_finished) 어둡게 처리
        if is_finished:
            overlay = pygame.Surface((rect.width, rect.height), pygame.SRCALPHA)
            overlay.fill((0, 0, 0, 180))
            surf.blit(overlay, (rect.x, rect.y))

    def render_player_hand_to(self, surf):
        """[수선] 시뮬레이션된 잔여 내공(current_rem_energy)을 기준으로 카드 활성화를 판단합니다."""
        self.card_rects = []
        screen_w, screen_h = surf.get_size()
        c_w, c_h = 140, 190
        gap = 15
        y = screen_h - c_h - 40

        total_w = len(self.player.hand) * (c_w + gap) - gap
        start_x = (screen_w - total_w) // 2

        for i, card in enumerate(self.player.hand):
            rect = pygame.Rect(start_x + i * (c_w + gap), y, c_w, c_h)
            draw_card_advanced(surf, rect.x, rect.y, card, self.font)

            is_loaded = card in self.player_slots
            # [핵심] 운기조식이 반영된 잔여 내공과 비교하여 선택 가능 여부를 결정합니다.
            too_expensive = (not is_loaded) and (
                card.base_cost > self.current_rem_energy
            )

            if is_loaded or too_expensive:
                overlay = pygame.Surface((c_w, c_h), pygame.SRCALPHA)
                overlay_color = (0, 0, 0, 180) if is_loaded else (60, 0, 0, 160)
                overlay.fill(overlay_color)
                surf.blit(overlay, (rect.x, rect.y))

            self.card_rects.append(rect)

    def render_basic_technique_panel(self, surf):
        """[수선] 주인님의 레이아웃을 유지하며 클릭 시스템(ui_buttons_next)을 연결합니다."""
        # 버튼 위치 및 제원 (주인님의 설정 유지)
        start_x, start_y = 1030, 450
        btn_w, btn_h = 120, 50

        basic_names = ["기본 공격", "기본 방어", "운기조식"]
        colors = [COLOR_RED, COLOR_GREEN, COLOR_BLUE]

        for i, name in enumerate(basic_names):
            rect = pygame.Rect(start_x, start_y + i * (btn_h + 10), btn_w, btn_h)

            # 1. [핵심] 클릭 시스템에 등록 (이것이 추가되어야 클릭이 됩니다)
            # 람다(lambda)를 사용하여 클릭 시 어떤 카드를 추가할지 지정합니다.
            self.ui_buttons_next[f"basic_{i}"] = {
                "rect": rect,
                "enabled": True,
                "on_click": lambda n=name: self.add_basic_card_to_slot(n),
            }

            # 2. 버튼 그리기 (주인님의 미감 유지)
            pygame.draw.rect(surf, (30, 30, 30), rect, border_radius=5)
            pygame.draw.rect(surf, colors[i], rect, 2, border_radius=5)

            # 3. 텍스트 렌더링
            txt = self.font.render(name, True, COLOR_WHITE)
            surf.blit(
                txt,
                (
                    rect.centerx - txt.get_width() // 2,
                    rect.centery - txt.get_height() // 2,
                ),
            )

    def add_basic_card_to_slot(self, card_name):
        """[수선] 기초 초식 장전 시에도 시뮬레이션된 잔여 내공을 엄격히 체크합니다."""
        import copy
        from content.registry import CARD_REGISTRY

        if len(self.player_slots) < 5:
            template = CARD_REGISTRY.get(card_name)
            if template:
                # [핵심] 잔여 내공 시뮬레이션 값을 확인하여 음수 방지
                if template.base_cost > self.current_rem_energy:
                    print(f"⚠️ [내공 부족] {card_name}을 전개할 기력이 부족합니다.")
                    return

                self.player_slots.append(copy.deepcopy(template))
                print(f"✨ [장전] {card_name}이(가) 슬롯에 배치되었습니다.")

    def render_victory_to(self, surf):
        """[교정] 승리 후 '강호 유랑'과 '강호 귀환'의 길을 제시합니다."""
        # 1. 배경 및 타이틀
        title_surf = self.font_name.render("🎊 비무 승리! 🎊", True, COLOR_GOLD)
        surf.blit(title_surf, (SCREEN_WIDTH // 2 - title_surf.get_width() // 2, 200))

        # 2. 보상 표시
        if self.last_battle_rewards:
            r = self.last_battle_rewards
            streak_txt = f" ({r['streak']}연승 보너스 적용)" if r["streak"] > 1 else ""
            txt = f"획득: XP +{r['xp']} | 금자 +{r['gold']}{streak_txt}"
            reward_surf = self.font.render(txt, True, COLOR_WHITE)
            surf.blit(
                reward_surf, (SCREEN_WIDTH // 2 - reward_surf.get_width() // 2, 280)
            )

            if r.get("msg"):
                msg_surf = self.font.render(r["msg"], True, COLOR_GOLD)
                surf.blit(
                    msg_surf, (SCREEN_WIDTH // 2 - msg_surf.get_width() // 2, 330)
                )

        # 3. 안내 문구
        info_txt = self.font.render(
            "무인의 길은 끝이 없습니다. 정진하십시오.", True, COLOR_GRAY
        )
        surf.blit(info_txt, (SCREEN_WIDTH // 2 - info_txt.get_width() // 2, 380))

        # 4. 버튼 배치 (강호 유랑 / 강호 귀환)
        btn_y = 500
        btn_w, btn_h = 240, 60

        # '강호 유랑' 버튼
        r_yulang = pygame.Rect(SCREEN_WIDTH // 2 - btn_w - 20, btn_y, btn_w, btn_h)
        self.ui_buttons_next["yulang"] = {
            "rect": r_yulang,
            "enabled": True,
            "on_click": lambda: [
                setattr(self, "encounter", self.encounter + 1),
                self.start_kangho_chuldo(),
            ],
        }

        # '강호 귀환' 버튼 (기존 강호 대지로)
        r_back = pygame.Rect(SCREEN_WIDTH // 2 + 20, btn_y, btn_w, btn_h)

        def return_to_world():
            self.player.win_streak = 0  # 귀환 시 연승 초기화
            self.phase = Phase.WORLD

        self.ui_buttons_next["back_to_world"] = {
            "rect": r_back,
            "enabled": True,
            "on_click": return_to_world,
        }

        # 5. 버튼 그리기
        for r, txt, col in [
            (r_yulang, "강호 유랑", (34, 139, 34)),
            (r_back, "강호 귀환", COLOR_GRAY),
        ]:
            pygame.draw.rect(surf, col, r, border_radius=10)
            pygame.draw.rect(surf, COLOR_WHITE, r, 2, border_radius=10)
            btn_txt = self.font.render(txt, True, COLOR_WHITE)
            surf.blit(
                btn_txt,
                (
                    r.centerx - btn_txt.get_width() // 2,
                    r.centery - btn_txt.get_height() // 2,
                ),
            )

        def continue_yulang():
            self.encounter += 1  # 조우 횟수 증가
            self.start_kangho_chuldo()  # 즉시 다음 전투 시작

        self.ui_buttons_next["yulang"] = {
            "rect": r_yulang,
            "enabled": True,
            "on_click": continue_yulang,
        }

        # [신설] '강호 대지로' 버튼 (우측 - 기존 버튼을 이쪽으로 통합)
        r_back = pygame.Rect(SCREEN_WIDTH // 2 + 20, btn_y, btn_w, btn_h)
        self.ui_buttons_next["back_to_world"] = {
            "rect": r_back,
            "enabled": True,
            "on_click": lambda: setattr(self, "phase", Phase.WORLD),
        }

        # 5. 버튼 그리기
        # 강호 유랑 버튼 (초록색 계열)
        pygame.draw.rect(surf, (34, 139, 34), r_yulang, border_radius=10)
        pygame.draw.rect(surf, COLOR_WHITE, r_yulang, 2, border_radius=10)
        txt_yulang = self.font.render("강호 유랑", True, COLOR_WHITE)
        surf.blit(
            txt_yulang,
            (
                r_yulang.centerx - txt_yulang.get_width() // 2,
                r_yulang.centery - txt_yulang.get_height() // 2,
            ),
        )

        # 강호 대지로 버튼 (회색 계열)
        pygame.draw.rect(surf, COLOR_GRAY, r_back, border_radius=10)
        pygame.draw.rect(surf, COLOR_WHITE, r_back, 2, border_radius=10)
        txt_back = self.font.render("강호 대지로", True, COLOR_WHITE)
        surf.blit(
            txt_back,
            (
                r_back.centerx - txt_back.get_width() // 2,
                r_back.centery - txt_back.get_height() // 2,
            ),
        )

    def render_world_to(self, surf):
        """[개정] 가상 도화지에 강호 대지를 그립니다."""
        surf.blit(self.font_name.render("강호 대지", True, COLOR_WHITE), (530, 80))
        btn_configs = [
            ("강호 출도", 100, COLOR_RED, self.start_kangho_chuldo),
            ("객잔", 400, COLOR_GREEN, lambda: setattr(self, "phase", Phase.INN)),
            ("연무장", 700, COLOR_BLUE, lambda: setattr(self, "phase", Phase.TRAINING)),
        ]
        for txt, x, col, cmd in btn_configs:
            r = pygame.Rect(x, 200, 200, 100)
            self.ui_buttons_next[f"world_{txt}"] = {
                "rect": r,
                "enabled": True,
                "on_click": cmd,
            }
            pygame.draw.rect(surf, col, r, border_radius=10)
            surf.blit(self.font.render(txt, True, COLOR_WHITE), (r.x + 60, r.y + 40))

        info = f"금자: {self.player.gold} | XP: {self.player.xp} | 기혈: {self.player.hp}/{self.player.max_hp}"
        surf.blit(self.font.render(info, True, COLOR_GOLD), (100, 100))

    def render_battle_ui_to(self, surf):
        """[완성] 비무 UI를 그리고, 카드와 버튼을 클릭 가능하게 등록합니다."""
        # 1. 상단 정보 (Phase, Chapter 등)
        hdr = f"PHASE=PLAYER_TURN  chapter={self.chapter}  encounter={self.encounter}"
        surf.blit(self.font.render(hdr, True, COLOR_WHITE), (20, 15))

        # 2. 아방(플레이어) 영역
        surf.blit(self.font_name.render(self.player.name, True, COLOR_WHITE), (100, 70))
        draw_stat_bar(
            surf,
            100,
            115,
            280,
            22,
            self.player.hp,
            self.player.max_hp,
            COLOR_GREEN,
            "기혈",
            self.font,
        )

        # 5합 제한 및 내공 표시
        energy_txt = f"내공 {self.player.energy}/{self.player.max_energy} | 5합 제한: {self.clashes_count}/5"
        surf.blit(self.font.render(energy_txt, True, COLOR_GOLD), (100, 150))

        # 3. 적방 영역
        draw_enemy_intent_box(surf, 850, 40, self.enemy.intent_queue, self.font)
        surf.blit(self.font_name.render(self.enemy.name, True, COLOR_WHITE), (850, 70))
        draw_stat_bar(
            surf,
            850,
            115,
            280,
            22,
            self.enemy.hp,
            self.enemy.max_hp,
            COLOR_RED,
            "적 기혈",
            self.font,
        )

        # 4. 비무 로그
        draw_battle_log(surf, 100, 260, self.battle_log, self.font)

        # 5. [핵심] 초식 카드 렌더링 및 클릭 등록
        for i, c in enumerate(self.player.hand):
            r = pygame.Rect(70 + i * 155, 560, 140, 190)

            # 버튼 등록: 이 부분이 있어야 클릭이 됩니다!
            def use_card_func(idx=i):
                if self.clashes_count < 5:
                    card = self.player.hand[idx]
                    if self.player.energy >= card.base_cost:
                        self.player.energy -= card.base_cost
                        # BattleManager를 통해 치명타 등이 계산된 로그를 받아옵니다.
                        msg = self.battle_mgr.resolve_clash(idx)
                        self.battle_log.append(msg)
                        self.clashes_count += 1

            # 클릭 가능 명부(ui_buttons_next)에 추가
            self.ui_buttons_next[f"card_{i}"] = {
                "rect": r,
                "enabled": self.clashes_count < 5 and self.player.energy >= c.base_cost,
                "on_click": use_card_func,
            }
            # 실제 카드 그림 그리기
            draw_card_advanced(surf, r.x, r.y, c, self.font)

        # 6. [핵심] 합 종료 버튼 등록
        self.ui_buttons_next["end_turn"] = {
            "rect": self.btn_end_turn_rect,
            "enabled": True,
            "on_click": self.execute_enemy_turn,
        }
        pygame.draw.rect(
            surf, COLOR_DARK_GREEN, self.btn_end_turn_rect, border_radius=5
        )
        pygame.draw.rect(surf, COLOR_WHITE, self.btn_end_turn_rect, 1, border_radius=5)
        btn_txt = self.font.render("합 종료", True, COLOR_WHITE)
        surf.blit(
            btn_txt,
            (
                self.btn_end_turn_rect.centerx - btn_txt.get_width() // 2,
                self.btn_end_turn_rect.centery - btn_txt.get_height() // 2,
            ),
        )

    def render_death_scene(self):
        """[신설] 무인의 죽음과 일대기를 소설처럼 표현합니다."""
        # 핏빛 오버레이 (배경)
        self.screen.fill((30, 10, 10))

        center_x = SCREEN_WIDTH // 2
        # 제목 정정: 죽음(死亡)
        title_surf = self.font_name.render(
            "무인의 마지막 기록: 죽음(死亡)", True, COLOR_WHITE
        )
        self.screen.blit(title_surf, (center_x - title_surf.get_width() // 2, 120))

        # 소설 텍스트 렌더링
        for i, line in enumerate(self.death_novel):
            txt_surf = self.font_novel.render(line, True, (230, 200, 200))
            self.screen.blit(
                txt_surf, (center_x - txt_surf.get_width() // 2, 220 + i * 45)
            )

        # 윤회(부활) 버튼
        r = pygame.Rect(center_x - 100, 580, 200, 70)
        self.ui_buttons_next["resurrection"] = {
            "rect": r,
            "enabled": True,
            "on_click": self.resurrect_player,
        }
        pygame.draw.rect(self.screen, (60, 20, 20), r, border_radius=10)
        pygame.draw.rect(self.screen, COLOR_WHITE, r, 2, border_radius=10)
        self.screen.blit(
            self.font.render("다시 태어나기", True, COLOR_WHITE), (r.x + 50, r.y + 25)
        )

    def resurrect_player(self):
        """[수선] 다시 태어나도 이전의 최대 내공 성취는 잃지 않습니다."""
        old_max_energy = self.player.max_energy  # 이전 생의 내공 성취

        self.player = Player(self.player.name)
        self.player.max_energy = old_max_energy  # 내공 전계
        self.player.initialize_deck(CARD_REGISTRY)

        self.encounter = 1
        self.phase = Phase.WORLD

    def render_player_hand(self):
        """[신설] 손패를 그리고 각 카드의 좌표(rect)를 card_rects에 저장합니다."""
        self.card_rects = []  # 매 프레임 좌표를 새로 갱신합니다.

        card_width, card_height = 140, 200
        padding = 20
        # 화면 하단 중앙 정렬 계산
        total_width = len(self.player.hand) * (card_width + padding)
        start_x = (SCREEN_WIDTH - total_width) // 2
        y_pos = SCREEN_HEIGHT - card_height - 30

        for i, card in enumerate(self.player.hand):
            x = start_x + i * (card_width + padding)
            rect = pygame.Rect(x, y_pos, card_width, card_height)

            # 카드를 화면에 그립니다. (이미 슬롯에 있으면 어둡게 처리 가능)
            self.draw_single_card(card, rect)

            # 중요: 클릭 감지를 위해 좌표를 저장합니다!
            self.card_rects.append(rect)

    def add_card_to_slot(self, card_idx):
        """[수선] 카드를 슬롯에 넣을 때 손패에서 제거(pop)하여 중복 생성을 원천 봉쇄합니다."""
        if card_idx >= len(self.player.hand):
            return

        card = self.player.hand[card_idx]

        # 1. 시뮬레이션된 잔여 내공 확인 (주인님 로직 유지)
        if card.base_cost > self.current_rem_energy:
            return

        # 2. 슬롯이 꽉 찼으면 거부
        if len(self.player_slots) >= 5:
            return

        # 3. [핵심] 손패에서 카드를 실제로 꺼내어 슬롯으로 옮깁니다. (중복 방지 요혈)
        self.player.hand.pop(card_idx)
        self.player_slots.append(card)
        print(f"✨ [장전] {card.name} 초식을 슬롯에 배치했습니다.")

    def render_world(self):
        self.screen.blit(
            self.font_name.render("강호 대지", True, COLOR_WHITE), (530, 80)
        )
        btn_configs = [
            ("강호 출도", 100, COLOR_RED, self.start_kangho_chuldo),
            ("객잔", 400, COLOR_GREEN, lambda: setattr(self, "phase", Phase.INN)),
            ("연무장", 700, COLOR_BLUE, lambda: setattr(self, "phase", Phase.TRAINING)),
        ]
        for txt, x, col, cmd in btn_configs:
            r = pygame.Rect(x, 200, 200, 100)
            self.ui_buttons_next[f"world_{txt}"] = {
                "rect": r,
                "enabled": True,
                "on_click": cmd,
            }
            pygame.draw.rect(self.screen, col, r, border_radius=10)
            self.screen.blit(
                self.font.render(txt, True, COLOR_WHITE), (r.x + 60, r.y + 40)
            )

        info = f"금자: {self.player.gold} | XP: {self.player.xp} | 기혈: {self.player.hp}/{self.player.max_hp}"
        self.screen.blit(self.font.render(info, True, COLOR_GOLD), (100, 100))

    def render_battle_ui(self):
        # 플레이어 정보
        self.screen.blit(
            self.font_name.render(self.player.name, True, COLOR_WHITE), (100, 70)
        )
        draw_stat_bar(
            self.screen,
            100,
            115,
            280,
            22,
            self.player.hp,
            self.player.max_hp,
            COLOR_GREEN,
            "기혈",
            self.font,
        )
        self.screen.blit(
            self.font.render(
                f"내공 {self.player.energy}/{self.player.max_energy} | 5합 제한: {self.clashes_count}/5",
                True,
                COLOR_GOLD,
            ),
            (100, 150),
        )

        # 적 정보
        self.screen.blit(
            self.font_name.render(self.enemy.name, True, COLOR_WHITE), (850, 70)
        )
        draw_stat_bar(
            self.screen,
            850,
            115,
            280,
            22,
            self.enemy.hp,
            self.enemy.max_hp,
            COLOR_RED,
            "적 기혈",
            self.font,
        )

        draw_battle_log(self.screen, 100, 260, self.battle_log, self.font)
        for i, c in enumerate(self.player.hand):
            r = pygame.Rect(70 + i * 155, 560, 140, 190)

            def use_card(idx=i):
                if self.clashes_count < 5:
                    card = self.player.hand[idx]
                    if self.player.energy >= card.base_cost:
                        self.player.energy -= card.base_cost
                        self.battle_log.append(self.battle_mgr.resolve_clash(idx))
                        self.clashes_count += 1

            self.ui_buttons_next[f"card_{i}"] = {
                "rect": r,
                "enabled": self.clashes_count < 5,
                "on_click": use_card,
            }
            draw_card_advanced(self.screen, r.x, r.y, c, self.font)

        # 합 종료 버튼
        self.ui_buttons_next["end_turn"] = {
            "rect": self.btn_end_turn_rect,
            "enabled": True,
            "on_click": self.execute_enemy_turn,
        }
        pygame.draw.rect(
            self.screen, COLOR_DARK_GREEN, self.btn_end_turn_rect, border_radius=5
        )
        self.screen.blit(self.font.render("합 종료", True, COLOR_WHITE), (1040, 725))

    def execute_enemy_turn(self):
        msgs = self.battle_mgr.execute_enemy_turn()
        self.battle_log.extend(msgs)

        # [복구] 사망 판정 - 죽음 시 소설 생성
        if self.player.hp <= 0:
            self.player.hp = 0
            self.death_novel = self.generate_death_novel()  # 소설 집필 시작
            self.phase = Phase.GAMEOVER
            return

        if self.player.hp > 0:
            self.new_hap()

    def render_training(self):
        self.screen.blit(
            self.font_name.render(
                "연무장: XP 50을 소모하여 스탯을 올립니다", True, COLOR_GOLD
            ),
            (400, 50),
        )
        for i, (s, v) in enumerate(self.player.stats.items()):
            r = pygame.Rect(450, 150 + i * 60, 300, 45)
            self.ui_buttons_next[f"train_{s}"] = {
                "rect": r,
                "enabled": self.player.xp >= 50,
                "on_click": lambda name=s: self.upgrade_stat(name),
            }
            pygame.draw.rect(
                self.screen, COLOR_BLUE if self.player.xp >= 50 else COLOR_GRAY, r
            )
            self.screen.blit(
                self.font.render(f"{s}: {v}", True, COLOR_WHITE), (r.x + 20, r.y + 10)
            )

    def render_victory(self):
        self.screen.blit(
            self.font_name.render("🎊 비무 승리! 🎊", True, COLOR_GOLD), (500, 300)
        )
        if self.last_battle_rewards:
            r = self.last_battle_rewards
            txt = f"XP +{r['xp']} | Gold +{r['gold']}"
            self.screen.blit(self.font.render(txt, True, COLOR_WHITE), (530, 380))

    def run(self):
        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                self.handle_input(event)

            if self.phase == Phase.PLAYER_TURN and self.enemy.hp <= 0:
                self.process_victory()
            self.render()
            self.clock.tick(FPS)

    def process_victory(self):
        """[수선] deck_instances를 deck으로 교정하여 승리 정산 시 발생하는 AttributeError를 박멸합니다."""
        # 1. 기초 보상 결정
        base_xp = 20 + random.randint(0, 10)
        base_gold = 10 + random.randint(0, 5)

        # 2. 보너스 배율 계산 (LaTeX 공식 적용)
        # 레벨 차이 보너스: $1.0 + (Gap \times 0.15)$
        # 연승 보너스: $1.0 + (Streak \times 0.1)$
        level_gap = max(0, self.enemy.level - self.encounter)
        gap_bonus = 1.0 + (level_gap * 0.15)
        streak_bonus = 1.0 + min(1.0, self.player.win_streak * 0.1)

        # 3. 최종 공력 합산
        final_xp = int(base_xp * gap_bonus * streak_bonus)
        self.player.xp += final_xp
        self.player.gold += base_gold

        # 4. 보스 처치 시 깨달음 기연 (20% 확률)
        enlightenment_msg = ""
        if self.encounter % 5 == 0 and random.random() < 0.2:
            # [수정] Player 객체의 실제 속성인 self.player.deck을 참조합니다.
            if self.player.deck:
                target_card = random.choice(self.player.deck)
                if target_card.upgrade():
                    enlightenment_msg = (
                        f"✨ 기연! {target_card.name}의 깨달음을 얻었습니다!"
                    )

        # 5. 보상 결과 저장 및 연승 횟수 증가
        self.last_battle_rewards = {
            "xp": final_xp,
            "gold": base_gold,
            "streak": self.player.win_streak,
            "msg": enlightenment_msg,
        }

        # 정산 완료 후 연승 수치 증가 및 기록
        self.player.win_streak += 1
        self.add_history(f"{self.enemy.name} 격파 (현재 {self.player.win_streak}연승)")

        # [수정] 승리 정산 후 화면을 전환하기 위해 페이즈를 명시적으로 변경합니다.
        self.phase = Phase.VICTORY_PANEL


if __name__ == "__main__":
    GuunrokGame().run()
