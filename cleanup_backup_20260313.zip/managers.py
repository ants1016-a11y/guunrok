#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
게임 매니저 클래스들 (StoryManager, StoryLog, DebugLogger)
"""

import os
import sys
import json
import random
from datetime import datetime
from typing import List, Optional, Dict, Any

from settings import now_ms


# ==================== 디버깅 시스템: DebugLogger ====================
class DebugLogger:
    """파일 기반 디버그 로거 (JSON Lines 형식)"""

    def __init__(self, log_dir: str = "logs"):
        self.log_dir = log_dir
        os.makedirs(log_dir, exist_ok=True)

        # 실행마다 새 로그 파일 생성
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.log_file = os.path.join(log_dir, f"run_{timestamp}.log")
        self.log_count = 0

        # 로그 파일 초기화
        with open(self.log_file, "w", encoding="utf-8") as f:
            f.write(f"# Debug Log Started: {datetime.now().isoformat()}\n")

    def log(
        self, level: str, tag: str, msg: str, data: Optional[Dict[str, Any]] = None
    ):
        """레벨, 태그, 메시지, 데이터를 JSON Lines 형식으로 기록"""
        entry = {
            "timestamp_ms": now_ms(),
            "timestamp": datetime.now().isoformat(),
            "level": level,  # DEBUG, INFO, WARN, ERROR, CRITICAL
            "tag": tag,  # PHASE_TRANSITION, UI_CLICK, STATE_CHANGE, ERROR 등
            "message": msg,
            "data": data or {},
        }

        # JSON Lines 형식으로 저장
        try:
            with open(self.log_file, "a", encoding="utf-8") as f:
                f.write(json.dumps(entry, ensure_ascii=False) + "\n")
            self.log_count += 1
        except Exception as e:
            # 로그 저장 실패 시 stderr에 출력
            print(f"[LOGGER ERROR] {e}", file=sys.stderr)

    def get_recent_logs(self, count: int = 200) -> List[Dict[str, Any]]:
        """최근 로그 N줄 읽기"""
        try:
            with open(self.log_file, "r", encoding="utf-8") as f:
                lines = f.readlines()
                # JSON Lines 파싱
                logs = []
                for line in lines[-count:]:
                    line = line.strip()
                    if line and not line.startswith("#"):
                        try:
                            logs.append(json.loads(line))
                        except:
                            pass
                return logs
        except:
            return []


# 스토리 로그 클래스
class StoryLog:
    """스토리 텍스트를 관리하는 클래스 (프레임마다 누적 방지)"""

    def __init__(self, max_lines: int = 6):
        self.max_lines = max_lines
        self.lines = []  # (text, dedupe_key, state_enter_id) 튜플 리스트
        self.last_story_key = None
        self.current_state_enter_id = {}  # state별 enter_id 추적

    def add(
        self,
        text: str,
        dedupe_key: Optional[str] = None,
        state_enter_id: Optional[int] = None,
    ):
        """스토리 라인 추가 (중복 방지)"""
        # 같은 dedupe_key가 같은 state_enter_id에서 반복되면 추가하지 않음
        if dedupe_key and state_enter_id is not None:
            # 최근 라인들 중 같은 dedupe_key와 state_enter_id가 있으면 스킵
            for line_text, line_key, line_enter_id in self.lines:
                if line_key == dedupe_key and line_enter_id == state_enter_id:
                    return  # 중복이므로 추가하지 않음

        self.lines.append((text, dedupe_key, state_enter_id))
        self.last_story_key = dedupe_key

        # 최대 라인 수 초과 시 오래된 줄 삭제
        if len(self.lines) > self.max_lines:
            self.lines.pop(0)

    def clear(self):
        """스토리 로그 초기화"""
        self.lines = []
        self.last_story_key = None

    def render(self, surface, font, color, x: int, y: int, line_height: int = 25):
        """스토리 로그 렌더링 (draw 단계에서만 호출)"""
        for i, (text, _, _) in enumerate(self.lines):
            text_surface = font.render(text, True, color)
            surface.blit(text_surface, (x, y + i * line_height))

    def get_count(self) -> int:
        """현재 스토리 라인 수 반환"""
        return len(self.lines)


# 스토리 매니저 클래스
class StoryManager:
    """동적 텍스트 생성 시스템"""

    def __init__(self):
        # 시간/장소 리스트
        self.times_places = [
            "달빛이 흐린 산길",
            "안개가 자욱한 새벽",
            "해가 지는 저녁",
            "비가 내리는 산길",
            "바람이 거세게 부는 고개",
            "깊은 산속 오솔길",
            "돌무더기 사이",
            "나무 그늘 아래",
        ]

        # 적 외형 묘사
        self.enemy_descriptions = {
            "녹림 졸개": [
                "덩치 큰 녹림 졸개가",
                "더벅머리에 두건을 두른 도적이",
                "짐승 가죽을 걸친 녹림 졸개가",
                "거친 외모의 도적이",
            ],
            "녹림 행동대장": [
                "호피를 걸친 행동대장이",
                "위압적인 기운을 풍기는 행동대장이",
                "큰 칼을 든 행동대장이",
                "눈빛이 날카로운 행동대장이",
            ],
            "녹림왕": [
                "녹림왕이",
                "위엄 있는 녹림왕이",
                "산 전체를 압도하는 녹림왕이",
                "깊은 무공을 지닌 녹림왕이",
            ],
        }

        # 적 도발/행동
        self.enemy_actions = {
            "녹림 졸개": [
                "흉한 미소를 지으며 앞을 막아섰다.",
                "'통행세를 내놔라!' 큰 소리로 외쳤다.",
                "도끼를 휘두르며 위협했다.",
                "'가진 걸 다 내놓으면 목숨만은 살려주마!'",
                "크하하하 웃으며 길을 막았다.",
            ],
            "녹림 행동대장": [
                "'내 부하들을 건드렸군.' 차갑게 말했다.",
                "큰 칼을 뽑으며 앞으로 나섰다.",
                "'가진 걸 다 내놓으면 목숨만은 살려주마!'",
                "위압적인 기운을 뿜어내며 막아섰다.",
            ],
            "녹림왕": [
                "'이 산은 내 땅이다. 지나가려면 목숨을 내놓아라!'",
                "깊은 목소리로 말하며 앞을 막아섰다.",
                "산 전체를 진동시키는 기운을 발산했다.",
                "위엄 있는 자세로 당신을 응시했다.",
            ],
        }

        # 무공 텍스트
        self.card_descriptions = {
            "육합권": [
                "검끝이 뱀처럼 휘어지며 적의 빈틈을 파고들었다!",
                "직선으로 뻗은 검기가 공기를 갈랐다!",
                "삼재검법의 기본 자세로 적을 공격했다!",
                "검을 휘둘러 적의 방어를 뚫었다!",
            ],
            "복호장": [
                "호랑이가 울부짖는 듯한 장력이 터져나갔다!",
                "묵직한 손바닥이 적의 가슴을 강타했다!",
                "강력한 기운이 손바닥에서 폭발했다!",
                "적의 방어를 완전히 무너뜨렸다!",
            ],
            "삼재공": [
                "단전의 기를 끌어올려 몸을 보호한다.",
                "발놀림을 가볍게 하여 적의 공격을 흘려낸다.",
                "내공을 순환시켜 기력을 회복한다.",
                "심법을 운용하여 방어력을 높인다.",
            ],
            "포천삼": [
                "단전의 기를 끌어올려 몸을 보호한다.",
                "발놀림을 가볍게 하여 적의 공격을 흘려낸다.",
                "내공을 순환시켜 방어력을 높인다.",
                "기운을 몸 주변에 감싸 방어막을 만든다.",
            ],
            "유운지": [
                "적의 기운을 흐트러뜨리는 기법을 사용했다!",
                "약화의 기운이 적을 감싸 공격력을 떨어뜨렸다!",
                "적의 무공을 억제하는 기법을 발동했다!",
                "적의 기운이 흐려지는 것을 느낄 수 있다!",
            ],
        }

    def generate_encounter(self, enemy_name: str) -> str:
        """랜덤 인카운터 텍스트 생성"""
        time_place = random.choice(self.times_places)
        enemy_desc = random.choice(
            self.enemy_descriptions.get(enemy_name, [f"{enemy_name}이(가)"])
        )
        enemy_action = random.choice(
            self.enemy_actions.get(enemy_name, ["앞을 막아섰다."])
        )

        return f"{time_place}, {enemy_desc} {enemy_action}"

    def generate_card_description(self, card_name: str) -> str:
        """카드 사용 시 무공 텍스트 생성"""
        descriptions = self.card_descriptions.get(
            card_name, [f"{card_name}을(를) 사용했다."]
        )
        return random.choice(descriptions)
