import pygame

import argparse
import random
import sys
import os
import traceback
from datetime import datetime
import json


def main():
    # (옵션) seed 처리 유지해도 됨
    parser = argparse.ArgumentParser(description="Guunrok")
    parser.add_argument("--seed", type=int, default=None)
    args = parser.parse_args()

    if args.seed is not None:
        random.seed(args.seed)
        print(f"랜덤 시드 고정: {args.seed}")

    game = Game()
    game.run()


if __name__ == "__main__":
    main()
