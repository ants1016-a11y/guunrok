#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
게임 설정 및 상수 정의
"""

import pygame
import sys
import os
import time
from enum import Enum

# --- 초기화 (가장 먼저 실행) ---
pygame.init()
pygame.font.init()

# --- 화면 설정 ---
SCREEN_WIDTH = 1280
SCREEN_HEIGHT = 720
FPS = 60

# --- 색상 정의 (전역 변수) ---
COLOR_WHITE = (255, 255, 255)
COLOR_BLACK = (0, 0, 0)
COLOR_BG = (30, 30, 30)  # 배경색
COLOR_PANEL_BG = (50, 50, 50)  # 패널 배경
COLOR_TEXT = (255, 255, 255)  # 일반 텍스트
COLOR_TEXT_HIGHLIGHT = (255, 255, 200)  # 강조
COLOR_DISABLED = (100, 100, 100)  # 비활성
COLOR_RED = (255, 80, 80)  # 위험/공격
COLOR_GREEN = (80, 255, 80)  # 회복/방어
COLOR_BLUE = (80, 80, 255)
COLOR_GOLD = (255, 215, 0)  # 골드/객잔

# 추가 색상 (기존 호환성 유지)
COLOR_DARK_GRAY = (40, 40, 40)  # 묵색
COLOR_DARK_RED = (120, 0, 0)
COLOR_DARK_GREEN = (0, 100, 0)
COLOR_BROWN = (139, 69, 19)
COLOR_GRAY = (128, 128, 128)  # 회색 (덜 중요한 정보용)

# --- 폰트 정의 (안전 장치 포함) ---
font_name = "malgungothic"
if sys.platform == "darwin":  # 맥OS
    font_name = "AppleGothic"

try:
    FONT_TITLE = pygame.font.SysFont(font_name, 48, bold=True)
    FONT_NORMAL = pygame.font.SysFont(font_name, 24)
    FONT_DESC = pygame.font.SysFont(font_name, 20)
    FONT_SMALL = pygame.font.SysFont(font_name, 18)
except:
    FONT_TITLE = pygame.font.Font(None, 48)
    FONT_NORMAL = pygame.font.Font(None, 24)
    FONT_DESC = pygame.font.Font(None, 20)
    FONT_SMALL = pygame.font.Font(None, 18)

# --- 게임 상태 상수 ---
PHASE_START = "START"
PHASE_PLAYER_TURN = "PLAYER_TURN"
PHASE_ENEMY_TURN = "ENEMY_TURN"
PHASE_VICTORY_PANEL = "VICTORY_PANEL"
PHASE_GAME_OVER = "GAME_OVER"
PHASE_EVENT = "EVENT"
PHASE_INN = "INN"  # 객잔 상수 확인

# 게임 규칙 상수
HAND_LIMIT = 5  # 플레이어 손패 최대 장수

# 시간 유틸리티 함수
_pygame_initialized = True


def now_ms() -> int:
    """현재 시간을 밀리초로 반환합니다."""
    global _pygame_initialized
    if _pygame_initialized:
        return pygame.time.get_ticks()
    else:
        return int(time.time() * 1000)


# 폰트 설정 (한글 지원) - 기존 함수 유지
def get_font(size):
    """시스템 폰트를 가져옵니다. 한글 지원을 시도합니다."""
    import platform

    # macOS 폰트 경로
    if platform.system() == "Darwin":  # macOS
        # macOS 시스템 폰트 경로들 (실제 파일 경로)
        font_paths = [
            "/System/Library/Fonts/Supplemental/AppleGothic.ttf",
            "/System/Library/Fonts/AppleGothic.ttf",
            "/Library/Fonts/NanumGothic.ttc",
            "/System/Library/Fonts/Helvetica.ttc",
            "/System/Library/Fonts/Supplemental/AppleSDGothicNeo.ttc",
            "/System/Library/Fonts/Supplemental/AppleSDGothicNeoBold.ttc",
            "/System/Library/Fonts/Supplemental/AppleSDGothicNeoRegular.ttc",
        ]

        # 실제 파일 경로로 폰트 로드 시도
        for font_path in font_paths:
            if os.path.exists(font_path):
                try:
                    font = pygame.font.Font(font_path, size)
                    # 테스트: 한글 렌더링 가능한지 확인
                    test_surface = font.render("테스트", True, COLOR_WHITE)
                    if test_surface.get_width() > 0:
                        print(f"폰트 로드 성공: {font_path} (크기: {size})")
                        return font
                except Exception as e:
                    continue

        # SysFont 사용 (시스템 폰트 이름으로) - macOS에서 더 잘 작동
        font_names = [
            "AppleGothic",
            "Apple SD Gothic Neo",
            "NanumGothic",
            "Nanum Gothic",
            "Malgun Gothic",
            "Gulim",
            "Arial Unicode MS",
            "Helvetica",
        ]

        for font_name in font_names:
            try:
                font = pygame.font.SysFont(font_name, size)
                # 테스트: 한글 렌더링 가능한지 확인
                test_surface = font.render("테스트", True, COLOR_WHITE)
                if test_surface.get_width() > 0:
                    print(f"폰트 로드 성공: {font_name} (크기: {size})")
                    return font
            except Exception as e:
                continue

    # Windows/Linux 또는 폰트를 찾지 못한 경우
    font_names = [
        "malgun gothic",  # Windows
        "NanumGothic",  # Linux (설치되어 있다면)
        "AppleGothic",  # macOS fallback
    ]

    for font_name in font_names:
        try:
            font = pygame.font.SysFont(font_name, size)
            test_surface = font.render("테스트", True, COLOR_WHITE)
            if test_surface.get_width() > 0:
                print(f"폰트 로드 성공: {font_name} (크기: {size})")
                return font
        except:
            continue

    # 모든 폰트 실패 시 기본 폰트 사용 (한글 미지원)
    print(f"경고: 한글 폰트를 찾을 수 없습니다. 기본 폰트를 사용합니다. (크기: {size})")
    print("한글이 깨질 수 있습니다. 시스템에 한글 폰트가 설치되어 있는지 확인하세요.")
    return pygame.font.Font(None, size)


# 폰트 초기화 (게임 시작 전에 한 번만) - 기존 폰트들
FONT_LARGE = None
FONT_MEDIUM = None
FONT_TINY = None


def init_fonts():
    """폰트를 초기화합니다."""
    global FONT_LARGE, FONT_MEDIUM, FONT_TINY
    FONT_LARGE = get_font(32)
    FONT_MEDIUM = get_font(24)
    FONT_TINY = get_font(14)
    # FONT_SMALL, FONT_TITLE, FONT_DESC는 이미 위에서 정의됨


# 게임 상태 Enum (State Machine)
class GameState(Enum):
    EVENT = "EVENT"  # 이벤트/선택지 화면
    BATTLE = "BATTLE"  # 전투 중 (PLAYER_TURN/ENEMY_TURN 포함)
    VICTORY_PANEL = "VICTORY_PANEL"  # 승리 결과창
    GAMEOVER = "GAMEOVER"  # 패배 결과창
    WORLD = "WORLD"  # 월드 화면 (수련 등)


# BATTLE 내부 상태
# 하위 호환성을 위한 상수
PHASE_VICTORY_PANEL = GameState.VICTORY_PANEL.value
PHASE_DEFEAT_PANEL = GameState.GAMEOVER.value
PHASE_CAMP = "CAMP"  # 전투 후 캠프 화면 (산길을 걷는다)
PHASE_TRAINING = "TRAINING"  # 수련 메뉴 화면
PHASE_DECK = "DECK"  # 덱 빌더 화면
PHASE_WORLD = GameState.WORLD.value  # 하위 호환성 (CAMP와 동일)
PHASE_UI_CRASH = "UI_CRASH"  # UI 렌더링 오류 상태
