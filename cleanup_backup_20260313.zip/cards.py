#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
구운록 - 카드 및 무공 성취(12성) 시스템 모듈 (AttributeError 해결 버전)
"""

import random
from enum import Enum
from typing import Optional, Dict, TYPE_CHECKING

if TYPE_CHECKING:
    from player import Player
    from enemies import Enemy


class CardType(Enum):
    ATTACK = "공격"
    DEFENSE = "방어"
    SKILL = "기술"
    DEBUFF = "약화"


class Card:
    """12성 성취 체계가 적용된 무공 카드 클래스"""

    def __init__(
        self,
        name: str,
        card_type: CardType,
        base_cost: int,
        description: str,
        base_value: int,
        power=0,  # [수정] 여기에 쉼표(,)가 꼭 있어야 합니다!
        effect_func=None,
    ):
        self.name = name
        self.type = card_type
        self.power = power
        self.description = description
        self.effect_func = effect_func
        self.power = (
            power or base_value
        )  # 실제 전투에서 쓰이는 '현재' 위력 (기본값은 base_value)
        # --- [QA 잼미니의 핵심 수정: 변수명을 mastery로 통일] ---
        self.mastery = 1  # main.py에서 호출하는 이름과 일치시킴
        self.usage_count = 0  # 숙련도 추적 변수 추가
        # --------------------------------------------------

        self.base_cost = base_cost
        self.base_value = base_value

    @property
    def current_cost(self) -> int:
        """성취 단계(mastery)에 따른 내공 소모 계산"""
        cost = self.base_cost
        if self.mastery >= 4:
            cost -= 1
        if self.mastery >= 8:
            cost -= 1
        if self.mastery == 10:
            cost += 3
        elif self.mastery == 11:
            cost += 4
        elif self.mastery == 12:
            cost += 2
        return max(1, cost)

    @property
    def current_value(self) -> int:
        """성취 단계(mastery)에 따른 위력 계산"""
        val = int(self.base_value * (1.1 ** (self.mastery - 1)))
        if self.mastery == 12:
            val *= 2
        return val

    def can_use(self, player_energy: int) -> bool:
        return player_energy >= self.current_cost

    def gain_experience(self) -> bool:
        """무공 사용 시 숙련도 상승 및 성취도 업그레이드"""
        self.usage_count += 1
        if self.usage_count >= self.mastery * 3 and self.mastery < 12:
            self.mastery += 1
            self.usage_count = 0
            if self.mastery == 12:
                self.name = f"진(眞)·{self.name}"
            return True
        return False

    def use(self, player: "Player", enemy: "Enemy"):
        if not self.can_use(player.energy):
            return False, "내공 부족!"
        player.energy -= self.current_cost
        if self.effect_func:
            result = self.effect_func(player, enemy, self)
            return True, result
        return True, f"{self.name} 사용!"


# --- 카드 레지스트리 및 효과 함수들 ---

CARD_REGISTRY: Dict[str, Card] = {}


def register_card(card: Card):
    CARD_REGISTRY[card.name] = card


def get_card_by_id(card_id: str) -> Optional[Card]:
    return CARD_REGISTRY.get(card_id)


# 1. 삼재공: 내공 회복량이 숙련도에 따라 증가 (3성마다 +1)
def effect_samjae_gong(player: Player, enemy: Enemy, card: Card) -> str:
    """삼재공: 기혈을 뒤틀어 내공의 그릇(최대치)을 일시적으로 확장합니다."""
    # 1. 숙련도에 따른 확장량 계산 (3성마다 +1)
    breakthrough_val = 1 + (card.mastery // 3)

    # 2. 실전 수치(max_energy)만 증가시킵니다.
    # 근본 수치(base_simbeop)는 변하지 않으므로 안전합니다.
    player.max_energy += breakthrough_val

    # 3. 늘어난 공간만큼 현재 내공도 즉시 채워줍니다.
    player.energy += breakthrough_val

    return f"✨ 삼재공 돌파! 내공의 그릇이 커졌습니다. (최대 내공 +{breakthrough_val})"


def effect_yukhap_gwon(player, enemy, card):
    damage = card.current_value
    actual_damage = enemy.take_damage(damage)
    return f"{card.name}으로 {actual_damage} 피해를 입혔다!"


def effect_bokho_jang(player, enemy, card):
    damage = card.current_value
    actual_damage = enemy.take_damage(damage)
    return f"{card.name}의 중후한 장력이 {actual_damage} 피해를 입혔다!"


# 2. 포천삼: 시작 수치 5, 숙련도당 방어 +2씩 증가
def effect_pocheon_sam(player: Player, enemy: Enemy, card: Card) -> str:
    # (기본 5) + (성-1) * 2 => 2성일 때 7, 3성일 때 9
    def_val = card.base_value + (card.mastery - 1) * 2
    player.add_defense(def_val)
    return f"포천삼으로 방어도 {def_val}를 획득했다!"


# 3. 유운지: 적 약화 수치가 매 성마다 +1씩 증가
def effect_yuun_ji(player, enemy, card):
    # (기본 5) + (성-1) => 2성일 때 6, 3성일 때 7
    debuff_val = card.base_value + (card.mastery - 1)
    enemy.attack_debuff += debuff_val
    return f"{card.name}로 {enemy.name}의 기세를 {debuff_val}만큼 꺾었다!"


# cards.py 하단에 추가


def effect_nokrim_claw(player, enemy, card):
    """조법: 방어력을 무시하고 살점을 뜯음"""
    damage = card.current_value
    # 방어력(defense)을 무시하고 바로 HP를 깎음
    player.hp -= damage
    return f"{enemy.name}의 잔혹한 조법! 방어를 무시하고 {damage} 피해를 입혔다!"


def effect_nokrim_poison(player, enemy, card):
    """독공: 중독 및 방어력 감소"""
    damage = card.current_value // 2
    actual_damage = player.take_damage(damage)
    player.defense = max(0, player.defense - 5)  # 방어력 깎기
    return f"{enemy.name}의 독안개! {actual_damage} 피해와 함께 방어력이 감소했다!"


def effect_nokrim_chain(player, enemy, card):
    """사슬낫: 원거리 견제 및 기절(다음 턴 행동력 감소)"""
    damage = card.current_value
    actual_damage = player.take_damage(damage)
    # 기절 효과는 player.energy를 직접 깎는 식으로 구현
    player.energy = max(0, player.energy - 1)
    return (
        f"{enemy.name}의 사슬낫에 휘감겼다! {actual_damage} 피해와 함께 기운이 꺾였다!"
    )
