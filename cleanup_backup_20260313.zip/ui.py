#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
UI 렌더링 헬퍼 함수들
"""

import pygame

from settings import (
    COLOR_WHITE,
    COLOR_BLACK,
    COLOR_RED,
    COLOR_DARK_GREEN,
    COLOR_DARK_GRAY,
    COLOR_GOLD,
    COLOR_BROWN,
    FONT_SMALL,
    FONT_TINY,
)
from cards import CardType


def draw_health_bar(surface, x, y, width, height, current, maximum, color):
    """HP 바를 그립니다."""
    # 배경 (검은색)
    pygame.draw.rect(surface, COLOR_BLACK, (x, y, width, height))

    # HP 바
    if maximum > 0:
        hp_ratio = current / maximum
        hp_width = int(width * hp_ratio)
        pygame.draw.rect(surface, color, (x, y, hp_width, height))

    # 테두리
    pygame.draw.rect(surface, COLOR_WHITE, (x, y, width, height), 2)


def draw_text(surface, text, font, color, x, y, center=False):
    """텍스트를 그립니다."""
    if font is None:
        # 폰트가 None이면 기본 폰트 사용
        font = pygame.font.Font(None, 20)

    try:
        # UTF-8 인코딩으로 텍스트 렌더링 시도
        text_str = str(text)
        text_surface = font.render(text_str, True, color)

        if center:
            text_rect = text_surface.get_rect(center=(x, y))
            surface.blit(text_surface, text_rect)
        else:
            surface.blit(text_surface, (x, y))
    except Exception as e:
        # 한글 렌더링 실패 시 영문으로 대체 시도
        try:
            # ASCII만 남기기
            ascii_text = "".join(c for c in str(text) if ord(c) < 128)
            if ascii_text:
                text_surface = font.render(ascii_text, True, color)
                if center:
                    text_rect = text_surface.get_rect(center=(x, y))
                    surface.blit(text_surface, text_rect)
                else:
                    surface.blit(text_surface, (x, y))
        except:
            # 모든 렌더링 실패 시 아무것도 그리지 않음
            pass


def draw_card(surface, card, x, y, width, height, selected=False, player_energy=0):
    """카드를 그립니다."""
    # 카드 배경색 (타입에 따라)
    if selected:
        card_color = COLOR_GOLD
    elif card.type == CardType.ATTACK:
        card_color = COLOR_RED
    elif card.type == CardType.DEFENSE:
        card_color = COLOR_DARK_GREEN
    elif card.type == CardType.SKILL:
        card_color = COLOR_BROWN
    else:  # DEBUFF
        card_color = COLOR_DARK_GRAY

    # 카드 배경
    pygame.draw.rect(surface, card_color, (x, y, width, height))
    pygame.draw.rect(surface, COLOR_WHITE, (x, y, width, height), 2)

    # 카드 이름
    draw_text(surface, card.name, FONT_SMALL, COLOR_WHITE, x + 5, y + 5)

    # 카드 설명 (간단히 표시)
    # 설명을 여러 줄로 나누어 표시
    desc_lines = []
    desc_text = card.description
    # 긴 설명은 자르기
    if len(desc_text) > 15:
        # 15자씩 나누기
        for i in range(0, len(desc_text), 15):
            desc_lines.append(desc_text[i : i + 15])
    else:
        desc_lines.append(desc_text)

    # 설명 표시 (최대 2줄)
    desc_y = y + 30
    for i, line in enumerate(desc_lines[:2]):
        if desc_y + i * 15 < y + height - 25:
            draw_text(
                surface, line, FONT_TINY, COLOR_WHITE, x + 5, desc_y + i * 15
            )

    # 카드 비용
    cost_text = f"비용: {card.energy_cost}"
    draw_text(
        surface, cost_text, FONT_TINY, COLOR_WHITE, x + 5, y + height - 20
    )

    # 사용 가능 여부 표시
    if not card.can_use(player_energy):
        # 반투명 오버레이
        overlay = pygame.Surface((width, height))
        overlay.set_alpha(128)
        overlay.fill(COLOR_BLACK)
        surface.blit(overlay, (x, y))
