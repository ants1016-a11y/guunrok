# entities/card.py
from enum import Enum


class CardType(Enum):
    ATTACK = "공격"
    DEFENSE = "방어"
    SKILL = "기술"
    DEBUFF = "약화"


class Card:
    def __init__(
        self, name, card_type, base_cost, description, base_value, effect_func
    ):
        self.name = name
        self.type = card_type
        self.base_cost = base_cost
        self.description = description
        self.base_value = base_value
        self.effect_func = effect_func
        self.mastery = 1  # 1성부터 시작
        self.usage_count = 0

    def get_current_value(self):
        """숙련도에 따른 실시간 위력 계산 (평등 스탯 기준 반영)"""
        return self.base_value + (self.mastery - 1) * 2
