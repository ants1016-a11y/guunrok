#!/usr/bin/env python3
import subprocess
import sys

# 1. 수정 전 라인 확인
with open('main.py', 'r') as f:
    lines = f.readlines()

print("=" * 60)
print("1. 수정 전: nl -ba main.py | sed -n '2988,3010p'")
print("=" * 60)
for i in range(2987, min(3010, len(lines))):
    line = lines[i]
    spaces = len(line) - len(line.lstrip())
    print(f"{i+1:4d} [{spaces:2d}칸]: {line.rstrip()}")

# 2. python3 -m py_compile main.py 출력
print("\n" + "=" * 60)
print("2. python3 -m py_compile main.py 출력")
print("=" * 60)
result = subprocess.run(['python3', '-m', 'py_compile', 'main.py'], capture_output=True, text=True)
print(result.stderr, end='')
print(f"Exit code: {result.returncode}")

# 3. 통과하면 black main.py 실행
if result.returncode == 0:
    print("\n" + "=" * 60)
    print("3. black main.py 실행 로그")
    print("=" * 60)
    result_black = subprocess.run(['python3', '-m', 'black', 'main.py'], capture_output=True, text=True)
    print(result_black.stdout, end='')
    print(result_black.stderr, end='')
    print(f"black Exit code: {result_black.returncode}")
else:
    print("\n" + "=" * 60)
    print("3. black main.py 실행 스킵 (py_compile 실패)")
    print("=" * 60)
