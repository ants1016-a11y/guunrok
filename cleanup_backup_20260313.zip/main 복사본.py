#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
구운록 (Guunrok) - 무협 카드 배틀 게임 (정리본 단일 파일)

실행:
1) pip install pygame
2) python main.py

구성 요약:
- phase(화면상태) 단일 기준으로 화면/입력/전환을 통일
- UI 버튼 레지스트리(더블버퍼)로 클릭 라우팅 일원화
- 전투: PLAYER_TURN -> ENEMY_TURN -> (VICTORY_PANEL | GAMEOVER)
- 월드: 수련 / 덱 정비 / 계속 걷기(전투)
"""

import os
import sys
import json
import time
import random
import traceback
import platform
from enum import Enum
from datetime import datetime
from collections import deque
from typing import Dict, Any, Optional, Tuple, List
from cards import Card, CardType, CARD_REGISTRY, register_card, get_card_by_id
from player import Player
from enemies import Enemy, NokrimBandit

import pygame

# =========================================================
# 기본 설정
# =========================================================
SCREEN_WIDTH = 1200
SCREEN_HEIGHT = 800
FPS = 60

COLOR_BLACK = (0, 0, 0)
COLOR_WHITE = (255, 255, 255)
COLOR_DARK_GRAY = (40, 40, 40)
COLOR_RED = (180, 0, 0)
COLOR_DARK_RED = (120, 0, 0)
COLOR_GREEN = (0, 150, 0)
COLOR_DARK_GREEN = (0, 100, 0)
COLOR_GOLD = (218, 165, 32)
COLOR_BROWN = (139, 69, 19)
COLOR_GRAY = (128, 128, 128)
COLOR_BLUE = (100, 150, 255)

_pygame_initialized = False


def now_ms() -> int:
    global _pygame_initialized
    if _pygame_initialized:
        return pygame.time.get_ticks()
    return int(time.time() * 1000)


# =========================================================
# 폰트
# =========================================================
FONT_LARGE = None
FONT_MEDIUM = None
FONT_SMALL = None
FONT_TINY = None


def get_font(size: int) -> pygame.font.Font:
    # macOS 한글 폰트 경로 우선
    if platform.system() == "Darwin":
        font_paths = [
            "/System/Library/Fonts/Supplemental/AppleGothic.ttf",
            "/System/Library/Fonts/AppleGothic.ttf",
            "/System/Library/Fonts/Supplemental/AppleSDGothicNeo.ttc",
            "/Library/Fonts/NanumGothic.ttc",
        ]
        for p in font_paths:
            if os.path.exists(p):
                try:
                    f = pygame.font.Font(p, size)
                    test = f.render("테스트", True, COLOR_WHITE)
                    if test.get_width() > 0:
                        return f
                except Exception:
                    pass

        # 이름 기반 fallback
        for name in [
            "AppleGothic",
            "Apple SD Gothic Neo",
            "NanumGothic",
            "Malgun Gothic",
            "Gulim",
        ]:
            try:
                f = pygame.font.SysFont(name, size)
                test = f.render("테스트", True, COLOR_WHITE)
                if test.get_width() > 0:
                    return f
            except Exception:
                pass

    # Windows/Linux
    for name in ["malgun gothic", "NanumGothic", "AppleGothic"]:
        try:
            f = pygame.font.SysFont(name, size)
            test = f.render("테스트", True, COLOR_WHITE)
            if test.get_width() > 0:
                return f
        except Exception:
            pass

    return pygame.font.Font(None, size)


def init_fonts():
    global FONT_LARGE, FONT_MEDIUM, FONT_SMALL, FONT_TINY
    FONT_LARGE = get_font(32)
    FONT_MEDIUM = get_font(24)
    FONT_SMALL = get_font(18)
    FONT_TINY = get_font(14)


MOUNTAIN_INN_MENU = {
    "FOOD": [
        {
            "id": "f_dumpling",
            "name": "고기 만두",
            "cost": 15,
            "stat": "def",
            "val": 5,
            "duration": 3,
            "desc": "신체 강화: 방어력 +5 (3회)",
        },
        {
            "id": "f_meat",
            "name": "멧돼지 고기",
            "cost": 30,
            "stat": "atk",
            "val": 3,
            "duration": 2,
            "desc": "근력 강화: 위력 +3 (2회)",
        },
    ],
    "DRINK": [
        {
            "id": "d_takju",
            "name": "시골 탁주",
            "cost": 10,
            "stat": "energy",
            "val": 1,
            "duration": 1,
            "desc": "기운 보강: 내공 회복 +1 (1회)",
        },
        {
            "id": "d_dokju",
            "name": "독주",
            "cost": 25,
            "stat": "mastery",
            "val": 2.0,
            "duration": 1,
            "desc": "깨달음: 숙련도 획득 2배 (1회)",
        },
    ],
}


# =========================================================
# Phase(화면 상태) - 단일 기준
# =========================================================
class Phase(Enum):
    WORLD = "WORLD"
    TRAINING = "TRAINING"
    INN = "INN"
    DECK = "DECK"
    PLAYER_TURN = "PLAYER_TURN"
    ENEMY_TURN = "ENEMY_TURN"
    # [수정] 아래 두 개를 모두 정의해두면 에러를 방지할 수 있습니다.
    VICTORY = "VICTORY"
    VICTORY_PANEL = "VICTORY_PANEL"
    GAMEOVER = "GAMEOVER"
    ERROR = "ERROR"


# =========================================================
# 로깅 / 스냅샷
# =========================================================
class DebugLogger:
    def __init__(self, log_dir: str = "logs"):
        os.makedirs(log_dir, exist_ok=True)
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.log_file = os.path.join(log_dir, f"run_{ts}.log")
        with open(self.log_file, "w", encoding="utf-8") as f:
            f.write(f"# Debug Log Started: {datetime.now().isoformat()}\n")

    def log(
        self, level: str, tag: str, msg: str, data: Optional[Dict[str, Any]] = None
    ):
        entry = {
            "timestamp_ms": now_ms(),
            "timestamp": datetime.now().isoformat(),
            "level": level,
            "tag": tag,
            "message": msg,
            "data": data or {},
        }
        try:
            with open(self.log_file, "a", encoding="utf-8") as f:
                f.write(json.dumps(entry, ensure_ascii=False) + "\n")
        except Exception:
            print("[LOGGER ERROR]", file=sys.stderr)

    def get_recent_logs(self, count: int = 200) -> List[Dict[str, Any]]:
        try:
            with open(self.log_file, "r", encoding="utf-8") as f:
                lines = f.readlines()[-count:]
            out = []
            for ln in lines:
                ln = ln.strip()
                if ln and not ln.startswith("#"):
                    try:
                        out.append(json.loads(ln))
                    except Exception:
                        pass
            return out
        except Exception:
            return []


class StoryLog:
    """프레임 누적 방지 + 중복 방지"""

    def __init__(self, max_lines: int = 6):
        self.max_lines = max_lines
        self.lines: deque[Tuple[str, Optional[str]]] = deque(
            maxlen=max_lines
        )  # (text, key)
        self.last_key: Optional[str] = None

    def add(self, text: str, dedupe_key: Optional[str] = None):
        if dedupe_key and self.last_key == dedupe_key:
            return
        self.lines.append((text, dedupe_key))
        self.last_key = dedupe_key

    def clear(self):
        self.lines.clear()
        self.last_key = None

    def render(self, surface: pygame.Surface, x: int, y: int, line_h: int = 24):
        for i, (t, _) in enumerate(self.lines):
            surf = FONT_SMALL.render(t, True, COLOR_WHITE)
            surface.blit(surf, (x, y + i * line_h))

    def count(self) -> int:
        return len(self.lines)


# =========================================================
# 카드/전투 데이터
# =========================================================
class CardType(Enum):
    ATTACK = "공격"
    DEFENSE = "방어"
    SKILL = "기술"
    DEBUFF = "약화"


def register_card(card: Card):
    CARD_REGISTRY[card.name] = card


def get_card(card_id: str) -> Optional[Card]:
    return CARD_REGISTRY.get(card_id)


class Enemy:
    def __init__(self, name: str, max_hp: int, atk: int):
        self.name = name
        self.max_hp = max_hp
        self.hp = max_hp
        self.attack_power = atk
        self.attack_debuff = 0
        # [추가] 적의 다음 수(의도)를 미리 저장하는 변수
        self.next_intent = None
        # [새로 추가된 스탯]
        self.crit_chance = 0.05  # 기본 5% 확률
        self.crit_mult = 1.5  # 치명타 시 1.5배 데미지

    def plan_next_action(self, player):
        """플레이어의 턴이 시작될 때 적이 할 일을 미리 결정합니다."""
        action_type, value = self.get_action(player)
        self.next_intent = {"type": action_type, "value": value}

    def is_alive(self) -> bool:
        return self.hp > 0

    def take_damage(self, dmg: int) -> int:
        self.hp = max(0, self.hp - dmg)
        return dmg

    def get_action(self, player: Player) -> Tuple[str, int]:
        return "attack", self.attack_power

    def attack(self, player: Player) -> Tuple[int, str]:
        dmg = max(1, self.attack_power - self.attack_debuff)
        actual = player.take_damage(dmg)
        self.attack_debuff = max(0, self.attack_debuff - 1)

        weapon = random.choice(["도끼", "철퇴", "대도"])
        hp_ratio = player.hp / player.max_hp if player.max_hp else 0.0
        if hp_ratio > 0.7:
            msg = random.choice(
                [
                    f"{self.name}이(가) {weapon}로 공격했다. 옷자락만 스쳤다. ({actual} 데미지)",
                    f"{self.name}의 {weapon} 공격. 가볍게 막아냈다. ({actual} 데미지)",
                    f"{self.name}이(가) {weapon}를 휘둘렀다. 가소로운 공격이다. ({actual} 데미지)",
                ]
            )
        elif hp_ratio > 0.3:
            msg = random.choice(
                [
                    f"{self.name}이(가) {weapon}로 공격! ({actual} 데미지)",
                    f"{self.name}의 {weapon} 공격이 명중했다. ({actual} 데미지)",
                    f"{self.name}이(가) {weapon}를 휘둘렀다. 상처를 입었다. ({actual} 데미지)",
                ]
            )
        else:
            msg = random.choice(
                [
                    f"{self.name}이(가) {weapon}로 강타했다! 피가 시야를 가린다. ({actual} 데미지)",
                    f"{self.name}의 {weapon} 공격이 깊이 박혔다. 하지만 검을 놓지 않는다. ({actual} 데미지)",
                    f"{self.name}이(가) {weapon}로 내리쳤다. 몸이 흔들리지만 버틴다. ({actual} 데미지)",
                ]
            )
        return actual, msg


class Minion(Enemy):
    def __init__(self):
        super().__init__("녹림 졸개", 30, 5)


class Elite(Enemy):
    def __init__(self):
        super().__init__("녹림 행동대장", 60, 10)
        self.cooldown = 0

    def get_action(self, player: Player) -> Tuple[str, int]:
        if self.cooldown <= 0 and random.random() < 0.3:
            self.cooldown = 2
            return "special", self.attack_power * 2
        self.cooldown = max(0, self.cooldown - 1)
        return "attack", self.attack_power


class Boss(Enemy):
    def __init__(self):
        super().__init__("녹림왕", 120, 15)
        self.cooldown = 0

    def get_action(self, player: Player) -> Tuple[str, int]:
        if self.cooldown <= 0 and random.random() < 0.4:
            self.cooldown = 3
            return "ultimate", self.attack_power * 3
        if random.random() < 0.3:
            return "attack", self.attack_power
        return "attack", self.attack_power


# =========================================================
# 스토리 매니저(간단)
# =========================================================
class StoryManager:
    def __init__(self):
        self.times_places = [
            "달빛이 흐린 산길",
            "안개가 자욱한 새벽",
            "해가 지는 저녁",
            "비가 내리는 산길",
            "바람이 거세게 부는 고개",
            "깊은 산속 오솔길",
            "돌무더기 사이",
            "나무 그늘 아래",
        ]
        self.enemy_actions = {
            "녹림 졸개": [
                "흉한 미소를 지으며 앞을 막아섰다.",
                "'통행세를 내놔라!' 큰 소리로 외쳤다.",
                "도끼를 휘두르며 위협했다.",
            ],
            "녹림 행동대장": [
                "'내 부하들을 건드렸군.' 차갑게 말했다.",
                "큰 칼을 뽑으며 앞으로 나섰다.",
                "위압적인 기운을 뿜어내며 막아섰다.",
            ],
            "녹림왕": [
                "'이 산은 내 땅이다. 지나가려면 목숨을 내놓아라!'",
                "산 전체를 진동시키는 기운을 발산했다.",
                "위엄 있는 자세로 당신을 응시했다.",
            ],
        }
        self.card_lines = {
            "육합권": [
                "직선으로 뻗은 권세가 공기를 갈랐다!",
                "육합의 흐름이 이어지며 빈틈을 파고들었다!",
            ],
            "복호장": [
                "호랑이가 울부짖는 듯한 장력이 터져나갔다!",
                "묵직한 장력이 적의 중심을 꿰뚫었다!",
            ],
            "삼재공": [
                "단전의 기를 끌어올려 몸을 다잡는다.",
                "내공이 순환하며 숨이 고르게 가라앉는다.",
            ],
            "포천삼": [
                "기운이 몸 주변을 감싸 방어막을 만들었다.",
                "자세를 낮추며 흐름을 단단히 고정했다.",
            ],
            "유운지": [
                "기운의 흐름을 비틀어 적의 힘을 흐리게 했다!",
                "약화의 기운이 적을 감싸 공격을 꺾었다!",
            ],
        }

    def encounter(self, enemy_name: str) -> str:
        place = random.choice(self.times_places)
        act = random.choice(self.enemy_actions.get(enemy_name, ["앞을 막아섰다."]))
        return f"{place}, {enemy_name}이(가) {act}"

    def card_text(self, card_name: str) -> str:
        return random.choice(
            self.card_lines.get(card_name, [f"{card_name}을(를) 사용했다."])
        )


# =========================================================
# 카드 효과
# =========================================================
# 1. 삼재공: 내공 회복량이 숙련도에 따라 증가 (3성마다 +1)
def effect_samjae_gong(player: Player, enemy: Enemy, card: Card) -> str:
    # 1성일 때 1 회복, 4성일 때 2 회복... (주인님 요청대로 1부터 시작)
    energy_gain = 1 + (card.mastery // 3)

    if random.random() < 0.5:
        player.restore_energy(energy_gain)
        return f"삼재공으로 내공을 {energy_gain} 회복했다!"

    # 방어력도 숙련도에 따라 강화
    def_gain = 3 + card.mastery
    player.add_defense(def_gain)
    return f"삼재공으로 방어도가 {def_gain} 증가했다!"


def effect_yukhap_gwon(player: Player, enemy: Enemy, card: Card) -> str:
    dmg = random.randint(8, 12)
    enemy.take_damage(dmg)
    return f"육합권으로 {dmg} 데미지를 입혔다!"


def effect_bokho_jang(player: Player, enemy: Enemy, card: Card) -> str:
    dmg = random.randint(18, 25)
    enemy.take_damage(dmg)
    return f"복호장으로 {dmg} 데미지를 입혔다!"


# 2. 포천삼: 시작 수치를 5로 낮추고 숙련도당 +2씩 성장
def effect_pocheon_sam(player: Player, enemy: Enemy, card: Card) -> str:
    # (기본값 5) + (성 - 1) * 2
    def_val = card.base_value + (card.mastery - 1) * 2
    player.add_defense(def_val)
    return f"포천삼으로 방어도 {def_val}를 획득했다!"


# 3. 유운지: 적 약화 수치가 매 성마다 +1씩 증가
def effect_yuun_ji(player, enemy, card):
    # (기본값 5) + (성 - 1)
    debuff_val = card.base_value + (card.mastery - 1)
    enemy.attack_debuff += debuff_val
    return f"{card.name}로 {enemy.name}의 기세를 {debuff_val}만큼 꺾었다!"


def bootstrap_cards():
    """모든 무공 카드를 새로운 설계도에 맞춰 중앙 등록합니다."""
    from cards import (
        Card,
        CardType,
        register_card,
        effect_yukhap_gwon,
        effect_samjae_gong,
        effect_bokho_jang,
        effect_pocheon_sam,
        effect_yuun_ji,
    )

    # 1. 무공 데이터 정의 (이름, 타입, 비용, 설명, 위력, 효과함수)
    # 위력(base_value)만 고치면 이제 카드 UI에 자동으로 반영됩니다!
    card_list = [
        (
            "삼재공",
            CardType.SKILL,
            1,
            "최대 내공 일시 증가",
            1,
            effect_samjae_gong,
        ),  # 시작 내공 1
        ("육합권", CardType.ATTACK, 2, "기본 공격", 10, effect_yukhap_gwon),
        ("복호장", CardType.ATTACK, 4, "강력한 일격", 25, effect_bokho_jang),
        (
            "포천삼",
            CardType.DEFENSE,
            2,
            "방어 획득",
            5,
            effect_pocheon_sam,
        ),  # 시작 방어 5
        ("유운지", CardType.DEBUFF, 3, "적 약화", 5, effect_yuun_ji),
    ]

    for name, c_type, cost, desc, val, func in card_list:
        if name not in CARD_REGISTRY:
            # 2. Card 객체 생성 (주인님의 __init__ 인자 이름에 정확히 맞춤)
            # power는 지정하지 않으면 __init__에서 자동으로 base_value를 따라갑니다.
            new_card = Card(
                name=name,
                card_type=c_type,
                base_cost=cost,
                description=desc,
                base_value=val,
                effect_func=func,
            )
            register_card(new_card)


# =========================================================
# UI 버튼 레지스트리
# =========================================================
LAYER_PRIORITY = {
    "hud": 1,
    "panel": 2,
    "modal": 3,
}


# =========================================================
# Game
# =========================================================
class Game:
    def __init__(self):
        init_fonts()

        # 드래그 앤 드롭 관련 상태 변수
        self.dragging_card_idx = None
        self.drag_offset = (0, 0)
        self.mouse_pos = (0, 0)

        self.screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
        pygame.display.set_caption("구운록 (Guunrok)")
        self.clock = pygame.time.Clock()
        self.running = True

        self.logger = DebugLogger()
        self.story_mgr = StoryManager()
        self.story = StoryLog(max_lines=6)

        self.phase: Phase = Phase.WORLD
        self.prev_phase: Optional[Phase] = None
        self.phase_enter_id = 0

        self.player = Player()
        self.enemy: Optional[Enemy] = None
        self.screen_shake = 0
        self.flash_alpha = 0  # 섬광의 투명도
        self.flash_color = (255, 255, 255)  # 섬광 색상

        self.life_count = 1  # 회차 기록 (파일 저장 기능이 없다면 실행 시마다 1로 시작)
        self.total_training = 0  # 총 수련 횟수
        self.met_enemies = []  # 만난 적 목록
        self.chronicle = []  # 주요 사건 기록 (예: "무명 졸개를 물리침")

        # 진행
        self.chapter = 1
        self.encounter_index = 0  # 0~5
        self.turn = 0

        # 전투 제어
        self.selected_card_index: Optional[int] = None
        self.battle_resolved = False
        self.pending_action: Optional[Dict[str, Any]] = None
        self.transition_lock = False
        self.enemy_turn_started_ms: Optional[int] = None
        self.enemy_turn_done = False

        self.crit_msg = ""  # 화면에 표시할 문구
        self.crit_dmg_val = 0  # 표시할 대미지 숫자
        self.crit_display_timer = 0  # 메시지 유지 시간

        # 결과
        self.xp = 0
        self.gold = 0
        self.battle_summary: Optional[Dict[str, Any]] = None
        self.rewards: Optional[Dict[str, Any]] = None
        self.cards_used_in_battle: List[str] = []

        # 디버그
        self.debug_overlay = True
        self.debug_ui_bounds = False
        self.last_exception: Optional[Tuple[str, str]] = None

        # 스냅샷
        self.snapshot_dir = "debug/snapshots"
        os.makedirs(self.snapshot_dir, exist_ok=True)

        # UI 레지스트리(더블버퍼)
        self.ui_buttons_active: Dict[str, Dict[str, Any]] = {}
        self.ui_buttons_next: Dict[str, Dict[str, Any]] = {}
        self.frame_click_consumed = False

        bootstrap_cards()
        self.init_starter_deck()

        self.logger.log(
            "INFO",
            "GAME_START",
            "게임 시작",
            {
                "chapter": self.chapter,
                "encounter_index": self.encounter_index,
            },
        )

    # -----------------------------
    # 공통 유틸
    # -----------------------------
    def set_phase(self, new_phase: Phase, reason: str = ""):
        if self.phase == new_phase:
            return
        self.prev_phase = self.phase
        self.phase = new_phase
        self.phase_enter_id += 1
        self.logger.log(
            "INFO",
            "PHASE",
            f"{self.prev_phase.value}->{new_phase.value}",
            {"reason": reason, "enter_id": self.phase_enter_id},
        )

    def dump_snapshot(self, tag: str):
        ts = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
        path = os.path.join(self.snapshot_dir, f"snap_{ts}_{tag}.json")
        snap = {
            "timestamp": datetime.now().isoformat(),
            "timestamp_ms": now_ms(),
            "tag": tag,
            "phase": self.phase.value,
            "prev_phase": self.prev_phase.value if self.prev_phase else None,
            "phase_enter_id": self.phase_enter_id,
            "chapter": self.chapter,
            "encounter_index": self.encounter_index,
            "turn": self.turn,
            "player": {
                "hp": self.player.hp,
                "max_hp": self.player.max_hp,
                "defense": self.player.defense,
                "energy": self.player.energy,
                "max_energy": self.player.max_energy,
                "hand": [c.name for c in self.player.hand],
                "draw": len(self.player.draw_pile),
                "discard": len(self.player.discard_pile),
            },
            "enemy": (
                None
                if not self.enemy
                else {
                    "name": self.enemy.name,
                    "hp": self.enemy.hp,
                    "max_hp": self.enemy.max_hp,
                    "atk": self.enemy.attack_power,
                    "debuff": self.enemy.attack_debuff,
                    "type": type(self.enemy).__name__,
                }
            ),
            "xp": self.xp,
            "gold": self.gold,
            "rewards": self.rewards,
            "battle_summary": self.battle_summary,
            "ui_buttons": list(self.ui_buttons_active.keys()),
            "recent_debug_logs": self.logger.get_recent_logs(120),
        }
        try:
            with open(path, "w", encoding="utf-8") as f:
                json.dump(snap, f, ensure_ascii=False, indent=2)
            self.logger.log(
                "INFO", "SNAPSHOT", "스냅샷 저장", {"path": path, "tag": tag}
            )
        except Exception as e:
            self.logger.log("ERROR", "SNAPSHOT_FAIL", str(e), {"tag": tag})

    def draw_text(
        self, text: str, x: int, y: int, font, color=COLOR_WHITE, center=False
    ):
        try:
            surf = font.render(str(text), True, color)
        except Exception:
            surf = pygame.font.Font(None, 20).render(str(text), True, color)
        if center:
            r = surf.get_rect(center=(x, y))
            self.screen.blit(surf, r)
        else:
            self.screen.blit(surf, (x, y))

    def draw_bar(self, x, y, w, h, cur, mx, color):
        pygame.draw.rect(self.screen, COLOR_BLACK, (x, y, w, h))
        if mx > 0:
            ratio = max(0.0, min(1.0, cur / mx))
            pygame.draw.rect(self.screen, color, (x, y, int(w * ratio), h))
        pygame.draw.rect(self.screen, COLOR_WHITE, (x, y, w, h), 2)

    def register_button(
        self,
        button_id: str,
        rect: pygame.Rect,
        label: str,
        on_click,
        layer: str = "hud",
        enabled: bool = True,
        priority: int = 0,
        color=None,
    ):
        self.ui_buttons_next[button_id] = {
            "rect": rect,
            "label": label,
            "on_click": on_click,
            "layer": layer,
            "enabled": enabled,
            "priority": priority,
            "color": color,
        }

    def commit_buttons(self):
        self.ui_buttons_active = self.ui_buttons_next
        self.ui_buttons_next = {}

    def route_click(self, pos: Tuple[int, int]):
        # 프레임 1회 클릭만 처리
        if self.frame_click_consumed:
            return
        candidates = []
        for bid, info in self.ui_buttons_active.items():
            rect = info.get("rect")
            if rect and rect.collidepoint(pos):
                layer = info.get("layer", "hud")
                candidates.append(
                    (LAYER_PRIORITY.get(layer, 1), info.get("priority", 0), bid, info)
                )
        if not candidates:
            return
        candidates.sort(key=lambda x: (x[0], x[1]), reverse=True)
        _, _, bid, info = candidates[0]
        if not info.get("enabled", True):
            return
        cb = info.get("on_click")
        if cb:
            self.frame_click_consumed = True
            try:
                cb()
                self.logger.log("INFO", "UI_CLICK", bid, {"phase": self.phase.value})
            except Exception as e:
                self.handle_exception(e)

    # -----------------------------
    # 덱/전투 준비
    # -----------------------------
    def init_starter_deck(self):
        self.player.collection.clear()
        self.player.deck.clear()
        self.player.last_rewards.clear()

        starter = ["삼재공", "육합권", "복호장", "포천삼", "유운지"]
        for cid in starter:
            for _ in range(2):
                self.player.collection.append(cid)
                self.player.deck.append(cid)

        # 최대 10장 보장
        self.player.deck = self.player.deck[:10]

    def build_battle_piles(self):
        self.player.draw_pile.clear()
        self.player.hand.clear()
        self.player.discard_pile.clear()

        # 덱이 너무 적으면 자동 보강
        if len(self.player.deck) < 5:
            for cid in ["삼재공", "육합권", "포천삼"]:
                if len(self.player.deck) >= 10:
                    break
                self.player.deck.append(cid)
                self.player.collection.append(cid)

        for cid in self.player.deck:
            c = get_card(cid)
            if c:
                self.player.draw_pile.append(c)
        random.shuffle(self.player.draw_pile)

    def generate_enemy(self):
        # 0~2: 졸개, 3~4: 엘리트, 5: 보스
        idx = self.encounter_index
        if idx <= 2:
            e = Minion()
        elif idx <= 4:
            e = Elite()
        else:
            e = Boss()

        # 챕터 스케일
        if self.chapter > 1:
            m = 1.0 + (self.chapter - 1) * 0.15
            e.max_hp = int(e.max_hp * m)
            e.hp = e.max_hp
            e.attack_power = int(e.attack_power * m)
        return e

    def start_battle(self):
        """전투를 시작합니다. 적 생성과 첫 턴 의도 파악 로직을 통합했습니다."""
        # 1. 전투 상태 초기화
        self.battle_resolved = False
        self.transition_lock = False
        self.pending_action = None
        self.enemy_turn_started_ms = None
        self.enemy_turn_done = False
        self.turn = 0
        self.selected_card_index = None
        self.cards_used_in_battle.clear()
        self.battle_summary = None
        self.rewards = None
        self.cards_played_this_battle = 0  # 이번 전투 카드 사용 횟수
        self.cards_played_this_turn = 0
        self.player.energy_regen = 1

        # 2. 적 생성 및 이번 생의 만남 기록 (딱 한 번만 수행)
        self.enemy = self.generate_enemy()
        self.met_enemies.append(self.enemy.name)

        # 3. 새로운 6대 스탯 체계에 맞춰 플레이어 수치 초기화
        self.player.max_hp = self.player.base_geungol
        # 현재 체력이 최대치를 넘지 않도록 조정 (필요 시)
        self.player.hp = min(self.player.hp, self.player.max_hp)
        self.player.defense = self.player.base_oegong
        self.player.max_energy = self.player.base_simbeop
        self.player.energy = self.player.max_energy

        # 4. 덱 구축
        self.build_battle_piles()

        # 5. [중요] 플레이어 턴 시작 (이 시점에 적의 의도가 계산됩니다)
        self.start_player_turn()

        # 6. 스토리 로그 초기화 및 페이즈 전환
        self.story.clear()
        self.story.add(self.story_mgr.encounter(self.enemy.name), "encounter")
        self.set_phase(Phase.PLAYER_TURN, "start_battle")

    def advance_progression(self):
        # 보스 처치 시 챕터+1, 인카운터 리셋
        if self.encounter_index >= 5:
            self.chapter += 1
            self.encounter_index = 0
        else:
            self.encounter_index += 1

    # -----------------------------
    # 승리/패배 처리
    # -----------------------------
    def build_battle_summary(self) -> Dict[str, Any]:
        counts: Dict[str, int] = {}
        for n in self.cards_used_in_battle:
            counts[n] = counts.get(n, 0) + 1
        final_blow = (
            self.cards_used_in_battle[-1] if self.cards_used_in_battle else None
        )
        return {
            "turns": self.turn + 1,
            "card_counts": counts,
            "final_blow": final_blow,
        }

    def roll_rewards(self) -> Dict[str, Any]:
        # 등급별 보상
        if isinstance(self.enemy, Boss):
            xp = random.randint(35, 55)
            gold = random.randint(40, 70)
            chance = 0.85
        elif isinstance(self.enemy, Elite):
            xp = random.randint(20, 35)
            gold = random.randint(20, 40)
            chance = 0.60
        else:
            xp = random.randint(10, 20)
            gold = random.randint(10, 20)
            chance = 0.35

        reward = {"xp": xp, "gold": gold, "card_reward_id": None}
        if random.random() < chance:
            reward["card_reward_id"] = random.choice(list(CARD_REGISTRY.keys()))
        return reward

    def on_victory(self):
        """전투 승리 시 보상을 계산하고 결과창 UI에 데이터를 보냅니다."""
        if self.battle_resolved:
            return
        if not self.enemy or self.enemy.hp > 0:
            return

        self.battle_resolved = True
        self.enemy.hp = 0

        # 1. 보상 계산
        loot_name, gold_amt = self.process_victory_loot()
        xp_gain = 10  # 경험치 고정값

        # [추가] 전투가 끝났으니 버프 지속 시간을 1회 차감합니다.
        self.player.update_buffs()

        # [수정] Phase 클래스에 추가한 이름과 똑같이 맞춰줍니다.
        self.set_phase(Phase.VICTORY, "enemy_dead")

        # ---------------------------------------------------------
        # [잼미니의 긴급 수정 포인트]

        # [추가 및 수정] 모든 주머니에 보상을 합칩니다.
        self.player.gold += gold_amt
        self.player.exp += (
            xp_gain  # 이제 player.py에 exp가 생겼으니 hasattr 없어도 됩니다!
        )
        # [중요!] main.py 자체 변수들도 같이 업데이트 (이중 주머니 동기화)
        self.gold = self.player.gold
        self.xp = self.player.exp

        # [중요!] 전투 요약 데이터 설정 (image_afe2db.png 에러 해결!)
        # 문자열이 아니라 아래처럼 '딕셔너리' 형태로 넣어줘야 UI가 읽을 수 있습니다.
        self.battle_summary = {"turns": self.turn}

        # UI 패널용 서랍 (기존 유지)
        self.rewards = {"xp": xp_gain, "gold": gold_amt, "items": [loot_name]}
        # ---------------------------------------------------------

        # 스토리 로그 기록 (기존 유지)
        self.story.add("녹림 도적이 쓰러졌다!", "victory")
        self.story.add(f"전리품 획득: {loot_name} (Gold +{gold_amt})", "loot_info")

        # 결과창 표시 (기존 유지)
        self.set_phase(Phase.VICTORY_PANEL, "enemy_dead")

    def process_victory_loot(self):
        """
        LORE_NOKRIM 설정에 따라 녹림 도적단의 전리품을 결정합니다.
        기본 무공 카드는 절대 드랍하지 않습니다.
        """
        import random

        roll = random.random()  # 0.0 ~ 1.0 사이 난수

        loot_name = ""
        gold_gain = 0

        # 1. 대박 (0.1%): 고대 무공 비급
        if roll <= 0.001:
            loot_name = "★온전한 고대 무공 비급★"
            gold_gain = 100
        # 2. 일반 전리품
        elif roll <= 0.2:
            loot_name = "찢어진 무공서 조각"
            gold_gain = random.randint(10, 20)
        elif roll <= 0.5:
            loot_name = "짐승 가죽"
            gold_gain = random.randint(8, 15)
        else:
            loot_name = "녹슨 도끼"
            gold_gain = random.randint(5, 10)

        # [중요] 보상 이름과 골드 금액 딱 '2개'만 반환합니다.
        return loot_name, gold_gain

    def on_defeat(self):
        """플레이어 패배 시 호출: 전투를 종결시키고 게임 오버 화면으로 보냅니다."""
        if self.battle_resolved or self.player.hp > 0:
            return

        self.battle_resolved = True
        self.enemy = (
            None  # [추가] 패배 시 적 정보를 즉시 삭제하여 유령 현상을 방지합니다.
        )
        # [추가] 누구에게 죽었는지 기록 (enemy 객체가 None이 되기 전에 가져와야 합니다)
        self.death_reason = self.enemy.name if self.enemy else "이름 모를 고수"
        self.story.add("🌪️ 기력이 다했습니다. 여기서 멈추게 되었다...", "defeat")

        # Phase 이름이 GAMEOVER인지 GAME_OVER인지 확인 후 맞춰주세요.
        self.set_phase(Phase.GAMEOVER, "player_dead")

    def reset_game(self):
        """게임 리셋: 모든 진행도와 플레이어 스탯을 초기화합니다."""
        # 1. 진행도 초기화
        self.chapter = 1
        self.encounter_index = 0
        self.turn = 0

        # 2. 플레이어 초기화 (새로운 6대 스탯 체계로 생성됩니다)
        self.player = Player("무인")
        self.init_starter_deck()

        # 3. 자원 리셋 (수련 창에서 사용하는 player.exp와 연동)
        self.player.exp = 0
        self.player.gold = 0
        # 만약 self.xp/gold 변수를 따로 쓰신다면 아래도 유지:
        self.xp = 0
        self.gold = 0

        # 4. 전투 및 UI 상태 리셋
        self.enemy = None
        self.battle_resolved = False
        self.pending_action = None
        self.transition_lock = False
        self.selected_card_index = None
        self.story.clear()

        # 5. 월드로 귀환
        self.set_phase(Phase.WORLD, "reset_game_done")

    # -----------------------------
    # 카드 사용
    # -----------------------------
    def use_card_index(self, idx: int):
        """카드를 사용하고, 실제 성공 시에만 '이번 턴' 5합 제한을 적용합니다."""

        # 1. 인덱스 및 유효성 체크 (self.player.hand 사용)
        if idx is None or idx < 0 or idx >= len(self.player.hand):
            return

        # 2. 기본 상태 체크
        if self.phase != Phase.PLAYER_TURN:
            return
        if not self.enemy or not self.enemy.is_alive():
            return

        # 3. [수정] 이번 '턴'에 이미 5합을 모두 소모했는지 확인
        if self.cards_played_this_turn >= 5:
            self.story.add(
                "⚠️ 이번 턴의 기력이 소진되었습니다! (턴 종료 필요)", "exhausted"
            )
            return

        card = self.player.hand[idx]

        # 4. 카드 사용 시도 (내공 체크 포함)
        ok, msg = card.use(self.player, self.enemy)

        if ok:
            # ---------------------------------------------------------
            # [성공] 여기서만 턴당 횟수 차감 및 숙련도 처리
            # ---------------------------------------------------------
            self.cards_played_this_turn += 1  # 턴 카운트 증가

            self.cards_used_in_battle.append(card.name)  # 전투 기록
            card.gain_experience()  # 숙련도 증가

            self.story.add(f"⚔️ {card.name}: {msg}", f"res_{now_ms()}")

            # 사용한 카드 제거 및 인덱스 초기화
            self.player.discard(card)
            self.selected_card_index = None

            # 남은 횟수 연출 (턴 단위로 표시)
            remaining = 5 - self.cards_played_this_turn
            if remaining > 0:
                self.story.add(f"📜 남은 초식: {remaining}합", f"count_{now_ms()}")
            else:
                self.story.add(
                    "‼️ 마지막 초식을 펼쳤습니다! 이제 기력이 다했습니다.", "last_move"
                )

            # 승리 체크
            if self.enemy.hp <= 0:
                self.on_victory()
        else:
            # [실패] 내공 부족 등 (횟수 차감 안 됨)
            self.story.add(f"❌ {msg}", f"fail_{now_ms()}")

    # [수정 후] 턴이 교체되는 시점 (예: start_player_turn 또는 적 공격 종료 시)
    def start_player_turn(self):
        """플레이어의 새로운 합(턴)이 시작될 때 기력과 방어도를 재정비합니다."""
        # 1. 페이즈 설정 및 합(Turn) 수 증가
        self.phase = Phase.PLAYER_TURN
        self.turn += 1

        # 2. [핵심] 초식 사용 횟수 초기화 (턴당 5합 제한 리셋)
        self.cards_played_this_turn = 0

        # 3. 방어도 재정비 (기본 외공 수치로 복구)
        # base_oegong이 없을 경우를 대비해 getattr로 안전하게 참조합니다.
        self.player.defense = getattr(self.player, "base_oegong", 0)

        # 4. 적의 상태 및 의도 분석 (중복 로직 통합)
        if self.enemy:
            # 적에게 걸려있던 약화 효과를 해제하고 다음 수를 계획합니다.
            self.enemy.attack_debuff = 0
            self.enemy.plan_next_action(self.player)

        # 에너지 회복 (AttributeError 방지 처리)
        regen = getattr(self.player, "energy_regen", 1)
        self.player.energy = min(self.player.max_energy, self.player.energy + regen)

        self.player.start_turn()
        self.story.add(
            f"🌬️ 제 {self.turn}합 시작: 기력을 회복했습니다.", f"turn_{self.turn}"
        )

        # 7. 스토리 로그 기록
        self.story.add(
            f"🌬️ 제 {self.turn}합: 숨을 고르며 기력을 회복했습니다.",
            f"turn_start_{now_ms()}",
        )

    # -----------------------------
    # 턴 종료 / 적 턴
    # -----------------------------
    def request_end_turn(self):
        if self.phase != Phase.PLAYER_TURN:
            return
        if self.transition_lock:
            return
        self.pending_action = {"type": "END_TURN", "at": now_ms()}

    def end_player_turn(self):
        if self.phase != Phase.PLAYER_TURN:
            return
        if self.transition_lock:
            return

        self.transition_lock = True
        self.pending_action = None
        self.selected_card_index = None

        self.set_phase(Phase.ENEMY_TURN, "end_turn")
        self.enemy_turn_started_ms = now_ms()
        self.enemy_turn_done = False

        # 적의 공격 처리가 끝나는 함수(예: resolve_enemy_turn) 마지막에 추가
        self.story.add(f"--- 제 {self.turn}합 완료 ---", "turn_end")

    def run_enemy_turn_once(self):
        """적의 공격을 처리합니다. 데미지 중복 계산 버그를 수정했습니다."""
        if self.phase != Phase.ENEMY_TURN or self.enemy_turn_done:
            return
        if not self.enemy or not self.enemy.is_alive():
            self.on_victory()
            return

        self.enemy_turn_done = True

        # 1. 행동과 기초 위력을 가져옵니다.
        action, value = self.enemy.get_action(self.player)

        # 2. 기초 데미지 계산 (약화(Debuff) 반영)
        base_dmg = max(0, value - self.enemy.attack_debuff)

        # 3. 치명타 계산 (약화된 데미지 기준)
        is_crit = random.random() < self.enemy.crit_chance
        final_dmg = (
            int(base_dmg * self.enemy.crit_mult)
            if is_crit and base_dmg > 0
            else base_dmg
        )

        # 4. 공격 종류에 따른 연출 수치 설정 (흔들림, 번쩍임)
        if action == "ultimate":
            self.screen_shake = 40  # 필살기: 강한 흔들림
            self.flash_alpha = 200  # 화면 번쩍임
            self.flash_color = (255, 255, 255)
        elif action == "special":
            self.screen_shake = 20  # 강공격: 중간 흔들림
            self.flash_alpha = 120
            self.flash_color = (200, 0, 0)
        else:
            self.screen_shake = 8  # 일반공격: 가벼운 흔들림

        # 5. [핵심 수정] 모든 계산이 끝난 후 '단 한 번'만 데미지를 입힙니다.
        # 이전의 중복 호출(base_dmg 적용 후 final_dmg 또 적용)을 제거했습니다.
        actual = self.player.take_damage(final_dmg)

        # 6. 로그 생성 및 턴 종료
        crit_msg = "치명적 " if is_crit else ""
        msg = f"{self.enemy.name}의 {crit_msg}공격! ({actual} 데미지)"
        self.story.add(msg, f"enemy_atk_{self.turn}")

        # 사망 체크 및 페이즈 전환
        if self.player.hp <= 0:
            self.on_defeat()
            return

        self.start_player_turn()
        self.transition_lock = False
        self.set_phase(Phase.PLAYER_TURN, "enemy_done")

    # -----------------------------
    # 예외 처리
    # -----------------------------
    def handle_exception(self, e: Exception):
        tb = traceback.format_exc()
        self.last_exception = (str(e), tb)
        self.logger.log("ERROR", "EXCEPTION", str(e), {"trace": tb})
        self.dump_snapshot("exception")
        self.set_phase(Phase.ERROR, "exception")

    def _get_deck_index_from_pos(self, pos):
        """마우스 위치(pos)가 덱의 몇 번째 카드 자리에 있는지 반환합니다."""
        start_x, start_y = 100, 150
        card_w, card_h = 140, 180
        spacing_x, spacing_y = 160, 200

        # 덱에 있는 카드 개수만큼 루프를 돌며 충돌 체크
        for i in range(len(self.player.deck)):
            x = start_x + (i % 5) * spacing_x
            y = start_y + (i // 5) * spacing_y
            rect = pygame.Rect(x, y, card_w, card_h)
            if rect.collidepoint(pos):
                return i
        return None

    # -----------------------------
    # 이벤트 처리
    # -----------------------------
    def handle_events(self):
        for ev in pygame.event.get():
            if ev.type == pygame.QUIT:
                self.running = False
                return

            if ev.type == pygame.KEYDOWN:
                if ev.key == pygame.K_ESCAPE:
                    self.running = False
                    return
                if ev.key == pygame.K_F1:
                    self.dump_snapshot("manual")
                if ev.key == pygame.K_F2:
                    self.debug_overlay = not self.debug_overlay
                if ev.key == pygame.K_F3:
                    self.debug_ui_bounds = not self.debug_ui_bounds

                # 카드 사용 단축키
                if self.phase == Phase.PLAYER_TURN:
                    if (
                        ev.key == pygame.K_RETURN
                        and self.selected_card_index is not None
                    ):
                        self.use_card_index(self.selected_card_index)
                    if ev.key == pygame.K_SPACE:
                        self.request_end_turn()

            if ev.type == pygame.MOUSEBUTTONDOWN and ev.button == 1:
                pos = ev.pos
                # 1) 버튼 우선
                self.route_click(pos)

                # 2) 전투 카드 클릭(버튼에 안 걸렸을 때)
                if not self.frame_click_consumed and self.phase == Phase.PLAYER_TURN:
                    self.handle_battle_card_click(pos)

            if ev.type == pygame.MOUSEBUTTONDOWN and self.phase == Phase.DECK:
                # 드래그 시작 로직
                for i in range(len(self.player.deck)):
                    card_w, card_h = 140, 180
                    x = 100 + (i % 5) * 160
                    y = 150 + (i // 5) * 200
                    if pygame.Rect(x, y, card_w, card_h).collidepoint(ev.pos):
                        self.dragging_card_idx = i
                        self.drag_offset = (ev.pos[0] - x, ev.pos[1] - y)
                        break

            if ev.type == pygame.MOUSEBUTTONUP and self.phase == Phase.DECK:
                # 드래그 종료 및 위치 교환 로직
                if self.dragging_card_idx is not None:
                    # 마우스 위치의 새로운 인덱스 계산
                    new_idx = self._get_deck_index_from_pos(ev.pos)
                    if new_idx is not None and new_idx != self.dragging_card_idx:
                        # 위치 스왑
                        (
                            self.player.deck[self.dragging_card_idx],
                            self.player.deck[new_idx],
                        ) = (
                            self.player.deck[new_idx],
                            self.player.deck[self.dragging_card_idx],
                        )
                    self.dragging_card_idx = None

            if ev.type == pygame.MOUSEMOTION:
                self.mouse_pos = ev.pos

    def handle_battle_card_click(self, pos: Tuple[int, int]):
        # 카드 영역 계산
        card_w, card_h = 150, 120
        spacing = 15
        start_x = 50
        y = SCREEN_HEIGHT - card_h - 40

        for i, card in enumerate(self.player.hand):
            x = start_x + i * (card_w + spacing)
            rect = pygame.Rect(x, y, card_w, card_h)
            if rect.collidepoint(pos):
                # 같은 카드 두 번 클릭하면 사용
                if self.selected_card_index == i:
                    self.use_card_index(i)
                else:
                    self.selected_card_index = i
                return

    # -----------------------------
    # 업데이트
    # -----------------------------
    def update(self):
        # pending END_TURN 처리
        if self.pending_action and self.pending_action.get("type") == "END_TURN":
            self.end_player_turn()

        # 적 턴: 살짝 텀을 두고 실행(연출 느낌)
        if self.phase == Phase.ENEMY_TURN and not self.enemy_turn_done:
            if self.enemy_turn_started_ms is None:
                self.enemy_turn_started_ms = now_ms()
            if now_ms() - self.enemy_turn_started_ms >= 350:
                self.run_enemy_turn_once()

        # 전투 중 사망 체크(안전장치)
        if self.phase in (Phase.PLAYER_TURN, Phase.ENEMY_TURN):
            if self.enemy and self.enemy.hp <= 0:
                self.on_victory()
            if self.player.hp <= 0:
                self.on_defeat()

    # -----------------------------
    # 렌더
    # -----------------------------
    def render(self):
        """현재 상태(Phase)에 따라 단 하나의 화면만 렌더링합니다."""
        # 1. 화면 초기화 (잔상 제거의 핵심)
        self.screen.fill(COLOR_DARK_GRAY)
        self.buttons = []
        self.ui_buttons_next = {}
        self.frame_click_consumed = False

        # 2. 화면 흔들림 및 효과 계산
        render_offset = [0, 0]
        if self.screen_shake > 0:
            render_offset[0] = random.randint(-self.screen_shake, self.screen_shake)
            render_offset[1] = random.randint(-self.screen_shake, self.screen_shake)
            self.screen_shake = max(0, self.screen_shake - 2)

        try:
            # 3. Phase에 따른 엄격한 분기 (중복 호출 금지)
            if self.phase == Phase.WORLD:
                self.render_world()
            elif self.phase == Phase.INN:
                # [수정] render_world()를 내부에서 부르지 않아 겹침을 방지합니다.
                self.render_inn()
            elif self.phase == Phase.DECK:
                # [해결] AttributeError: render_deck 누락 해결
                self.render_deck()
            elif self.phase == Phase.TRAINING:
                self.render_training()
            elif self.phase in (Phase.PLAYER_TURN, Phase.ENEMY_TURN):
                self.render_battle()
            elif self.phase == Phase.VICTORY_PANEL:
                self.render_battle()
                self.render_victory_panel()
            elif self.phase == Phase.GAMEOVER:
                # [해결] NameError: 'py' 미정의 해결
                self.render_gameover_panel()
            elif self.phase == Phase.ERROR:
                self.render_error_panel()

            if self.debug_overlay:
                self.render_debug_overlay()

        except Exception as e:
            self.handle_exception(e)

        self.commit_buttons()
        pygame.display.flip()

    def render_inn(self):
        """객잔 화면: 휴식, 식사, 주류 시스템을 통합하여 렌더링합니다."""
        # 1. 배경 초기화 (겹침 방지)
        self.screen.fill((30, 20, 10))
        cx, cy = SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2

        # 2. 기초 수치 계산 (휴식용)
        nap_cost = max(1, self.player.max_hp // 10)
        sleep_cost = max(1, (self.player.max_hp * 3) // 10)
        missing_hp = self.player.max_hp - self.player.hp

        # 상단 정보 표시
        self.draw_text(
            "🏮 강호의 안식처 - 객잔", cx, 60, FONT_LARGE, COLOR_GOLD, center=True
        )
        self.draw_text(
            f"보유 금전: {self.player.gold} Gold / 현재 체력: {self.player.hp}/{self.player.max_hp}",
            cx,
            110,
            FONT_SMALL,
            COLOR_WHITE,
            center=True,
        )

        # ---------------------------------------------------------
        # [섹션 1: 휴식 시스템] - 주인님의 기존 로직 유지
        # ---------------------------------------------------------
        def do_rest(mode):
            latest_missing = self.player.max_hp - self.player.hp
            cost = nap_cost if mode == "nap" else sleep_cost
            if self.player.gold >= cost and latest_missing > 0:
                self.player.gold -= cost
                heal_amt = (
                    int(latest_missing * 0.5) if mode == "nap" else latest_missing
                )
                self.player.hp += heal_amt
                self.story.add(
                    f"🛌 {'쪽잠' if mode=='nap' else '숙면'}으로 기운을 차렸습니다. (+{heal_amt} HP)",
                    f"rest_{now_ms()}",
                )

        # 쪽잠 버튼
        r_nap = pygame.Rect(cx - 310, 160, 300, 70)
        can_nap = self.player.gold >= nap_cost and missing_hp > 0
        pygame.draw.rect(
            self.screen,
            (60, 80, 60) if can_nap else (50, 50, 50),
            r_nap,
            border_radius=10,
        )
        self.draw_text(
            f"쪽잠 (비용: {nap_cost}G)",
            r_nap.centerx,
            r_nap.centery,
            FONT_SMALL,
            center=True,
        )
        self.register_button(
            "inn_nap", r_nap, "쪽잠", on_click=lambda: do_rest("nap"), enabled=can_nap
        )

        # 숙면 버튼
        r_sleep = pygame.Rect(cx + 10, 160, 300, 70)
        can_sleep = self.player.gold >= sleep_cost and missing_hp > 0
        pygame.draw.rect(
            self.screen,
            (40, 60, 100) if can_sleep else (50, 50, 50),
            r_sleep,
            border_radius=10,
        )
        self.draw_text(
            f"숙면 (비용: {sleep_cost}G)",
            r_sleep.centerx,
            r_sleep.centery,
            FONT_SMALL,
            center=True,
        )
        self.register_button(
            "inn_sleep",
            r_sleep,
            "숙면",
            on_click=lambda: do_rest("sleep"),
            enabled=can_sleep,
        )

        # ---------------------------------------------------------
        # [섹션 2: 식사 및 주류 메뉴] - 신규 통합 시스템
        # ---------------------------------------------------------
        menu_y = 260
        pygame.draw.line(
            self.screen, COLOR_GOLD, (cx - 310, menu_y), (cx + 310, menu_y), 2
        )
        self.draw_text(
            "📜 오늘의 차림표 (식사 및 명주)",
            cx,
            menu_y + 25,
            FONT_MEDIUM,
            COLOR_GOLD,
            center=True,
        )

        def buy_item(item, category):
            if self.player.gold >= item["cost"]:
                self.player.gold -= item["cost"]
                self.player.apply_buff(
                    item, category
                )  # Player 클래스에 정의된 메서드 호출
                self.story.add(
                    f"😋 {item['name']}을(를) 즐겼습니다! {item['desc']}",
                    f"buy_{now_ms()}",
                )

        # 음식 메뉴 (왼쪽 배치 - 신체 강화용)
        for i, item in enumerate(MOUNTAIN_INN_MENU["FOOD"]):
            bx, by = cx - 310, menu_y + 60 + (i * 65)
            rect = pygame.Rect(bx, by, 300, 55)
            can_buy = self.player.gold >= item["cost"]

            pygame.draw.rect(
                self.screen,
                (45, 40, 35) if can_buy else (30, 30, 30),
                rect,
                border_radius=8,
            )
            pygame.draw.rect(
                self.screen,
                COLOR_WHITE if can_buy else (60, 60, 60),
                rect,
                1,
                border_radius=8,
            )

            self.draw_text(
                f"{item['name']} ({item['cost']}G)",
                bx + 15,
                by + 12,
                FONT_SMALL,
                COLOR_WHITE,
            )
            self.draw_text(item["desc"], bx + 15, by + 35, FONT_TINY, COLOR_GRAY)
            self.register_button(
                f"food_{i}",
                rect,
                item["name"],
                on_click=lambda it=item: buy_item(it, "FOOD"),
                enabled=can_buy,
            )

        # 주류 메뉴 (오른쪽 배치 - 내공/성장용)
        for i, item in enumerate(MOUNTAIN_INN_MENU["DRINK"]):
            bx, by = cx + 10, menu_y + 60 + (i * 65)
            rect = pygame.Rect(bx, by, 300, 55)
            can_buy = self.player.gold >= item["cost"]

            pygame.draw.rect(
                self.screen,
                (40, 45, 50) if can_buy else (30, 30, 30),
                rect,
                border_radius=8,
            )
            pygame.draw.rect(
                self.screen,
                COLOR_GOLD if can_buy else (60, 60, 60),
                rect,
                1,
                border_radius=8,
            )

            self.draw_text(
                f"{item['name']} ({item['cost']}G)",
                bx + 15,
                by + 12,
                FONT_SMALL,
                COLOR_GOLD,
            )
            self.draw_text(item["desc"], bx + 15, by + 35, FONT_TINY, COLOR_GRAY)
            self.register_button(
                f"drink_{i}",
                rect,
                item["name"],
                on_click=lambda it=item: buy_item(it, "DRINK"),
                enabled=can_buy,
            )

        # 떠나기 버튼 (위치 하단으로 조정)
        exit_r = pygame.Rect(cx - 60, SCREEN_HEIGHT - 80, 120, 45)
        pygame.draw.rect(self.screen, COLOR_DARK_RED, exit_r, border_radius=5)
        self.draw_text(
            "떠나기", cx, exit_r.centery, FONT_SMALL, COLOR_WHITE, center=True
        )
        self.register_button(
            "inn_exit", exit_r, "떠나기", on_click=lambda: self.set_phase(Phase.WORLD)
        )

    def render_active_buffs(self, x, y):
        curr_y = y
        # 1. 음식 버프 (BOX 높이를 30으로 설정하고 간격을 35씩 띄움)
        if self.player.food_buff:
            b = self.player.food_buff
            dur = b.get("duration", 0)
            pygame.draw.rect(
                self.screen, (50, 70, 50), (x, curr_y, 250, 30), border_radius=5
            )
            buff_text = f"🍱 {b['name']}: {b['desc']} ({dur}회 남음)"
            self.draw_text(buff_text, x + 10, curr_y + 7, FONT_TINY, COLOR_WHITE)
            curr_y += 40  # 다음 버프는 40픽셀 아래에 그림 (겹침 방지)

        # 2. 술 버프
        if self.player.drink_buff:
            b = self.player.drink_buff
            dur = b.get("duration", 0)
            pygame.draw.rect(
                self.screen, (70, 60, 40), (x, curr_y, 250, 30), border_radius=5
            )
            buff_text = f"🍶 {b['name']}: {b['desc']} ({dur}회 남음)"
            self.draw_text(buff_text, x + 10, curr_y + 7, FONT_TINY, COLOR_GOLD)

    def update_buffs(self):
        """전투가 끝날 때 호출하여 횟수를 차감하고, 0이 되면 즉시 삭제합니다."""
        # 1. 음식 버프 정리
        if self.player.food_buff:
            self.player.food_buff["duration"] -= 1
            # 0 이하가 되면 아예 데이터 자체를 비웁니다.
            if self.player.food_buff["duration"] <= 0:
                self.player.food_buff = None

        # 2. 술 버프 정리
        if self.player.drink_buff:
            self.player.drink_buff["duration"] -= 1
            if self.player.drink_buff["duration"] <= 0:
                self.player.drink_buff = None

    def render_debug_overlay(self):
        y = 8
        self.draw_text(
            f"PHASE={self.phase.value} chapter={self.chapter} encounter={self.encounter_index} turn={self.turn}",
            10,
            y,
            FONT_TINY,
        )
        y += 18
        if self.enemy:
            self.draw_text(
                f"ENEMY={self.enemy.name} hp={self.enemy.hp}/{self.enemy.max_hp} atk={self.enemy.attack_power} debuff={self.enemy.attack_debuff}",
                10,
                y,
                FONT_TINY,
            )
            y += 18
        self.draw_text(
            f"PLAYER hp={self.player.hp}/{self.player.max_hp} def={self.player.defense} energy={self.player.energy}/{self.player.max_energy}",
            10,
            y,
            FONT_TINY,
        )
        y += 18
        self.draw_text(
            f"story_lines={self.story.count()} buttons={len(self.ui_buttons_active)}",
            10,
            y,
            FONT_TINY,
        )

    def render_deck(self):
        """무공 비급 정리: 카드 형태의 UI와 드래그 앤 드롭을 지원합니다."""
        self.screen.fill((25, 20, 15))  # 깊은 밤 서재 느낌의 배경
        cx = SCREEN_WIDTH // 2

        # 1. 상단 타이틀 연출
        pygame.draw.line(self.screen, COLOR_GOLD, (cx - 200, 85), (cx + 200, 85), 2)
        self.draw_text(
            "📜 무림 비급 정리 (武林秘笈)", cx, 55, FONT_LARGE, COLOR_GOLD, center=True
        )
        self.draw_text(
            f"장착된 무공: {len(self.player.deck)} / 10 (드래그하여 위치 변경)",
            cx,
            105,
            FONT_TINY,
            COLOR_GRAY,
            center=True,
        )

        # 카드 배치 설정 (그리드 레이아웃)
        card_w, card_h = 140, 180
        start_x, start_y = 100, 150
        spacing_x, spacing_y = 160, 200

        # 2. 빈 슬롯(그림자) 미리 그리기 (위치 가이드)
        for i in range(10):
            x = start_x + (i % 5) * spacing_x
            y = start_y + (i // 5) * spacing_y
            slot_r = pygame.Rect(x, y, card_w, card_h)
            pygame.draw.rect(
                self.screen, (40, 35, 30), slot_r, border_radius=10
            )  # 슬롯 배경
            pygame.draw.rect(
                self.screen, (60, 55, 50), slot_r, 1, border_radius=10
            )  # 테두리

        # 3. 장착된 카드들 렌더링
        for i, card_id in enumerate(self.player.deck):
            # 현재 드래그 중인 카드는 여기서 그리지 않고 마지막에 그립니다 (Top-most)
            if i == self.dragging_card_idx:
                continue

            card = get_card_by_id(card_id)
            if not card:
                continue

            x = start_x + (i % 5) * spacing_x
            y = start_y + (i // 5) * spacing_y
            rect = pygame.Rect(x, y, card_w, card_h)

            # 카드 디자인 렌더링 (마스터리에 따른 황금 테두리 등)
            self._draw_ui_card(card, rect)

            # [제거 버튼] 우측 상단 X
            rem_r = pygame.Rect(x + card_w - 25, y + 5, 20, 20)
            pygame.draw.rect(self.screen, COLOR_DARK_RED, rem_r, border_radius=5)
            self.draw_text(
                "X", rem_r.centerx, rem_r.centery, FONT_TINY, COLOR_WHITE, center=True
            )
            self.register_button(
                f"rem_{i}",
                rem_r,
                "제거",
                on_click=lambda idx=i: self.player.deck.pop(idx),
            )

        # 4. 드래그 중인 카드 (마우스 위치를 따라다님)
        if self.dragging_card_idx is not None:
            drag_card_id = self.player.deck[self.dragging_card_idx]
            drag_card = get_card_by_id(drag_card_id)
            # 마우스 오프셋을 적용해 자연스러운 드래그 연출
            drag_rect = pygame.Rect(
                self.mouse_pos[0] - self.drag_offset[0],
                self.mouse_pos[1] - self.drag_offset[1],
                card_w,
                card_h,
            )
            self._draw_ui_card(drag_card, drag_rect, is_dragging=True)

        # 5. 하단 돌아가기 버튼
        exit_r = pygame.Rect(cx - 100, SCREEN_HEIGHT - 70, 200, 45)
        pygame.draw.rect(self.screen, (80, 40, 0), exit_r, border_radius=8)
        pygame.draw.rect(self.screen, COLOR_GOLD, exit_r, 2, border_radius=8)
        self.draw_text(
            "강호로 돌아가기", cx, exit_r.centery, FONT_SMALL, COLOR_WHITE, center=True
        )
        self.register_button(
            "deck_exit",
            exit_r,
            "돌아가기",
            on_click=lambda: self.set_phase(Phase.WORLD),
        )

    def _draw_ui_card(self, card, rect, is_dragging=False):
        """전투 시 카드 디자인을 계승한 UI 카드 그리기 함수"""
        alpha = 180 if is_dragging else 255

        # 카드 타입별 색상 설정
        type_colors = {
            "공격": (160, 40, 40),
            "방어": (40, 100, 40),
            "기술": (40, 40, 130),
            "약화": (70, 70, 70),
        }
        bg_color = type_colors.get(card.type.value, (100, 100, 100))

        # 카드 베이스
        pygame.draw.rect(self.screen, bg_color, rect, border_radius=8)
        pygame.draw.rect(
            self.screen,
            COLOR_GOLD if card.mastery >= 5 else COLOR_WHITE,
            rect,
            2,
            border_radius=8,
        )

        # 내용 (이름, 코스트, 마스터리)
        self.draw_text(f"{card.name}", rect.x + 10, rect.y + 15, FONT_SMALL)
        self.draw_text(
            f"內功 {card.base_cost}", rect.x + 10, rect.y + 45, FONT_TINY, COLOR_GOLD
        )
        self.draw_text(f"{card.mastery}성(星)", rect.x + 10, rect.y + 70, FONT_TINY)

    def render_ui_bounds(self):
        for bid, info in self.ui_buttons_active.items():
            rect: pygame.Rect = info["rect"]
            enabled = info.get("enabled", True)
            color = COLOR_GREEN if enabled else COLOR_RED
            pygame.draw.rect(self.screen, color, rect, 2)
            self.draw_text(bid, rect.x, rect.y - 14, FONT_TINY, color)

    # -----------------------------
    # WORLD / TRAINING / DECK
    # -----------------------------
    def render_world(self):
        cx = SCREEN_WIDTH // 2
        self.draw_text("산길을 걷는다", cx, 60, FONT_LARGE, COLOR_WHITE, center=True)

        self.draw_text(
            f"체력: {self.player.hp}/{self.player.max_hp}", 60, 140, FONT_MEDIUM
        )
        self.draw_text(f"경험치: {self.xp}", 60, 175, FONT_MEDIUM)
        self.draw_text(f"금전: {self.gold}", 60, 210, FONT_MEDIUM)
        self.draw_text(f"챕터: {self.chapter}", 60, 245, FONT_MEDIUM)
        self.draw_text(f"인카운터: {self.encounter_index}/5", 60, 280, FONT_MEDIUM)

        # 버튼들
        bw, bh = 240, 52

        r1 = pygame.Rect(cx - bw // 2, 360, bw, bh)
        pygame.draw.rect(self.screen, COLOR_DARK_GREEN, r1)
        pygame.draw.rect(self.screen, COLOR_WHITE, r1, 2)
        self.draw_text("계속 걷기 (전투)", cx, 386, FONT_MEDIUM, center=True)
        self.register_button(
            "world_continue",
            r1,
            "계속 걷기",
            on_click=lambda: self.start_battle(),
            layer="hud",
            priority=1,
        )

        r2 = pygame.Rect(cx - bw // 2, 430, bw, bh)
        pygame.draw.rect(self.screen, COLOR_BLUE, r2)
        pygame.draw.rect(self.screen, COLOR_WHITE, r2, 2)
        self.draw_text("수련", cx, 456, FONT_MEDIUM, center=True)
        self.register_button(
            "world_training",
            r2,
            "수련",
            on_click=lambda: self.set_phase(Phase.TRAINING, "open_training"),
            layer="hud",
            priority=1,
        )

        r3 = pygame.Rect(cx - bw // 2, 500, bw, bh)
        pygame.draw.rect(self.screen, COLOR_BROWN, r3)
        pygame.draw.rect(self.screen, COLOR_WHITE, r3, 2)
        self.draw_text("덱 정비", cx, 526, FONT_MEDIUM, center=True)
        self.register_button(
            "world_deck",
            r3,
            "덱 정비",
            on_click=lambda: self.set_phase(Phase.DECK, "open_deck"),
            layer="hud",
            priority=1,
        )
        r4 = pygame.Rect(cx - bw // 2, 570, bw, bh)
        pygame.draw.rect(self.screen, COLOR_BROWN, r4)  # 고풍스러운 갈색
        pygame.draw.rect(self.screen, COLOR_WHITE, r4, 2)
        self.draw_text("객잔 입장", cx, 596, FONT_MEDIUM, center=True)
        self.register_button(
            "world_inn",
            r4,
            "객잔 입장",
            on_click=lambda: self.set_phase(Phase.INN, "enter_inn"),
            layer="hud",
            priority=1,
        )
        # 스토리
        self.story.render(self.screen, 60, 600)

    def render_training(self):
        """수련 화면: 6대 근본 스탯을 수련하여 무인의 경지를 높입니다."""
        # 1. 배경을 어둡게 처리하여 월드 UI와 분리
        overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
        overlay.set_alpha(200)
        overlay.fill(COLOR_BLACK)
        self.screen.blit(overlay, (0, 0))

        # 2. 중앙 패널 설정
        cx, cy = SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2
        pw, ph = 600, 500
        px, py = cx - pw // 2, cy - ph // 2
        panel = pygame.Rect(px, py, pw, ph)

        pygame.draw.rect(self.screen, COLOR_BLACK, panel)
        pygame.draw.rect(self.screen, COLOR_GOLD, panel, 3)
        self.draw_text("수련 (修行)", cx, py + 40, FONT_LARGE, COLOR_GOLD, center=True)

        # 3. 6대 스탯 옵션
        upgrades = [
            ("근골 (생명 +10)", 20, "geungol", 10),
            ("심법 (내공 +1)", 30, "simbeop", 1),
            ("외공 (방어 +2)", 15, "oegong", 2),
            ("경공 (회피 +1%)", 20, "gyeonggong", 1),
            ("자질 (위력 +2%)", 25, "jajil", 1),
            ("행운 (치명 +1%)", 20, "haengun", 1),
        ]

        bw, bh = 240, 80
        padding, start_y = 20, py + 100

        for i, (label, cost, stat_key, val) in enumerate(upgrades):
            col, row = i // 3, i % 3
            bx = (cx - bw - padding // 2) if col == 0 else (cx + padding // 2)
            by = start_y + row * (bh + padding)
            r = pygame.Rect(bx, by, bw, bh)

            can_afford = self.player.exp >= cost
            bg_col = (40, 80, 40) if can_afford else (60, 60, 60)

            pygame.draw.rect(self.screen, bg_col, r, border_radius=10)
            pygame.draw.rect(self.screen, COLOR_WHITE, r, 2, border_radius=10)
            self.draw_text(label, r.centerx, r.y + 18, FONT_SMALL, center=True)
            self.draw_text(
                f"비용: {cost} XP",
                r.centerx,
                r.y + 48,
                FONT_TINY,
                COLOR_GOLD if can_afford else COLOR_WHITE,
                center=True,
            )

            def make_upgrade_handler(_key=stat_key, _cost=cost, _val=val, _label=label):
                def h():
                    if self.player.exp < _cost:
                        return
                    self.player.exp -= _cost
                    self.total_training += 1
                    if _key == "geungol":
                        self.player.base_geungol += _val
                        self.player.max_hp = self.player.base_geungol
                        self.player.hp += _val
                    elif _key == "simbeop":
                        self.player.base_simbeop += _val
                        self.player.max_energy = self.player.base_simbeop
                    elif _key == "oegong":
                        self.player.base_oegong += _val
                    elif _key == "gyeonggong":
                        self.player.base_gyeonggong += _val
                    elif _key == "jajil":
                        self.player.base_jajil += _val
                    elif _key == "haengun":
                        self.player.base_haengun += _val
                    self.story.add(
                        f"🙏 깨달음! {_label} 수련 완료.", f"train_{_key}_{now_ms()}"
                    )

                return h

            self.register_button(
                f"btn_train_{i}",
                r,
                label,
                on_click=make_upgrade_handler(),
                layer="modal",
                enabled=can_afford,
                priority=3,
            )

        # 4. 닫기 버튼
        cr = pygame.Rect(cx - 60, py + ph - 60, 120, 40)
        pygame.draw.rect(self.screen, COLOR_DARK_RED, cr, border_radius=5)
        self.draw_text("닫기", cx, cr.y + 12, FONT_SMALL, center=True)
        self.register_button(
            "training_close",
            cr,
            "닫기",
            on_click=lambda: self.set_phase(Phase.WORLD),
            layer="modal",
            priority=3,
        )

    # -----------------------------
    # BATTLE / 결과 패널
    # -----------------------------
    def render_battle(self):
        """전투 화면을 렌더링합니다. (방어력 버프 표기 로직 적용)"""
        # 1. 상단 HUD 표시
        self.draw_text("구운록", 60, 30, FONT_MEDIUM, COLOR_GOLD)
        self.draw_text(
            f"챕터 {self.chapter} / 인카운터 {self.encounter_index}",
            60,
            55,
            FONT_TINY,
            COLOR_GRAY,
        )
        self.draw_text(
            f"XP {self.xp} / GOLD {self.gold}", 60, 75, FONT_TINY, COLOR_GRAY
        )

        # 2. 플레이어 정보 표시 (이름 및 체력바)
        self.draw_text(f"{self.player.name}", 60, 120, FONT_MEDIUM)
        self.draw_bar(60, 145, 280, 18, self.player.hp, self.player.max_hp, COLOR_GREEN)
        self.draw_text(
            f"HP {self.player.hp}/{self.player.max_hp}", 60, 170, FONT_TINY, COLOR_WHITE
        )

        # ---------------------------------------------------------
        # [교정 지점] 방어력(DEF) 및 버프 수치 연동 표기
        # ---------------------------------------------------------
        eff_def = self.player.get_effective_defense()  # 버프 포함 총 방어력
        base_def = self.player.defense  # 기본 외공 수치
        bonus = eff_def - base_def  # 만두 등으로 얻은 보너스

        # DEF 0 (+5) 형식으로 텍스트 구성
        def_text = f"DEF {base_def}"
        if bonus > 0:
            def_text += f" (+{bonus})"

        # 실제 화면 출력 (좌표 60, 190)
        self.draw_text(def_text, 60, 190, FONT_TINY, COLOR_BLUE)
        # ---------------------------------------------------------

        # 3. 내공(ENERGY) 표시
        if self.phase in (Phase.PLAYER_TURN, Phase.ENEMY_TURN):
            self.draw_text(
                f"ENERGY {self.player.energy}/{self.player.max_energy}",
                60,
                210,
                FONT_TINY,
                COLOR_GOLD,
            )

        # 4. 버프 아이콘 표시 (에너지 바 아래)
        self.render_active_buffs(60, 235)

        # 5. 적의 의도(Intent) 표시
        if self.enemy and self.enemy.next_intent:
            ex = SCREEN_WIDTH - 360
            intent = self.enemy.next_intent
            intent_msg = ""
            intent_color = COLOR_WHITE

            if intent["type"] == "attack":
                intent_msg = f"⚔️ 다음 수: {intent['value']} 대미지 공격 예상"
                intent_color = COLOR_RED
            elif intent["type"] == "special":
                intent_msg = f"🔥 위기: {intent['value']} 대미지 강력한 일격!"
                intent_color = COLOR_GOLD
            else:
                intent_msg = f"⚠️ 경고: {intent['value']}의 필살기 준비 중!"
                intent_color = COLOR_DARK_RED

            self.draw_text(intent_msg, ex, 100, FONT_SMALL, intent_color)

        # 6. 적 상태창 표시
        if self.enemy:
            ex = SCREEN_WIDTH - 360
            self.draw_text(f"{self.enemy.name}", ex, 120, FONT_MEDIUM)
            self.draw_bar(ex, 145, 280, 18, self.enemy.hp, self.enemy.max_hp, COLOR_RED)
            self.draw_text(
                f"HP {self.enemy.hp}/{self.enemy.max_hp}",
                ex,
                170,
                FONT_TINY,
                COLOR_WHITE,
            )

        # 7. 중앙 스토리 로그 렌더링
        self.story.render(self.screen, 60, 260)

        # 8. 전투 UI (손패 및 버튼)
        if self.phase in (Phase.PLAYER_TURN, Phase.ENEMY_TURN):
            self.render_hand()
            self.render_primary_button()

        # 9. 화면 상단 남은 초식 카운트 표시
        rem = 5 - self.cards_played_this_turn
        color = COLOR_GOLD if rem > 1 else COLOR_DARK_RED
        self.draw_text(
            f"남은 초식: {rem} / 5",
            SCREEN_WIDTH // 2,
            200,
            FONT_MEDIUM,
            color,
            center=True,
        )

    def render_hand(self):
        """플레이어의 손패 카드를 상세 수치(위력/방어)와 함께 그립니다."""
        card_w, card_h = 150, 120
        spacing = 15
        start_x = 50
        y = SCREEN_HEIGHT - card_h - 40

        TYPE_COLORS = {
            "공격": (180, 40, 40),
            "방어": (40, 120, 40),
            "기술": (40, 40, 150),
            "약화": (80, 80, 80),
        }

        for i, card in enumerate(self.player.hand):
            x = start_x + i * (card_w + spacing)
            rect = pygame.Rect(x, y, card_w, card_h)

            # 10성 이상이면 황금색 테두리 연출
            if card.mastery >= 10:
                bg_color = (255, 215, 0)
                name_color = (0, 0, 0)
            else:
                card_type_str = (
                    card.type.value if hasattr(card.type, "value") else str(card.type)
                )
                bg_color = TYPE_COLORS.get(card_type_str, (40, 120, 40))
                name_color = (255, 255, 255)

            pygame.draw.rect(self.screen, bg_color, rect)
            pygame.draw.rect(self.screen, (255, 255, 255), rect, 2)

            # 1. 무공 이름과 [성] 표시
            display_name = f"{card.name} [{card.mastery}성]"
            self.draw_text(display_name, x + 8, y + 8, FONT_SMALL, name_color)

            # 2. 내공 소모 표시
            self.draw_text(
                f"내공 {card.base_cost}", x + 8, y + 30, FONT_TINY, name_color
            )

            # 3. [핵심] 숙련도(성)에 따른 실시간 수치 계산 및 표시
            stat_label = ""
            if card.name == "포천삼":
                # 시작 수치 5 + (성-1) * 2
                current_val = card.base_value + (card.mastery - 1) * 2
                stat_label = f"방어: {current_val}"
            elif card.name == "유운지":
                # 시작 수치 5 + (성-1)
                current_val = card.base_value + (card.mastery - 1)
                stat_label = f"약화: {current_val}"
            elif "삼재" in card.name or "심재" in card.name:
                # 3성마다 내공 회복 +1 (기본 1)
                current_val = 1 + (card.mastery // 3)
                stat_label = f"내공회복: {current_val}"
            elif card_type_str == "공격":
                # 공격 무공은 성당 위력 +2씩 보너스
                current_val = card.base_value + (card.mastery - 1) * 2
                stat_label = f"위력: {current_val}"
            else:
                stat_label = "효과: 특수"

            self.draw_text(stat_label, x + 8, y + 50, FONT_TINY, name_color)

            # 4. 무공 설명
            desc_text = card.description
            if len(desc_text) > 15:
                desc_text = desc_text[:13] + ".."
            self.draw_text(desc_text, x + 8, y + 70, FONT_TINY, name_color)

            # 5. 숙련도(경험치) 바 표시
            exp_text = f"숙련: {card.usage_count}/{card.mastery * 3}"
            self.draw_text(exp_text, x + 8, y + card_h - 20, FONT_TINY, name_color)

    def render_primary_button(self):
        bw, bh = 150, 46
        r = pygame.Rect(SCREEN_WIDTH - bw - 40, SCREEN_HEIGHT - bh - 30, bw, bh)

        if self.phase == Phase.PLAYER_TURN:
            enabled = not self.transition_lock
            col = COLOR_DARK_GREEN if enabled else COLOR_DARK_GRAY
            pygame.draw.rect(self.screen, col, r)
            pygame.draw.rect(self.screen, COLOR_WHITE, r, 2)
            self.draw_text("턴 종료", r.centerx, r.centery, FONT_SMALL, center=True)
            self.register_button(
                "turn_end",
                r,
                "턴 종료",
                on_click=self.request_end_turn,
                layer="hud",
                enabled=enabled,
                priority=1,
            )

        elif self.phase == Phase.ENEMY_TURN:
            pygame.draw.rect(self.screen, COLOR_DARK_GRAY, r)
            pygame.draw.rect(self.screen, COLOR_WHITE, r, 2)
            self.draw_text("적 턴...", r.centerx, r.centery, FONT_SMALL, center=True)

    def render_victory_panel(self):
        # 오버레이
        overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
        overlay.set_alpha(240)
        overlay.fill(COLOR_BLACK)
        self.screen.blit(overlay, (0, 0))

        cx, cy = SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2
        pw, ph = 640, 520
        px, py = cx - pw // 2, cy - ph // 2
        panel = pygame.Rect(px, py, pw, ph)

        pygame.draw.rect(self.screen, COLOR_BLACK, panel)
        pygame.draw.rect(self.screen, COLOR_GOLD, panel, 3)

        self.draw_text("승리!", cx, py + 40, FONT_LARGE, COLOR_GOLD, center=True)
        if self.enemy:
            self.draw_text(
                f"{self.enemy.name}을(를) 쓰러뜨렸다.",
                cx,
                py + 85,
                FONT_SMALL,
                COLOR_WHITE,
                center=True,
            )

        # 요약
        bs = self.battle_summary or {}
        self.draw_text(
            f"전투 요약: {bs.get('turns', 0)}합",
            cx,
            py + 135,
            FONT_MEDIUM,
            COLOR_WHITE,
            center=True,
        )

        # 카드 사용
        cc = bs.get("card_counts", {})
        if cc:
            card_line = ", ".join([f"{k}({v})" for k, v in cc.items()])
            if len(card_line) > 60:
                card_line = card_line[:57] + "..."
            self.draw_text(
                f"사용한 무공: {card_line}",
                cx,
                py + 175,
                FONT_SMALL,
                COLOR_WHITE,
                center=True,
            )

        # 보상
        rw = self.rewards or {"xp": 0, "gold": 0, "card_reward_id": None}
        self.draw_text("획득", cx, py + 230, FONT_MEDIUM, COLOR_WHITE, center=True)
        self.draw_text(
            f"경험치 +{rw.get('xp', 0)} (총 {self.xp})",
            cx,
            py + 265,
            FONT_SMALL,
            COLOR_WHITE,
            center=True,
        )
        self.draw_text(
            f"금전 +{rw.get('gold', 0)} (총 {self.gold})",
            cx,
            py + 295,
            FONT_SMALL,
            COLOR_WHITE,
            center=True,
        )
        if rw.get("card_reward_id"):
            self.draw_text(
                f"카드: {rw['card_reward_id']}",
                cx,
                py + 325,
                FONT_SMALL,
                COLOR_GOLD,
                center=True,
            )

        # 버튼 2개
        bw, bh = 190, 52
        y = py + ph - 90

        r1 = pygame.Rect(cx - bw - 10, y, bw, bh)
        pygame.draw.rect(self.screen, COLOR_BROWN, r1)
        pygame.draw.rect(self.screen, COLOR_WHITE, r1, 2)
        self.draw_text("덱 정비", r1.centerx, r1.centery, FONT_MEDIUM, center=True)
        self.register_button(
            "victory_deck",
            r1,
            "덱 정비",
            on_click=lambda: self.set_phase(Phase.DECK, "victory_deck"),
            layer="modal",
            priority=3,
        )

        r2 = pygame.Rect(cx + 10, y, bw, bh)
        pygame.draw.rect(self.screen, COLOR_DARK_GREEN, r2)
        pygame.draw.rect(self.screen, COLOR_WHITE, r2, 2)
        self.draw_text("다음 적", r2.centerx, r2.centery, FONT_MEDIUM, center=True)

        def next_enemy():
            # 다음 진행
            self.advance_progression()
            # 적/전투 정리 후 월드로
            self.enemy = None
            self.set_phase(Phase.WORLD, "victory_next")
            self.story.add("다음 길로 발걸음을 옮긴다.", f"walk_{now_ms()}")

        self.register_button(
            "victory_next",
            r2,
            "다음 적",
            on_click=next_enemy,
            layer="modal",
            priority=3,
        )

    def render_gameover_panel(self):
        """플레이어의 죽음을 무협지 일대기로 정리하여 보여줍니다."""
        # 1. 어두운 배경 오버레이 (죽음의 분위기 연출)
        overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
        overlay.set_alpha(220)
        overlay.fill((10, 5, 0))
        self.screen.blit(overlay, (0, 0))

        # 2. 중앙 패널 및 좌표 설정 (에러 방지를 위해 px, py, pw, ph 정의)
        cx, cy = SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2
        pw, ph = 600, 600
        px, py = cx - pw // 2, cy - ph // 2
        book_rect = pygame.Rect(px, py, pw, ph)

        # 3. 고풍스러운 종이 질감 연출 (강호실록 배경)
        pygame.draw.rect(self.screen, (245, 235, 210), book_rect)  # 빛바랜 한지 색
        pygame.draw.rect(self.screen, (80, 40, 0), book_rect, 5)  # 책 테두리

        # 4. 일대기 텍스트 렌더링 (generate_life_summary 활용)
        lines = self.generate_life_summary()
        for i, line in enumerate(lines):
            # 강조색 (제목이나 회차 정보는 붉은색, 본문은 어두운 회색)
            color = (180, 0, 0) if "제" in line and "회차" in line else (40, 40, 40)
            # 패널 상단(cy - 250)부터 줄 간격 40으로 텍스트 배치
            self.draw_text(line, cx, cy - 250 + i * 40, FONT_SMALL, color, center=True)

        # 5. '윤회하기' 버튼 (재시작)
        # 기존의 단순한 '패배' 문구 대신 서사적인 '윤회' 버튼으로 통일했습니다.
        btn_r = pygame.Rect(cx - 100, cy + 220, 200, 50)
        pygame.draw.rect(self.screen, (60, 30, 0), btn_r)
        pygame.draw.rect(self.screen, COLOR_GOLD, btn_r, 2)

        self.draw_text(
            "윤회 (다시 시작)", cx, btn_r.y + 15, FONT_SMALL, COLOR_WHITE, center=True
        )

        # 윤회 시스템 호출 (reset_game_with_legacy)
        self.register_button(
            "retry",
            btn_r,
            "윤회",
            on_click=self.reset_game_with_legacy,
            layer="modal",
            priority=3,
        )

    def reset_game_with_legacy(self):
        """회차를 기억하며 다시 시작합니다."""
        self.life_count += 1
        self.met_enemies = []
        self.total_training = 0
        self.reset_game()

    def render_error_panel(self):
        self.screen.fill(COLOR_BLACK)
        cx, cy = SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2
        self.draw_text("EXCEPTION 발생!", cx, 60, FONT_LARGE, COLOR_RED, center=True)

        msg, tb = self.last_exception if self.last_exception else ("Unknown", "")
        self.draw_text(msg, cx, 110, FONT_SMALL, COLOR_WHITE, center=True)

        lines = tb.splitlines()[-12:]
        y = 160
        for ln in lines:
            if ln.strip():
                self.draw_text(ln[:120], 30, y, FONT_TINY, COLOR_GRAY)
                y += 18

        r = pygame.Rect(cx - 110, SCREEN_HEIGHT - 80, 220, 48)
        pygame.draw.rect(self.screen, COLOR_DARK_GREEN, r)
        pygame.draw.rect(self.screen, COLOR_WHITE, r, 2)
        self.draw_text("게임 리셋", r.centerx, r.centery, FONT_MEDIUM, center=True)
        self.register_button(
            "error_reset",
            r,
            "게임 리셋",
            on_click=self.reset_game,
            layer="modal",
            priority=3,
        )

    def generate_life_summary(self):
        """이번 생의 기록을 무협지 문체로 요약합니다."""
        summary = []
        summary.append(
            f"--- 제 {self.life_count}회차 일대기: 무인 {self.player.name}의 기록 ---"
        )
        summary.append(f"\n[출도] 어느 평범한 날, 강호에 첫발을 내디뎠다.")

        # 수련 기록 요약
        if self.total_training > 0:
            summary.append(f"[수련] 총 {self.total_training}회의 고된 수련을 통해")
            summary.append(
                f"      근골({self.player.base_geungol})과 이해도({self.player.base_jajil})를 닦았다."
            )

        # 적 조우 기록
        unique_enemies = list(set(self.met_enemies))
        if unique_enemies:
            summary.append(
                f"[행적] {', '.join(unique_enemies)} 등 수많은 강적과 마주하며"
            )
            summary.append(f"      자신의 무공을 증명해 보였다.")

        # 최후의 순간
        killer = self.enemy.name if self.enemy else "알 수 없는 운명"
        summary.append(f"\n[절명] 그러나 세상은 넓고 고수는 많았다.")
        summary.append(f"      끝내 {killer}의 초식을 파훼하지 못하고")
        summary.append(
            f"      차가운 땅 위에서 짧은 생을 마감하니, 향년 제 {self.turn}합째였다."
        )

        summary.append(f"\n--- 그의 혼은 다시 윤회하여 강호에 돌아오리라 ---")
        return summary

    def render_chronicle(self):
        """죽었을 때 나타나는 일대기 화면"""
        self.screen.fill((20, 20, 20))  # 어두운 배경

        # 고풍스러운 종이 느낌의 사각형
        book_rect = pygame.Rect(100, 50, SCREEN_WIDTH - 200, SCREEN_HEIGHT - 100)
        pygame.draw.rect(self.screen, (240, 230, 200), book_rect)  # 빛바랜 종이색
        pygame.draw.rect(self.screen, (100, 50, 0), book_rect, 5)  # 책 테두리

        lines = self.generate_life_summary()
        for i, line in enumerate(lines):
            color = (50, 50, 50)
            if "제" in line and "회차" in line:
                color = (150, 0, 0)  # 제목은 붉은색

            self.draw_text(
                line, SCREEN_WIDTH // 2, 100 + i * 40, FONT_SMALL, color, center=True
            )

        # 다시 시작 버튼
        btn_r = pygame.Rect(SCREEN_WIDTH // 2 - 100, SCREEN_HEIGHT - 120, 200, 50)
        pygame.draw.rect(self.screen, (50, 50, 50), btn_r)
        self.draw_text(
            "윤회하기 (다시 시작)",
            SCREEN_WIDTH // 2,
            btn_r.y + 15,
            FONT_TINY,
            (255, 255, 255),
            center=True,
        )

    # -----------------------------
    # 메인 루프
    # -----------------------------
    def run(self):
        while self.running:
            self.clock.tick(FPS)
            self.handle_events()
            self.update()
            self.render()


def main():
    pygame.init()
    global _pygame_initialized
    _pygame_initialized = True

    try:
        game = Game()
        game.run()
    except Exception:
        print(traceback.format_exc())
    finally:
        pygame.quit()


if __name__ == "__main__":
    main()
