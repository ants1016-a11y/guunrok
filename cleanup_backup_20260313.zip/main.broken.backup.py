#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
구운록 (Guunrok) - 무협 카드 배틀 게임
=====================================

실행 방법:
1. Pygame 설치: pip install pygame
2. 실행: python main.py

게임 설명:
- 회귀한 둔재가 되어 녹림 도적들과 전투를 벌이는 턴제 카드 배틀 게임
- 카드를 선택하여 사용하고, 턴 종료 버튼으로 턴을 넘깁니다
- 적을 모두 물리치면 승리합니다
"""

import pygame
import random
import sys
import json
import os
import traceback
import time
import argparse
from datetime import datetime
from collections import deque
from typing import List, Optional, Tuple, Dict, Any
from enum import Enum

# 시간 유틸리티 함수
# pygame.init() 이후에는 pygame.time.get_ticks()를 사용하고,
# 그 전에는 time.time() 기반을 사용합니다.
_pygame_initialized = False


def now_ms() -> int:
    """현재 시간을 밀리초로 반환합니다."""
    global _pygame_initialized
    if _pygame_initialized:
        return pygame.time.get_ticks()
    else:
        return int(time.time() * 1000)


# Pygame 초기화
pygame.init()
_pygame_initialized = True

# 화면 설정
SCREEN_WIDTH = 1200
SCREEN_HEIGHT = 800
FPS = 60

# 색상 정의 (무협 느낌)
COLOR_BLACK = (0, 0, 0)
COLOR_WHITE = (255, 255, 255)
COLOR_DARK_GRAY = (40, 40, 40)  # 묵색
COLOR_RED = (180, 0, 0)  # 붉은색
COLOR_DARK_RED = (120, 0, 0)
COLOR_GREEN = (0, 150, 0)
COLOR_DARK_GREEN = (0, 100, 0)
COLOR_GOLD = (218, 165, 32)
COLOR_BROWN = (139, 69, 19)
COLOR_GRAY = (128, 128, 128)  # 회색 (덜 중요한 정보용)
COLOR_BLUE = (100, 150, 255)  # 푸른색 (방어도용)


# 폰트 설정 (한글 지원)
def get_font(size):
    """시스템 폰트를 가져옵니다. 한글 지원을 시도합니다."""
    import platform
    import os

    # macOS 폰트 경로
    if platform.system() == "Darwin":  # macOS
        # macOS 시스템 폰트 경로들 (실제 파일 경로)
        font_paths = [
            "/System/Library/Fonts/Supplemental/AppleGothic.ttf",
            "/System/Library/Fonts/AppleGothic.ttf",
            "/Library/Fonts/NanumGothic.ttc",
            "/System/Library/Fonts/Helvetica.ttc",
            "/System/Library/Fonts/Supplemental/AppleSDGothicNeo.ttc",
            "/System/Library/Fonts/Supplemental/AppleSDGothicNeoBold.ttc",
            "/System/Library/Fonts/Supplemental/AppleSDGothicNeoRegular.ttc",
        ]

        # 실제 파일 경로로 폰트 로드 시도
        for font_path in font_paths:
            if os.path.exists(font_path):
                try:
                    font = pygame.font.Font(font_path, size)
                    # 테스트: 한글 렌더링 가능한지 확인
                    test_surface = font.render("테스트", True, COLOR_WHITE)
                    if test_surface.get_width() > 0:
                        print(f"폰트 로드 성공: {font_path} (크기: {size})")
                        return font
                except Exception as e:
                    continue

        # SysFont 사용 (시스템 폰트 이름으로) - macOS에서 더 잘 작동
        font_names = [
            "AppleGothic",
            "Apple SD Gothic Neo",
            "NanumGothic",
            "Nanum Gothic",
            "Malgun Gothic",
            "Gulim",
            "Arial Unicode MS",
            "Helvetica",
        ]

        for font_name in font_names:
            try:
                font = pygame.font.SysFont(font_name, size)
                # 테스트: 한글 렌더링 가능한지 확인
                test_surface = font.render("테스트", True, COLOR_WHITE)
                if test_surface.get_width() > 0:
                    print(f"폰트 로드 성공: {font_name} (크기: {size})")
                    return font
            except Exception as e:
                continue

    # Windows/Linux 또는 폰트를 찾지 못한 경우
    font_names = [
        "malgun gothic",  # Windows
        "NanumGothic",  # Linux (설치되어 있다면)
        "AppleGothic",  # macOS fallback
    ]

    for font_name in font_names:
        try:
            font = pygame.font.SysFont(font_name, size)
            test_surface = font.render("테스트", True, COLOR_WHITE)
            if test_surface.get_width() > 0:
                print(f"폰트 로드 성공: {font_name} (크기: {size})")
                return font
        except:
            continue

    # 모든 폰트 실패 시 기본 폰트 사용 (한글 미지원)
    print(f"경고: 한글 폰트를 찾을 수 없습니다. 기본 폰트를 사용합니다. (크기: {size})")
    print("한글이 깨질 수 있습니다. 시스템에 한글 폰트가 설치되어 있는지 확인하세요.")
    return pygame.font.Font(None, size)


# 폰트 초기화 (게임 시작 전에 한 번만)
FONT_LARGE = None
FONT_MEDIUM = None
FONT_SMALL = None
FONT_TINY = None


def init_fonts():
    """폰트를 초기화합니다."""
    global FONT_LARGE, FONT_MEDIUM, FONT_SMALL, FONT_TINY
    FONT_LARGE = get_font(32)
    FONT_MEDIUM = get_font(24)
    FONT_SMALL = get_font(18)
    FONT_TINY = get_font(14)


# 게임 상태 Enum (State Machine)
class GameState(Enum):
    EVENT = "EVENT"  # 이벤트/선택지 화면
    BATTLE = "BATTLE"  # 전투 중 (PLAYER_TURN/ENEMY_TURN 포함)
    VICTORY_PANEL = "VICTORY_PANEL"  # 승리 결과창
    GAMEOVER = "GAMEOVER"  # 패배 결과창
    WORLD = "WORLD"  # 월드 화면 (수련 등)


# BATTLE 내부 상태
PHASE_PLAYER_TURN = "PLAYER_TURN"  # BATTLE 내부 상태
PHASE_ENEMY_TURN = "ENEMY_TURN"  # BATTLE 내부 상태

# 하위 호환성을 위한 상수
PHASE_VICTORY_PANEL = GameState.VICTORY_PANEL.value
PHASE_DEFEAT_PANEL = GameState.GAMEOVER.value
PHASE_CAMP = "CAMP"  # 전투 후 캠프 화면 (산길을 걷는다)
PHASE_TRAINING = "TRAINING"  # 수련 메뉴 화면
PHASE_DECK = "DECK"  # 덱 빌더 화면
PHASE_WORLD = GameState.WORLD.value  # 하위 호환성 (CAMP와 동일)


# ==================== 디버깅 시스템: DebugLogger ====================
class DebugLogger:
    """파일 기반 디버그 로거 (JSON Lines 형식)"""

    def __init__(self, log_dir: str = "logs"):
        self.log_dir = log_dir
        os.makedirs(log_dir, exist_ok=True)

        # 실행마다 새 로그 파일 생성
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.log_file = os.path.join(log_dir, f"run_{timestamp}.log")
        self.log_count = 0

        # 로그 파일 초기화
        with open(self.log_file, "w", encoding="utf-8") as f:
            f.write(f"# Debug Log Started: {datetime.now().isoformat()}\n")

    def log(
        self, level: str, tag: str, msg: str, data: Optional[Dict[str, Any]] = None
    ):
        """레벨, 태그, 메시지, 데이터를 JSON Lines 형식으로 기록"""
        entry = {
            "timestamp_ms": now_ms(),
            "timestamp": datetime.now().isoformat(),
            "level": level,  # DEBUG, INFO, WARN, ERROR, CRITICAL
            "tag": tag,  # PHASE_TRANSITION, UI_CLICK, STATE_CHANGE, ERROR 등
            "message": msg,
            "data": data or {},
        }

        # JSON Lines 형식으로 저장
        try:
            with open(self.log_file, "a", encoding="utf-8") as f:
                f.write(json.dumps(entry, ensure_ascii=False) + "\n")
            self.log_count += 1
        except Exception as e:
            # 로그 저장 실패 시 stderr에 출력
            print(f"[LOGGER ERROR] {e}", file=sys.stderr)

    def get_recent_logs(self, count: int = 200) -> List[Dict[str, Any]]:
        """최근 로그 N줄 읽기"""
        try:
            with open(self.log_file, "r", encoding="utf-8") as f:
                lines = f.readlines()
                # JSON Lines 파싱
                logs = []
                for line in lines[-count:]:
                    line = line.strip()
                    if line and not line.startswith("#"):
                        try:
                            logs.append(json.loads(line))
                        except:
                            pass
                return logs
        except:
            return []


# 카드 타입 열거형
class CardType(Enum):
    ATTACK = "공격"
    DEFENSE = "방어"
    SKILL = "기술"
    DEBUFF = "약화"


# 스토리 로그 클래스
class StoryLog:
    """스토리 텍스트를 관리하는 클래스 (프레임마다 누적 방지)"""

    def __init__(self, max_lines: int = 6):
        self.max_lines = max_lines
        self.lines = []  # (text, dedupe_key, state_enter_id) 튜플 리스트
        self.last_story_key = None
        self.current_state_enter_id = {}  # state별 enter_id 추적

    def add(
        self,
        text: str,
        dedupe_key: Optional[str] = None,
        state_enter_id: Optional[int] = None,
    ):
        """스토리 라인 추가 (중복 방지)"""
        # 같은 dedupe_key가 같은 state_enter_id에서 반복되면 추가하지 않음
        if dedupe_key and state_enter_id is not None:
            # 최근 라인들 중 같은 dedupe_key와 state_enter_id가 있으면 스킵
            for line_text, line_key, line_enter_id in self.lines:
                if line_key == dedupe_key and line_enter_id == state_enter_id:
                    return  # 중복이므로 추가하지 않음

        self.lines.append((text, dedupe_key, state_enter_id))
        self.last_story_key = dedupe_key

        # 최대 라인 수 초과 시 오래된 줄 삭제
        if len(self.lines) > self.max_lines:
            self.lines.pop(0)

    def clear(self):
        """스토리 로그 초기화"""
        self.lines = []
        self.last_story_key = None

    def render(self, surface, font, color, x: int, y: int, line_height: int = 25):
        """스토리 로그 렌더링 (draw 단계에서만 호출)"""
        for i, (text, _, _) in enumerate(self.lines):
            text_surface = font.render(text, True, color)
            surface.blit(text_surface, (x, y + i * line_height))

    def get_count(self) -> int:
        """현재 스토리 라인 수 반환"""
        return len(self.lines)


# 스토리 매니저 클래스
class StoryManager:
    """동적 텍스트 생성 시스템"""

    def __init__(self):
        # 시간/장소 리스트
        self.times_places = [
            "달빛이 흐린 산길",
            "안개가 자욱한 새벽",
            "해가 지는 저녁",
            "비가 내리는 산길",
            "바람이 거세게 부는 고개",
            "깊은 산속 오솔길",
            "돌무더기 사이",
            "나무 그늘 아래",
        ]

        # 적 외형 묘사
        self.enemy_descriptions = {
            "녹림 졸개": [
                "덩치 큰 녹림 졸개가",
                "더벅머리에 두건을 두른 도적이",
                "짐승 가죽을 걸친 녹림 졸개가",
                "거친 외모의 도적이",
            ],
            "녹림 행동대장": [
                "호피를 걸친 행동대장이",
                "위압적인 기운을 풍기는 행동대장이",
                "큰 칼을 든 행동대장이",
                "눈빛이 날카로운 행동대장이",
            ],
            "녹림왕": [
                "녹림왕이",
                "위엄 있는 녹림왕이",
                "산 전체를 압도하는 녹림왕이",
                "깊은 무공을 지닌 녹림왕이",
            ],
        }

        # 적 도발/행동
        self.enemy_actions = {
            "녹림 졸개": [
                "흉한 미소를 지으며 앞을 막아섰다.",
                "'통행세를 내놔라!' 큰 소리로 외쳤다.",
                "도끼를 휘두르며 위협했다.",
                "'가진 걸 다 내놓으면 목숨만은 살려주마!'",
                "크하하하 웃으며 길을 막았다.",
            ],
            "녹림 행동대장": [
                "'내 부하들을 건드렸군.' 차갑게 말했다.",
                "큰 칼을 뽑으며 앞으로 나섰다.",
                "'가진 걸 다 내놓으면 목숨만은 살려주마!'",
                "위압적인 기운을 뿜어내며 막아섰다.",
            ],
            "녹림왕": [
                "'이 산은 내 땅이다. 지나가려면 목숨을 내놓아라!'",
                "깊은 목소리로 말하며 앞을 막아섰다.",
                "산 전체를 진동시키는 기운을 발산했다.",
                "위엄 있는 자세로 당신을 응시했다.",
            ],
        }

        # 무공 텍스트
        self.card_descriptions = {
            "육합권": [
                "검끝이 뱀처럼 휘어지며 적의 빈틈을 파고들었다!",
                "직선으로 뻗은 검기가 공기를 갈랐다!",
                "삼재검법의 기본 자세로 적을 공격했다!",
                "검을 휘둘러 적의 방어를 뚫었다!",
            ],
            "복호장": [
                "호랑이가 울부짖는 듯한 장력이 터져나갔다!",
                "묵직한 손바닥이 적의 가슴을 강타했다!",
                "강력한 기운이 손바닥에서 폭발했다!",
                "적의 방어를 완전히 무너뜨렸다!",
            ],
            "삼재공": [
                "단전의 기를 끌어올려 몸을 보호한다.",
                "발놀림을 가볍게 하여 적의 공격을 흘려낸다.",
                "내공을 순환시켜 기력을 회복한다.",
                "심법을 운용하여 방어력을 높인다.",
            ],
            "포천삼": [
                "단전의 기를 끌어올려 몸을 보호한다.",
                "발놀림을 가볍게 하여 적의 공격을 흘려낸다.",
                "내공을 순환시켜 방어력을 높인다.",
                "기운을 몸 주변에 감싸 방어막을 만든다.",
            ],
            "유운지": [
                "적의 기운을 흐트러뜨리는 기법을 사용했다!",
                "약화의 기운이 적을 감싸 공격력을 떨어뜨렸다!",
                "적의 무공을 억제하는 기법을 발동했다!",
                "적의 기운이 흐려지는 것을 느낄 수 있다!",
            ],
        }

    def generate_encounter(self, enemy_name: str) -> str:
        """랜덤 인카운터 텍스트 생성"""
        time_place = random.choice(self.times_places)
        enemy_desc = random.choice(
            self.enemy_descriptions.get(enemy_name, [f"{enemy_name}이(가)"])
        )
        enemy_action = random.choice(
            self.enemy_actions.get(enemy_name, ["앞을 막아섰다."])
        )

        return f"{time_place}, {enemy_desc} {enemy_action}"

    def generate_card_description(self, card_name: str) -> str:
        """카드 사용 시 무공 텍스트 생성"""
        descriptions = self.card_descriptions.get(
            card_name, [f"{card_name}을(를) 사용했다."]
        )
        return random.choice(descriptions)


# 카드 클래스
class Card:
    """게임에서 사용하는 카드를 나타내는 클래스"""

    def __init__(
        self,
        name: str,
        card_type: CardType,
        energy_cost: int,
        description: str,
        effect_func=None,
    ):
        self.name = name
        self.type = card_type
        self.energy_cost = energy_cost
        self.description = description
        self.effect_func = effect_func  # 카드 효과를 실행하는 함수

    def can_use(self, player_energy: int) -> bool:
        """플레이어가 이 카드를 사용할 수 있는지 확인"""
        return player_energy >= self.energy_cost

    def use(self, player, enemy):
        """카드를 사용하고 효과를 적용"""
        if not self.can_use(player.energy):
            return False, "행동력 부족!"

        player.energy -= self.energy_cost

        if self.effect_func:
            result = self.effect_func(player, enemy, self)
            return True, result

        return True, f"{self.name} 사용!"


# 카드 레지스트리 (전역 카드 데이터베이스)
CARD_REGISTRY: Dict[str, Card] = {}


def register_card(card: Card):
    """카드를 레지스트리에 등록"""
    CARD_REGISTRY[card.name] = card


def get_card_by_id(card_id: str) -> Optional[Card]:
    """카드 ID로 Card 객체 가져오기"""
    return CARD_REGISTRY.get(card_id)


# 플레이어 클래스
class Player:
    """탱커 스타일의 주인공"""

    def __init__(self):
        self.max_hp = 100
        self.hp = 100
        self.defense = 0
        self.attack_power = 0  # 기본 공격력 (카드로 공격하므로 기본값은 0)
        self.max_energy = 5
        self.energy = 5
        self.name = "무인"
        # 덱 빌더 시스템: ID 기반 관리
        self.collection = []  # 보유한 모든 카드 ID (list[str])
        self.deck = []  # 실제 전투에 들고 갈 카드 ID (list[str], 최대 10장)
        self.last_rewards = []  # 방금 획득해서 아직 확인 안 한 카드 ID (list[str])
        # 전투 중 사용 (Card 객체)
        self.draw_pile = []  # 전투용 드로우 덱 (Card 객체)
        self.hand = []  # 현재 손에 든 카드 (Card 객체, 최대 5장)
        self.discard_pile = []  # 버린 카드 더미 (Card 객체)

    def take_damage(self, damage: int) -> int:
        """데미지를 받습니다. 방어도가 있으면 먼저 감소시킵니다."""
        actual_damage = max(0, damage - self.defense)
        self.hp = max(0, self.hp - actual_damage)
        return actual_damage

    def add_defense(self, amount: int):
        """방어도를 추가합니다."""
        self.defense += amount

    def restore_energy(self, amount: int):
        """행동력을 회복합니다."""
        self.energy = min(self.max_energy, self.energy + amount)

    def is_alive(self) -> bool:
        """생존 여부 확인"""
        return self.hp > 0

    def draw_card(self):
        """전투용 draw_pile에서 카드를 한 장 뽑습니다."""
        if len(self.draw_pile) == 0:
            # 버린 카드를 다시 섞어서 덱으로
            if len(self.discard_pile) > 0:
                self.draw_pile = self.discard_pile.copy()
                self.discard_pile = []
                random.shuffle(self.draw_pile)
            else:
                return None

        if len(self.draw_pile) > 0:
            card = self.draw_pile.pop(0)
            if len(self.hand) < 5:
                self.hand.append(card)
                return card
            else:
                # 손패가 가득 차면 버린 카드 더미로
                self.discard_pile.append(card)
                return None
        return None

    def discard_card(self, card: Card):
        """카드를 버린 카드 더미로 보냅니다."""
        if card in self.hand:
            self.hand.remove(card)
            self.discard_pile.append(card)

    def start_turn(self):
        """턴 시작 시 행동력을 회복하고 카드를 뽑습니다."""
        self.energy = self.max_energy
        # 손패가 5장 미만이면 카드 뽑기 (전투용 draw_pile 사용)
        while len(self.hand) < 5 and len(self.draw_pile) + len(self.discard_pile) > 0:
            self.draw_card()


# 적 클래스 (기본)
class Enemy:
    """적의 기본 클래스 (상속용)"""

    def __init__(self, name: str, max_hp: int, attack_power: int):
        self.name = name
        self.max_hp = max_hp
        self.hp = max_hp
        self.attack_power = attack_power
        self.attack_debuff = 0  # 공격력 감소 (유운지 효과)
        self.description = ""

    def attack(self, player: Player) -> Tuple[int, str]:
        """플레이어를 공격합니다."""
        damage = max(1, self.attack_power - self.attack_debuff)
        actual_damage = player.take_damage(damage)
        self.attack_debuff = max(0, self.attack_debuff - 1)  # 디버프 감소

        weapon = random.choice(["도끼", "철퇴", "대도"])

        # 체력 상태에 따른 메시지 다양화
        hp_ratio = player.hp / player.max_hp if player.max_hp > 0 else 0

        if hp_ratio > 0.7:  # 체력 70% 이상
            messages = [
                f"{self.name}이(가) {weapon}로 공격했다. 옷자락만 스쳤다. ({actual_damage} 데미지)",
                f"{self.name}의 {weapon} 공격. 가볍게 막아냈다. ({actual_damage} 데미지)",
                f"{self.name}이(가) {weapon}를 휘둘렀다. 가소로운 공격이다. ({actual_damage} 데미지)",
            ]
        elif hp_ratio > 0.3:  # 체력 30-70%
            messages = [
                f"{self.name}이(가) {weapon}로 공격! ({actual_damage} 데미지)",
                f"{self.name}의 {weapon} 공격이 명중했다. ({actual_damage} 데미지)",
                f"{self.name}이(가) {weapon}를 휘둘렀다. 상처를 입었다. ({actual_damage} 데미지)",
            ]
        else:  # 체력 30% 이하
            messages = [
                f"{self.name}이(가) {weapon}로 강타했다! 피가 시야를 가린다. ({actual_damage} 데미지)",
                f"{self.name}의 {weapon} 공격이 깊이 박혔다. 하지만 검을 놓지 않는다. ({actual_damage} 데미지)",
                f"{self.name}이(가) {weapon}로 내리쳤다. 몸이 흔들리지만 버틴다. ({actual_damage} 데미지)",
            ]

        message = random.choice(messages)
        return actual_damage, message

    def take_damage(self, damage: int) -> int:
        """데미지를 받습니다."""
        self.hp = max(0, self.hp - damage)
        return damage

    def is_alive(self) -> bool:
        """생존 여부 확인"""
        return self.hp > 0

    def get_action(self, player: Player) -> Tuple[str, int]:
        """AI 행동 결정 (기본: 공격만)"""
        return "attack", self.attack_power


# 녹림 졸개 (잡몹)
class Minion(Enemy):
    """녹림의 일반 졸개"""

    def __init__(self):
        super().__init__("녹림 졸개", 30, 5)
        self.description = "녹림의 일반 도적. 힘과 숫자로 밀어붙인다."
        self.encounter_story = "산길을 걷던 중, 녹림 졸개들이 길을 막고 서 있다. '통행세를 내놔라!' 그들은 큰 소리로 외친다. 말로 해결하려 했지만, 졸개들은 당신을 죽이고 빼앗겠다며 싸움을 시작했다."


# 녹림 행동대장 (초반 보스)
class Elite(Enemy):
    """녹림의 행동대장"""

    def __init__(self):
        super().__init__("녹림 행동대장", 60, 10)
        self.description = "녹림의 행동대장. 가끔 강한 기술을 사용한다."
        self.encounter_story = "졸개들을 물리치고 나아가던 중, 호피를 걸친 행동대장이 나타났다. '내 부하들을 건드렸군. 가진 걸 다 내놓으면 목숨만은 살려주마!' 하지만 당신은 거절했다. 행동대장은 크하하하 웃으며 무기를 휘둘렀다."
        self.special_attack_cooldown = 0

    def get_action(self, player: Player) -> Tuple[str, int]:
        """행동대장은 가끔 강공을 사용"""
        if self.special_attack_cooldown <= 0 and random.random() < 0.3:
            self.special_attack_cooldown = 2
            return "special_attack", self.attack_power * 2
        else:
            self.special_attack_cooldown = max(0, self.special_attack_cooldown - 1)
            return "attack", self.attack_power


# 녹림왕 (최종 보스)
class Boss(Enemy):
    """녹림왕 - 챕터 보스"""

    def __init__(self):
        super().__init__("녹림왕", 120, 15)
        self.description = "녹림의 두목. 강력한 무공을 보유하고 있다."
        self.encounter_story = "산길의 깊은 곳, 녹림왕이 당신의 앞을 막아섰다. '이 산은 내 땅이다. 지나가려면 목숨을 내놓아라!' 녹림왕의 위압감이 산 전체를 압도한다. 하지만 당신은 멈추지 않는다."
        self.special_attack_cooldown = 0

    def get_action(self, player: Player) -> Tuple[str, int]:
        """녹림왕은 강력한 필살기를 사용"""
        if self.special_attack_cooldown <= 0 and random.random() < 0.4:
            self.special_attack_cooldown = 3
            return "ultimate_attack", self.attack_power * 3
        elif random.random() < 0.3:
            return "attack", self.attack_power
        else:
            return "attack", self.attack_power


# 카드 효과 함수들
def effect_samjae_gong(player: Player, enemy: Enemy, card: Card) -> str:
    """삼재공: 행동력 회복 또는 방어도 소량 증가"""
    if random.random() < 0.5:
        player.restore_energy(3)
        return "삼재공으로 행동력을 회복했다!"
    else:
        player.add_defense(3)
        return "삼재공으로 방어도가 증가했다!"


def effect_yukhap_gwon(player: Player, enemy: Enemy, card: Card) -> str:
    """육합권: 기본 공격"""
    damage = random.randint(8, 12)
    actual_damage = enemy.take_damage(damage)
    return f"육합권으로 {actual_damage} 데미지를 입혔다!"


def effect_bokho_jang(player: Player, enemy: Enemy, card: Card) -> str:
    """복호장: 강한 공격"""
    damage = random.randint(18, 25)
    actual_damage = enemy.take_damage(damage)
    return f"복호장으로 {actual_damage} 데미지를 입혔다!"


def effect_pocheon_sam(player: Player, enemy: Enemy, card: Card) -> str:
    """포천삼: 높은 방어도 획득"""
    defense = random.randint(8, 12)
    player.add_defense(defense)
    return f"포천삼으로 방어도 {defense}를 획득했다!"


def effect_yuun_ji(player: Player, enemy: Enemy, card: Card) -> str:
    """유운지: 적의 공격력을 다음 턴에 약화"""
    enemy.attack_debuff = 5
    return f"유운지로 {enemy.name}의 공격력이 약화되었다!"


# 게임 메인 클래스
class Game:
    """메인 게임 클래스"""

    def __init__(self):
        # 폰트 초기화 (가장 먼저)
        init_fonts()

        self.screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
        pygame.display.set_caption("구운록 (Guunrok)")
        self.clock = pygame.time.Clock()
        self.running = True

        # 게임 상태 (State Machine) - 디버깅 시스템 통합
        self.player = Player()
        self.enemy = None
        self.turn = 0
        self.state = GameState.BATTLE  # 현재 상태 (GameState Enum)
        self.prev_phase = None  # 이전 phase (None-safe 처리 필요)
        # phase는 set_phase()로 초기화 (prev_phase가 None으로 유지됨)
        self.phase = None  # 임시 초기화
        self.phase_enter_id = 0  # phase 진입 ID (진입 1회 보장)
        self.phase_enter_ms = now_ms()  # phase 진입 시간 (ms)
        self.prev_state = None  # 이전 상태
        self.state_enter_time = now_ms()  # 상태 진입 시간 (ms)
        self.state_payload = {}  # 상태별 페이로드 (victory_text, rewards 등)
        self.selected_card_index = None
        self.phase_enter_id = 0  # phase 진입 ID (진입 1회 보장)
        self.phase_enter_ms = now_ms()  # phase 진입 시간 (ms)

        # 로그 시스템 (deque로 변경)
        self.story_lines = deque(maxlen=5)  # 스토리 라인 (최대 5줄)
        self.log_lines = deque(maxlen=40)  # 전투 로그 (최대 40줄)
        self.battle_log = list(self.log_lines)  # 하위 호환성
        self.event_log = []  # 구조화된 이벤트 로그 (최대 1000개)
        self.story_log = StoryLog(max_lines=6)  # 스토리 로그 (프레임마다 누적 방지)
        self.story_narration = []  # 하위 호환성 (제거 예정)

        self.enemy_level = 1  # 적 난이도 레벨 (전투 승리마다 증가)
        self.state_enter_id = 1  # 상태 진입 ID (진입 1회 보장, 0이 아닌 값으로 시작)
        self.battle_resolved = False  # 전투 해결 플래그 (enemy_hp <= 0 처리 후 가드)

        # 모달 UI 영역
        self.victory_next_btn_rect = None  # 승리 화면 "다음 적" 버튼 hitbox
        self.modal_rect = None  # 모달 전체 hitbox
        self.encounter_index = 0  # 인카운터 인덱스 (0부터 시작)
        self.chapter = 1  # 챕터 번호
        self.defeated_counts = {"Minion": 0, "Elite": 0, "Boss": 0}  # 처치한 적 수
        self.xp = 0  # 경험치
        self.gold = 0  # 금전
        self.battle_summary = None  # 전투 요약
        self.rewards = None  # 보상
        self.story_manager = StoryManager()  # 스토리 매니저
        self.victory_message_shown = False  # 승리 메시지가 이미 표시되었는지
        self.defeat_message_shown = False  # 패배 메시지가 이미 표시되었는지
        self.cards_used_in_battle = []  # 전투 중 사용한 카드 목록
        self.training_menu_open = False  # 수련 메뉴 열림 여부

        # 디버깅 시스템
        self.debug_overlay_visible = True  # 디버그 오버레이 표시 여부
        self.debug_ui_bounds_visible = False  # UI 클릭 영역 표시 여부
        self.invariant_failures = []  # 불변조건 위반 목록
        self.ui_layers = {"hud": [], "panel": [], "modal": []}  # UI 레이어
        self.victory_panel_rendered = (
            False  # VICTORY 패널 렌더링 여부 (프레임마다 리셋)
        )

        # 스냅샷 디렉토리 생성
        self.snapshot_dir = "debug/snapshots"
        os.makedirs(self.snapshot_dir, exist_ok=True)

        # 디버그 로거 초기화
        self.logger = DebugLogger()
        self.logger.log(
            "INFO",
            "GAME_START",
            "게임 시작",
            {
                "seed": getattr(random, "_seed", None),
            "chapter": self.chapter,
                "encounter_index": self.encounter_index,
            },
        )

        # "한 번만 실행" 가드용 딕셔너리
        self._handled_enter_ids = (
            {}
        )  # {phase: enter_id} - 각 phase별 마지막 처리된 enter_id

        # UI 클릭 라우팅 레지스트리 (더블버퍼 시스템)
        self.ui_buttons_active = (
            {}
        )  # {button_id: {"rect": pygame.Rect, "layer": str, "enabled": bool, "on_click": callable, "priority": int}}
        self.ui_buttons_next = (
            {}
        )  # {button_id: {"rect": pygame.Rect, "layer": str, "enabled": bool, "on_click": callable, "priority": int}}
        self.button_registry = self.ui_buttons_active  # 하위 호환성 (active를 참조)
        self.last_ui_click = (
            None  # {"button_id": str, "timestamp_ms": int, "phase": str}
        )
        self.last_transition = (
            None  # {"from": str, "to": str, "reason": str, "timestamp_ms": int}
        )

        # 클릭 디바운스 (150ms 내 연속 클릭 무시)
        self.last_click_time = {}  # {button_id: timestamp_ms}
        self.click_cooldown_ms = 150

        # 마우스 hover 상태
        self.mouse_hover_button = None  # 현재 hover 중인 button_id

        # 클릭 처리 가드 (한 프레임 1클릭만 처리)
        self.frame_click_consumed = False  # 현재 프레임에서 클릭이 처리되었는지

        # 스토리 컨텍스트 (최근 10개)
        self.story_context = deque(maxlen=10)  # 최근 스토리 이벤트

        # 턴 진행 시스템 (단순화: 클릭 시 직접 phase 전환)
        self.transition_lock = False  # 전환 중 플래그 (버튼 비활성화)
        self.last_turn_end_click_at = None  # TURN_END 클릭 시간 (watchdog용)

        # 카드 덱 초기화
        self.initialize_deck()

        # 첫 번째 적 생성
        self.spawn_enemy()

        # 플레이어 턴 시작 (set_phase로 초기화)
        self.set_phase(PHASE_PLAYER_TURN, "게임 시작")
        self.player.start_turn()
        self.enter_state(GameState.BATTLE, "게임 시작")

    # ==================== 상태 전환 시스템 ====================
    def set_phase(self, new_phase: str, reason: str = ""):
        """phase를 안전하게 변경하는 setter (prev_phase 자동 추적, 로깅, 가드)"""
        prev_phase = getattr(self, "phase", None)

        # state_enter_id가 0이면 보정 (BATTLE/PLAYER_TURN 진입 금지 방지)
        if self.state_enter_id == 0:
            self.logger.log(
                "WARN",
                "BOOT_SEQUENCE",
                "state_enter_id가 0인 상태 감지, 1로 보정",
                {"prev_phase": prev_phase, "new_phase": new_phase},
            )
            self.state_enter_id = 1
            self.dump_snapshot("boot_sequence_fix")

        # CAMP/TRAINING/DECK 진입 시 enemy는 반드시 None이어야 함
        if new_phase in (PHASE_CAMP, PHASE_TRAINING, PHASE_DECK):
            if self.enemy is not None:
                self.logger.log(
                    "WARN",
                    "PHASE_TRANSITION",
                              f"CAMP/TRAINING 진입 시 enemy가 None이 아님 (강제 clear)",
                    {
                        "prev_phase": prev_phase,
                        "new_phase": new_phase,
                        "enemy_name": self.enemy.name if self.enemy else None,
                    },
                )
                self.enemy = None

        # prev_phase 저장
        self.prev_phase = prev_phase
        self.phase = new_phase
        self.phase_enter_ms = now_ms()
        self.phase_enter_id = getattr(self, "phase_enter_id", 0) + 1

        # 전투 phase 진입 시 전투 진입 훅 호출
        if new_phase == PHASE_PLAYER_TURN:
            self.on_enter_player_turn(self.phase_enter_id)
        elif new_phase == PHASE_ENEMY_TURN:
            self.on_enter_enemy_turn(self.phase_enter_id)

        # transition 로그 기록
        self.last_transition = {
            "from": prev_phase or "None",
            "to": new_phase,
            "reason": reason,
            "timestamp_ms": self.phase_enter_ms,
            "enter_id": self.phase_enter_id,
        }

        self.logger.log(
            "INFO",
            "PHASE_TRANSITION",
                       f"{prev_phase or 'None'} -> {new_phase}",
                       {
                           "reason": reason,
                           "enter_id": self.phase_enter_id,
                           "chapter": self.chapter,
                "encounter_index": self.encounter_index,
            },
        )

        # 기존 log_event도 호출 (하위 호환성)
        self.log_event(
            "PHASE",
            f"{prev_phase or 'None'}->{new_phase}",
            reason,
            {"enter_id": self.phase_enter_id},
        )

    def enter_state(
        self,
        new_state: GameState,
        reason: str = "",
        payload: Optional[Dict[str, Any]] = None,
    ):
        """상태 전환의 단일 진입점 (1회성 전환 보장)"""
        # 이미 같은 상태면 전환하지 않음 (중복 방지)
        if self.state == new_state:
            return

        prev_state = self.state
        current_time = now_ms()

        # 상태 진입 ID 증가 (진입 1회 보장)
        self.state_enter_id += 1
        enter_id = self.state_enter_id

        # 상태 변경
        self.prev_state = prev_state
        self.state = new_state
        self.state_enter_time = current_time
        self.state_payload = payload or {}

        # 상태 전환 시 스토리/로그 추가 (enter_state에서만 가능)
        if new_state == GameState.BATTLE and prev_state == GameState.WORLD:
            # 전투 시작
            if self.enemy:
                encounter_text = self.story_manager.generate_encounter(self.enemy.name)
                self.story_lines.append(encounter_text)
                self.log_lines.append(
                    f"[전투] {self.enemy.name}과(와) 전투가 시작되었다!"
                )
        elif new_state == GameState.VICTORY_PANEL:
            # 승리
            victory_story = "녹림 도적이 쓰러졌다."
            self.story_lines.append(victory_story)
            self.log_lines.append(
                f"[승리] {self.enemy.name if self.enemy else '적'}을(를) 물리쳤다!"
            )
        elif new_state == GameState.GAMEOVER:
            # 패배
            defeat_story = "여기서 멈추게 되었다."
            self.story_lines.append(defeat_story)
            self.log_lines.append("[패배] 무인이 쓰러졌다...")

        # 로그 이벤트 기록
        self.log_event(
            "STATE",
            f"{prev_state.value}->{new_state.value}",
            reason,
            {"enter_id": enter_id, "payload": payload or {}},
        )

        # 불변조건 검증
        self.validate_invariants()

    def transition(
        self, to_state: str, reason: str, payload: Optional[Dict[str, Any]] = None
    ):
        """하위 호환성을 위한 래퍼 (GameState로 변환)"""
        prev_state = self.phase  # 현재 phase를 prev_state로 저장

        # 문자열을 GameState로 변환
        if to_state == PHASE_VICTORY_PANEL:
            self.enter_state(GameState.VICTORY_PANEL, reason, payload)
        elif to_state == PHASE_DEFEAT_PANEL:
            self.enter_state(GameState.GAMEOVER, reason, payload)
        elif to_state == PHASE_WORLD:
            self.enter_state(GameState.WORLD, reason, payload)
        elif to_state == PHASE_PLAYER_TURN or to_state == PHASE_ENEMY_TURN:
            # BATTLE 내부 상태 변경 (set_phase가 전투 진입 훅을 호출함)
            self.set_phase(to_state, reason)
            if to_state == PHASE_PLAYER_TURN:
                self.state = GameState.BATTLE

        # 페이로드 요약 생성
        payload_summary = {}
        if payload:
            for key, value in payload.items():
                if isinstance(value, (str, int, float, bool)):
                    payload_summary[key] = value
                elif isinstance(value, dict):
                    payload_summary[key] = f"dict({len(value)} keys)"
                elif isinstance(value, list):
                    payload_summary[key] = f"list({len(value)} items)"
                else:
                    payload_summary[key] = str(type(value).__name__)

        # 상태 전환 로깅 (이벤트 로그에만 추가, battle_log에는 추가하지 않음)
        event_data = {
            "timestamp_ms": now_ms(),
            "state": to_state,
            "turn": self.turn,
            "encounter_index": self.encounter_index,
            "scope": "STATE",
            "message": f"{prev_state}->{to_state}",
            "reason": reason,
            "data": payload_summary,
        }
        self.event_log.append(event_data)
        if len(self.event_log) > 1000:
            self.event_log.pop(0)

        # battle_log에는 간단한 메시지만 추가 (중복 방지)
        if prev_state != to_state:  # 실제 상태 변경이 있을 때만
            log_text = f"[STATE] {prev_state} -> {to_state} ({reason})"
            if log_text not in self.battle_log[-5:]:  # 최근 5개에 없을 때만 추가
                self.battle_log.append(log_text)
                if len(self.battle_log) > 100:
                    self.battle_log.pop(0)

        # 불변조건 검증
        self.validate_invariants()

    # ==================== 디버깅 시스템: 로깅 ====================
    def log_event(
        self,
        scope: str,
        message: str,
        reason: str = "",
        data: Optional[Dict[str, Any]] = None,
    ):
        """구조화된 이벤트 로깅"""
        event = {
            "timestamp_ms": now_ms(),
            "state": self.phase,
            "turn": self.turn,
            "encounter_index": self.encounter_index,
            "scope": scope,
            "message": message,
            "reason": reason,
            "data": data or {},
        }

        self.event_log.append(event)

        # 최대 1000개 유지
        if len(self.event_log) > 1000:
            self.event_log.pop(0)

        # 파일 로그에도 기록 (DebugLogger 사용)
        level = "INFO"
        if scope in ("ERROR", "INVARIANT_FAIL", "EXCEPTION"):
            level = "ERROR"
        elif scope == "WARN":
            level = "WARN"
        log_data = {"reason": reason}
        if data:
            log_data.update(data)
        self.logger.log(level, scope, message, log_data)

        # 기존 battle_log에도 추가 (하위 호환성)
        log_text = f"[{scope}] {message}"
        if reason:
            log_text += f" ({reason})"
        self.battle_log.append(log_text)
        if len(self.battle_log) > 100:
            self.battle_log.pop(0)

    # ==================== 디버깅 시스템: 불변조건 검증 ====================
    def validate_invariants(self):
        """불변조건 검증"""
        self.invariant_failures = []

        # 1. BATTLE 상태에서 적 HP 체크 (불변조건)
        if self.phase in (PHASE_PLAYER_TURN, PHASE_ENEMY_TURN):
            if self.enemy is None:
                self.logger.log(
                    "CRITICAL",
                    "INVARIANT_FAIL",
                    "phase가 PLAYER_TURN/ENEMY_TURN인데 enemy==None",
                    {
                        "phase": self.phase,
                        "state": self.state.value if hasattr(self.state, 'value') else str(self.state),
                        "state_enter_id": self.state_enter_id,
                    },
                )
                self.dump_snapshot("invariant_enemy_none")
                self.invariant_failures.append(
                    {
                        "condition": "BATTLE phase에서 enemy != None",
                        "actual": "enemy = None",
                        "fix": "즉시 전투 종료 또는 적 재생성",
                    }
                )
            elif self.enemy.hp <= 0:
                self.logger.log(
                    "CRITICAL",
                    "INVARIANT_FAIL",
                    "enemy.hp<=0이면서 phase가 BATTLE 계열",
                    {
                        "phase": self.phase,
                        "enemy_hp": self.enemy.hp,
                        "battle_resolved": self.battle_resolved,
                        "state_enter_id": self.state_enter_id,
                    },
                )
                self.dump_snapshot("invariant_enemy_dead")
                # 즉시 set_phase(VICTORY_PANEL) 강제 전환
                self.set_phase(PHASE_VICTORY_PANEL, "invariant_force")
                self.battle_resolved = True
                # on_victory()가 아직 호출되지 않았으면 호출
                if self._handled_enter_ids.get("on_victory") != self.phase_enter_id:
                    self.on_victory()
                self.invariant_failures.append(
                    {
                    "condition": "BATTLE 상태에서 enemy.hp > 0",
                    "actual": f"enemy.hp = {self.enemy.hp}",
                        "fix": "즉시 VICTORY_PANEL로 전환 (강제 전환 완료)",
                    }
                )

    def ensure_battle_ready(self):
        """Battle Ready Invariant 검증 및 자동 복구"""
        if self.phase not in (PHASE_PLAYER_TURN, PHASE_ENEMY_TURN):
            return  # 전투 phase가 아니면 검증하지 않음

        repairs = []

        # 1. enemy != None 체크
        if self.enemy is None:
            repairs.append("enemy is None")
            self.logger.log(
                "WARN",
                "INVARIANT_REPAIR",
                "전투 phase에서 enemy가 None, 복구 불가",
                {"phase": self.phase, "state_enter_id": self.state_enter_id},
            )
            self.dump_snapshot("invariant_repair_failed")
            return

        # 2. deck not empty 체크 (draw_pile + discard_pile)
        total_cards = len(self.player.draw_pile) + len(self.player.discard_pile)
        if total_cards == 0:
            repairs.append("deck empty")
            # 최소복구: starter deck 재구성
            starter_cards = ["삼재공", "육합권", "포천삼"]
            self.player.draw_pile = []
            for card_id in starter_cards:
                card = get_card_by_id(card_id)
                if card:
                    self.player.draw_pile.append(card)
                    self.player.draw_pile.append(card)  # 2장씩
            random.shuffle(self.player.draw_pile)
            self.logger.log(
                "WARN",
                "INVARIANT_REPAIR",
                "덱이 비어있어 starter deck 재구성",
                {"phase": self.phase, "state_enter_id": self.state_enter_id},
            )

        # 3. hand not empty 체크
        if len(self.player.hand) == 0:
            repairs.append("hand empty")
            # 최소복구: 즉시 draw_hand(5장)
            while len(self.player.hand) < 5 and (len(self.player.draw_pile) + len(self.player.discard_pile) > 0):
                self.player.draw_card()
            self.logger.log(
                "WARN",
                "INVARIANT_REPAIR",
                "손패가 비어있어 5장 드로우",
                {"phase": self.phase, "state_enter_id": self.state_enter_id, "hand_size": len(self.player.hand)},
            )

        # 4. battle_resolved False 체크
        if self.battle_resolved and self.enemy and self.enemy.hp > 0:
            repairs.append("battle_resolved True but enemy alive")
            self.battle_resolved = False
            self.logger.log(
                "WARN",
                "INVARIANT_REPAIR",
                "battle_resolved가 True지만 적이 살아있어 False로 복구",
                {"phase": self.phase, "state_enter_id": self.state_enter_id},
            )

        # 5. 로그가 비어있으면 강제 추가
        if len(self.log_lines) == 0:
            repairs.append("log empty")
            self.log_lines.append("[전투] 전투가 시작되었다!")
            self.battle_log.append("[전투] 전투가 시작되었다!")
            self.logger.log(
                "WARN",
                "INVARIANT_REPAIR",
                "로그가 비어있어 '전투 시작' 메시지 강제 추가",
                {"phase": self.phase, "state_enter_id": self.state_enter_id},
            )

        # 복구가 발생했으면 로그 및 스냅샷
        if repairs:
            self.log_event(
                "INVARIANT_REPAIR",
                f"전투 준비 불변조건 복구: {', '.join(repairs)}",
                "",
                {
                    "repairs": repairs,
                    "phase": self.phase,
                    "state_enter_id": self.state_enter_id,
                    "hand_size": len(self.player.hand),
                    "deck_size": len(self.player.draw_pile) + len(self.player.discard_pile),
                },
            )
            self.dump_snapshot("invariant_repair")

        # 복구 후에도 실패하면 handle_error로 보내기
        if len(self.player.hand) == 0 or (len(self.player.draw_pile) + len(self.player.discard_pile) == 0):
            error_msg = f"전투 준비 복구 실패: hand={len(self.player.hand)}, deck={len(self.player.draw_pile) + len(self.player.discard_pile)}"
            self.logger.log(
                "ERROR",
                "INVARIANT_REPAIR_FAILED",
                error_msg,
                {
                    "phase": self.phase,
                    "state_enter_id": self.state_enter_id,
                    "hand_size": len(self.player.hand),
                    "deck_size": len(self.player.draw_pile) + len(self.player.discard_pile),
                },
            )
            self.dump_snapshot("invariant_repair_failed")
            # handle_error는 예외가 필요하므로 여기서는 로그만 남김

    def on_enter_player_turn(self, enter_id: int):
        """플레이어 턴 진입 훅 (1회만 실행, 절대 누락되지 않게)"""
        # 중복 실행 방지
        if self._handled_enter_ids.get("on_enter_player_turn") == enter_id:
            return

        # 처리 완료 표시
        self._handled_enter_ids["on_enter_player_turn"] = enter_id

        # 핸드 딜 (손패가 비어있으면 5장 드로우)
        if len(self.player.hand) == 0:
            self.player.start_turn()

        # 로그 초기화 (비어있으면 강제 추가)
        if len(self.log_lines) == 0:
            self.log_lines.append("[전투] 전투가 시작되었다!")
            self.battle_log.append("[전투] 전투가 시작되었다!")

        # 스토리 라인 초기화 (비어있으면 인카운터 텍스트 추가)
        if len(self.story_lines) == 0 and self.enemy:
            encounter_text = self.story_manager.generate_encounter(self.enemy.name)
            self.story_lines.append(encounter_text)

        self.logger.log(
            "INFO",
            "BATTLE_ENTER",
            f"플레이어 턴 진입 (enter_id={enter_id})",
            {
                "enter_id": enter_id,
                "hand_size": len(self.player.hand),
                "deck_size": len(self.player.draw_pile) + len(self.player.discard_pile),
                "log_lines_count": len(self.log_lines),
            },
        )

    def on_enter_enemy_turn(self, enter_id: int):
        """적 턴 진입 훅 (1회만 실행)"""
        # 중복 실행 방지
        if self._handled_enter_ids.get("on_enter_enemy_turn") == enter_id:
            return

        # 처리 완료 표시
        self._handled_enter_ids["on_enter_enemy_turn"] = enter_id

        self.logger.log(
            "INFO",
            "BATTLE_ENTER",
            f"적 턴 진입 (enter_id={enter_id})",
            {"enter_id": enter_id},
        )

        # 2. VICTORY_PANEL 상태에서 필수 페이로드 체크
        if self.phase == PHASE_VICTORY_PANEL:
            if "victory_text" not in self.state_payload:
                self.invariant_failures.append(
                    {
                    "condition": "VICTORY_PANEL에서 state_payload['victory_text'] 존재",
                    "actual": "victory_text 없음",
                        "fix": "transition() 호출 시 victory_text를 payload에 포함",
                    }
                )
            if "rewards" not in self.state_payload:
                self.invariant_failures.append(
                    {
                    "condition": "VICTORY_PANEL에서 state_payload['rewards'] 존재",
                    "actual": "rewards 없음",
                        "fix": "transition() 호출 시 rewards를 payload에 포함",
                    }
                )

        # 3. 불변조건 위반 시 로깅 및 스냅샷
        if self.invariant_failures:
            for failure in self.invariant_failures:
                self.log_event(
                    "INVARIANT_FAIL",
                    failure["condition"],
                    f"실제: {failure['actual']}, 수정: {failure['fix']}",
                    failure,
                )
            self.dump_snapshot("invariant_fail")

    def validate_invariants_strict(self):
        """불변조건 엄격 검증 (즉시 실패 로그, 자동복구)"""
        # enemy.hp<=0이면서 phase가 BATTLE 계열이면 즉시 실패
        if self.phase in (PHASE_PLAYER_TURN, PHASE_ENEMY_TURN):
            if self.enemy is None:
                self.logger.log(
                    "CRITICAL",
                    "INVARIANT_FAIL",
                    "phase가 PLAYER_TURN/ENEMY_TURN인데 enemy==None",
                    {
                        "phase": self.phase,
                        "state": self.state.value if hasattr(self.state, 'value') else str(self.state),
                        "state_enter_id": self.state_enter_id,
                        "battle_resolved": self.battle_resolved,
                        "active_buttons": list(self.ui_buttons_active.keys()),
                    },
                )
                self.dump_snapshot("invariant_enemy_none")
            elif self.enemy.hp <= 0:
                self.logger.log(
                    "CRITICAL",
                    "INVARIANT_FAIL",
                    "enemy.hp<=0이면서 phase가 BATTLE 계열",
                    {
                        "phase": self.phase,
                        "enemy_hp": self.enemy.hp,
                        "battle_resolved": self.battle_resolved,
                        "state_enter_id": self.state_enter_id,
                        "active_buttons": list(self.ui_buttons_active.keys()),
                    },
                )
                self.dump_snapshot("invariant_enemy_dead")
                # 즉시 set_phase(VICTORY_PANEL) 강제 전환
                self.set_phase(PHASE_VICTORY_PANEL, "invariant_force")
                self.battle_resolved = True
                # on_victory()가 아직 호출되지 않았으면 호출
                if self._handled_enter_ids.get("on_victory") != self.phase_enter_id:
                    self.on_victory()

    # ==================== 디버깅 시스템: 스냅샷 ====================
    def snapshot_state(self) -> Dict[str, Any]:
        """현재 게임 상태를 딕셔너리로 반환 (스냅샷용)"""
        # 적 정보 수집
        enemy_info = None
        if self.enemy:
            enemy_rank = "Minion"
            if isinstance(self.enemy, Boss):
                enemy_rank = "Boss"
            elif isinstance(self.enemy, Elite):
                enemy_rank = "Elite"
            enemy_info = {
                "exists": True,
                "name": self.enemy.name,
                "hp": self.enemy.hp,
                "max_hp": self.enemy.max_hp,
                "attack_power": self.enemy.attack_power,
                "defense": getattr(self.enemy, "defense", 0),
                "rank": enemy_rank,
            }
        else:
            enemy_info = {"exists": False}

        # UI 버튼 레지스트리 수집 (active 기준)
        ui_buttons = []
        for button_id, btn_info in self.ui_buttons_active.items():
            rect = btn_info.get("rect")
            if rect:
                ui_buttons.append(
                    {
                    "button_id": button_id,
                    "layer": btn_info.get("layer", "unknown"),
                    "rect": {
                        "x": rect.x,
                        "y": rect.y,
                        "width": rect.width,
                            "height": rect.height,
                        },
                        "enabled": btn_info.get("enabled", True),
                        "priority": btn_info.get("priority", 0),
                    }
                )

        return {
            "timestamp_ms": now_ms(),
            "timestamp": datetime.now().isoformat(),
            "phase": self.phase,
            "prev_phase": self.prev_phase,
            "state": (
                self.state.value if hasattr(self.state, "value") else str(self.state)
            ),
            "prev_state": (
                self.prev_state.value
                if self.prev_state and hasattr(self.prev_state, "value")
                else (str(self.prev_state) if self.prev_state else None)
            ),
            "chapter": self.chapter,
            "encounter_index": self.encounter_index,
            "turn": self.turn,
            "phase_enter_id": self.phase_enter_id,
            "state_enter_id": self.state_enter_id,
            "player": {
                "hp": self.player.hp,
                "max_hp": self.player.max_hp,
                "defense": self.player.defense,
                "energy": self.player.energy,
                "max_energy": self.player.max_energy,
                "xp": self.xp,
                "gold": self.gold,
                "collection_size": len(self.player.collection),
                "deck_size": len(self.player.deck),
                "last_rewards_count": len(self.player.last_rewards),
                "hand_size": len(self.player.hand),
                "discard_size": len(self.player.discard_pile),
            },
            "enemy": enemy_info,
            "story_context": list(self.story_context),
            "last_ui_click": self.last_ui_click,
            "last_transition": self.last_transition,
            "ui_buttons": ui_buttons,
            "recent_logs_count": len(self.event_log),
            # 불변조건 검증용 정보
            "enemy_hp": self.enemy.hp if self.enemy else None,
            "battle_resolved": self.battle_resolved,
            "active_buttons": ui_buttons,
            "enemy_exists": self.enemy is not None,
            "button_registry": {
                "button_ids": list(self.ui_buttons_active.keys()),
                "buttons": [
                    {
                        "id": bid,
                        "enabled": binfo.get("enabled", True),
                        "layer": binfo.get("layer", "unknown"),
                    }
                    for bid, binfo in self.ui_buttons_active.items()
                ],
            },
            "_handled_enter_ids": dict(self._handled_enter_ids),
        }

    def dump_snapshot(self, tag: str):
        """게임 상태 스냅샷 저장 (파일)"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
        filename = f"{self.snapshot_dir}/snap_{timestamp}_{tag}.json"

        # snapshot_state() 사용
        snapshot = self.snapshot_state()
        snapshot["tag"] = tag
        snapshot["state_payload"] = self.state_payload
        snapshot["state_enter_time"] = self.state_enter_time
        snapshot["ui_layers"] = {k: len(v) for k, v in self.ui_layers.items()}
        snapshot["logs"] = {
            "recent_events": self.event_log[-100:],
            "recent_battle_log": self.battle_log[-100:],
            "recent_debug_logs": self.logger.get_recent_logs(100),
        }
        snapshot["invariant_failures"] = self.invariant_failures

        try:
            with open(filename, "w", encoding="utf-8") as f:
                json.dump(snapshot, f, ensure_ascii=False, indent=2)
            self.log_event("SNAPSHOT", f"스냅샷 저장: {filename}", tag)
        except Exception as e:
            self.log_event("ERROR", f"스냅샷 저장 실패: {str(e)}", tag)

    def initialize_deck(self):
        """플레이어의 덱을 초기화합니다."""
        # 카드 생성 및 레지스트리 등록
        card_definitions = [
            ("삼재공", CardType.SKILL, 1, "행동력 3 회복 또는 방어도 3 증가", effect_samjae_gong),
            ("육합권", CardType.ATTACK, 2, "기본 공격으로 8-12 데미지", effect_yukhap_gwon),
            ("복호장", CardType.ATTACK, 4, "강력한 공격으로 18-25 데미지", effect_bokho_jang),
            ("포천삼", CardType.DEFENSE, 2, "방어도 8-12 획득", effect_pocheon_sam),
            ("유운지", CardType.DEBUFF, 3, "적의 공격력을 5 감소시킴", effect_yuun_ji),
        ]

        # 카드 레지스트리에 등록
        for name, card_type, cost, desc, effect in card_definitions:
            if name not in CARD_REGISTRY:
                card = Card(name, card_type, cost, desc, effect)
                register_card(card)

        # 초기 컬렉션 및 덱 설정 (각 카드 2장씩, 총 10장)
        self.player.collection = []
        self.player.deck = []
        self.player.last_rewards = []

        for name, _, _, _, _ in card_definitions:
            for _ in range(2):
                self.player.collection.append(name)
                self.player.deck.append(name)

    def generate_enemy(self, encounter_index: int, chapter: int):
        """encounter_index와 chapter에 따라 적을 생성합니다."""
        # 스폰 룰: 0~2: 졸개, 3~4: 행동대장, 5: 녹림왕
        if encounter_index <= 2:
            enemy_class = Minion
            enemy_rank = "Minion"
        elif encounter_index <= 4:
            enemy_class = Elite
            enemy_rank = "Elite"
        else:  # encounter_index == 5
            enemy_class = Boss
            enemy_rank = "Boss"

        # 적 생성
        self.enemy = enemy_class()

        # 챕터에 따른 난이도 스케일 (챕터마다 HP와 공격력 증가)
        if chapter > 1:
            chapter_multiplier = 1.0 + (chapter - 1) * 0.15  # 챕터당 15% 증가
            self.enemy.max_hp = int(self.enemy.max_hp * chapter_multiplier)
            self.enemy.hp = self.enemy.max_hp
            self.enemy.attack_power = int(self.enemy.attack_power * chapter_multiplier)

        return enemy_rank

    def spawn_enemy(self):
        """새로운 적을 생성합니다. (초기 스폰용)"""
        # 첫 번째 적은 항상 졸개
        self.encounter_index = 0
        enemy_rank = self.generate_enemy(self.encounter_index, self.chapter)

        # 동적 인카운터 텍스트 생성
        encounter_text = self.story_manager.generate_encounter(self.enemy.name)
        self.add_log(encounter_text, "story")

        self.add_log(
            f"[전투] {self.enemy.name}과(와) 전투가 시작되었다! (챕터 {self.chapter}, 인카운터 {self.encounter_index})",
            "system",
        )

    def get_primary_action(self):
        """현재 phase에 따른 Primary Action 버튼 정보 반환"""
        button_x = SCREEN_WIDTH - 150
        button_y = SCREEN_HEIGHT - 50
        button_width = 120
        button_height = 40
        button_rect = pygame.Rect(button_x, button_y, button_width, button_height)

        if self.phase == PHASE_PLAYER_TURN:
            # transition_lock이 True면 버튼 비활성화
            enabled = not self.transition_lock
            return {
                "label": "턴 종료",
                "on_click": lambda: self.request_end_turn(),
                "enabled": enabled,
                "color": COLOR_DARK_GREEN,
                "rect": button_rect,
            }
        elif self.phase == PHASE_VICTORY_PANEL:
            return {
                "label": "다음 적",
                "on_click": self.start_next_encounter,
                "enabled": True,
                "color": COLOR_DARK_GREEN,
                "rect": button_rect,
            }
        elif self.phase == PHASE_DEFEAT_PANEL:
            return {
                "label": "재시도",
                "on_click": self.reset_game,
                "enabled": True,
                "color": COLOR_DARK_RED,
                "rect": button_rect,
            }
        elif self.phase == PHASE_WORLD:
            return {
                "label": "전투 시작",
                "on_click": self.start_battle,
                "enabled": True,
                "color": COLOR_DARK_GREEN,
                "rect": button_rect,
            }
        else:  # BATTLE 상태의 ENEMY_TURN 또는 기타
            return {
                "label": "(비활성) 적 턴",
                "on_click": None,
                "enabled": False,
                "color": COLOR_DARK_GRAY,
                "rect": button_rect,
            }

    def start_battle(self):
        """전투 시작 (CAMP/WORLD에서 전투로 이동)"""
        # CAMP 또는 WORLD 상태에서만 전투 시작 가능
        if (
            self.phase not in (PHASE_CAMP, PHASE_WORLD)
            and self.state != GameState.WORLD
        ):
            self.log_event(
                "ERROR",
                "start_battle 호출 실패",
                f"잘못된 phase: {self.phase}, state: {self.state}",
                {},
            )
            return

        # battle_resolved 플래그 초기화
        self.battle_resolved = False

        # 전투 초기화
        self.cards_used_in_battle = []
        self.battle_summary = None
        self.rewards = None
        self.victory_message_shown = False
        self.defeat_message_shown = False

        # 첫 번째 적 생성 (이미 있으면 그대로 사용)
        if not self.enemy:
            self.spawn_enemy()

        # 상태를 BATTLE로 변경
        self.enter_state(GameState.BATTLE, "전투 시작")
        self.set_phase(PHASE_PLAYER_TURN, "전투 시작")
        self.turn = 0

        # button_registry 초기화 (새 화면이므로)
        self.button_registry.clear()
        self.selected_card_index = None

        # transition_lock 초기화 (전투 시작 시 반드시 해제)
        self.transition_lock = False
        self.pending_action = None
        self.pending_end_turn_at = None
        self._end_turn_handled_enter_id = None

        # 전투용 draw_pile 구성 (player.deck 기반)
        self.player.draw_pile = []
        self.player.hand = []
        self.player.discard_pile = []

        # player.deck (카드 ID 리스트)를 Card 객체로 변환
        if len(self.player.deck) < 5:
            # 안전장치: 덱이 너무 적으면 기본 스타터 카드 추가
            self.logger.log(
                "WARN",
                "DECK_BUILD",
                f"덱이 너무 적음 ({len(self.player.deck)}장), 기본 카드 자동 추가",
                {"deck_size": len(self.player.deck)},
            )
            # 기본 스타터 카드 추가
            starter_cards = ["삼재공", "육합권", "포천삼"]
            for card_id in starter_cards:
                if card_id not in self.player.collection:
                    self.player.collection.append(card_id)
                if len(self.player.deck) < 10:
                    self.player.deck.append(card_id)

        # 덱 ID를 Card 객체로 변환하여 draw_pile 구성
        for card_id in self.player.deck:
            card = get_card_by_id(card_id)
            if card:
                self.player.draw_pile.append(card)
            else:
                self.logger.log(
                    "ERROR",
                    "DECK_BUILD",
                    f"카드 ID를 찾을 수 없음: {card_id}",
                    {"card_id": card_id},
                )

        # draw_pile 섞기
        random.shuffle(self.player.draw_pile)

        # 플레이어 턴 시작
        self.player.start_turn()
        self.log_lines.append("[전투] 전투가 시작되었다!")

    def start_next_encounter(self):
        """다음 인카운터 시작 (encounter/chapter 진행 확실히 증가)"""
        # State 가드: VICTORY_PANEL 또는 DECK 상태에서만 실행 가능
        if self.state != GameState.VICTORY_PANEL and self.phase != PHASE_DECK:
            self.log_lines.append(
                "[오류] start_next_encounter는 VICTORY_PANEL 상태에서만 호출 가능합니다."
            )
            return

        # 이전 적이 Boss였는지 확인 (처치 카운트 증가)
        if self.enemy:
            if isinstance(self.enemy, Boss):
                self.defeated_counts["Boss"] += 1
                # Boss 처치 후: 다음 챕터로
                self.chapter += 1
                self.encounter_index = 0  # 챕터 시작 시 인덱스 리셋
                self.log_lines.append(f"[챕터] 챕터 {self.chapter}가 시작되었다!")
                self.add_log(f"[챕터] 챕터 {self.chapter}가 시작되었다!", "system")
            elif isinstance(self.enemy, Elite):
                self.defeated_counts["Elite"] += 1
            elif isinstance(self.enemy, Minion):
                self.defeated_counts["Minion"] += 1

        # 인카운터 인덱스 증가 (Boss 처치 후가 아니면, 그리고 5 미만일 때만)
        # Boss 처치 후에는 encounter_index가 0으로 리셋되므로 증가하지 않음
        if self.encounter_index < 5:
            self.encounter_index += 1
        # encounter_index가 5면 Boss이므로 증가하지 않음 (다음에 Boss 처치하면 챕터 증가)

        # 진행 로그 (테스트 케이스 검증용)
        enemy_rank = "Minion"
        if self.encounter_index <= 2:
            enemy_rank = "Minion"
        elif self.encounter_index <= 4:
            enemy_rank = "Elite"
        else:
            enemy_rank = "Boss"

        self.log_lines.append(
            f"[진행] encounter={self.encounter_index} chapter={self.chapter} -> 다음 적: {enemy_rank}"
        )
        self.log_event(
            "PROGRESSION",
            f"다음 인카운터",
            f"encounter_index={self.encounter_index} chapter={self.chapter} rank={enemy_rank}",
        )
        self.add_log(
            f"[encounter] 다음 적을 만났다. (챕터 {self.chapter}, 인카운터 {self.encounter_index}, 등급: {enemy_rank})",
            "system",
        )

        # 플레이어 상태 정리
        # 에너지 회복
        self.player.energy = self.player.max_energy
        # 방어도 초기화 (선택사항, 필요하면 주석 해제)
        # self.player.defense = 0

        # 손패와 덱 정리 (전투용 draw_pile/hand/discard_pile 초기화)
        self.player.hand = []
        self.player.last_rewards.clear()  # last_rewards 비우기
        self.player.draw_pile = []

        # 새 적 생성 (encounter_index와 chapter 기반)
        enemy_rank = self.generate_enemy(self.encounter_index, self.chapter)

        # 동적 인카운터 텍스트 생성
        encounter_text = self.story_manager.generate_encounter(self.enemy.name)
        self.add_log(encounter_text, "story")

        self.add_log(
            f"[전투] {self.enemy.name}과(와) 전투가 시작되었다! (챕터 {self.chapter}, 인카운터 {self.encounter_index}, 등급: {enemy_rank})",
            "system",
        )

        # 전투 초기화
        self.cards_used_in_battle = []
        self.battle_summary = None
        self.rewards = None
        self.victory_message_shown = False
        self.defeat_message_shown = False

        # battle_resolved 플래그 리셋
        self.battle_resolved = False

        # 이전 적 제거 (CAMP 화면에서는 enemy가 없어야 함)
        self.enemy = None

        if self.phase == PHASE_DECK:
            # 덱 정비 후 CAMP로 이동
            self.set_phase(PHASE_CAMP, "덱 정비 완료")
            self.enter_state(GameState.WORLD, "덱 정비 완료")
            self.training_menu_open = False
            # button_registry 초기화 (새 화면이므로)
            self.button_registry.clear()
            self.player.last_rewards.clear()  # last_rewards 비우기
            # transition_lock 해제 (덱 화면에서 나올 때 반드시 해제)
            self.transition_lock = False
            # 로그 기록
            self.log_event("STATE", "DECK -> CAMP", "덱 정비 완료", {})
            self.logger.log(
                "INFO",
                "DECK_EXIT",
                "덱 화면에서 나옴, transition_lock 해제",
                {"transition_lock": self.transition_lock},
            )

        # 로그 기록
        self.log_event("STATE", "DECK -> CAMP", "덱 정비 완료", {})

    def add_log(self, message: str, scope: str = "game"):
        """전투 로그에 메시지를 추가합니다."""
        log_entry = f"[{scope}] {message}"
        # 중복 방지: 최근 10개에 같은 메시지가 있으면 추가하지 않음
        if log_entry not in self.battle_log[-10:]:
            self.battle_log.append(log_entry)
            # 로그가 너무 많아지면 오래된 것 제거
            if len(self.battle_log) > 100:
                self.battle_log.pop(0)

    def generate_story_narration(self, event_type: str, value: int = 0):
        """동적 스토리 내레이션 생성 (규칙 기반)"""
        narrations = []

        if event_type == "high_damage_dealt":
            narrations = [
                "무공이 적의 방어를 뚫었다.",
                "강력한 일격이 적에게 명중했다.",
                "무공의 위력이 빛을 발한다.",
            ]
        elif event_type == "high_damage_taken":
            narrations = [
                "적의 공격이 몸을 관통한다.",
                "아픔이 느껴지지만 버틴다.",
                "상처를 입었지만 포기하지 않는다.",
            ]
        elif event_type == "defense_focused":
            narrations = [
                "방어 자세를 취한다.",
                "적의 공격을 막아낸다.",
                "견고한 방어로 버틴다.",
            ]
        elif event_type == "low_hp":
            narrations = [
                "체력이 바닥을 향한다...",
                "위험한 상황이지만 포기하지 않는다.",
                "마지막 힘을 짜낸다.",
            ]
        elif event_type == "enemy_defeated":
            narrations = [
                "녹림 도적이 쓰러졌다.",
                "하지만 이게 전부가 아니다.",
                "더 강한 적이 기다리고 있을 것이다.",
            ]

        if narrations:
            narration = random.choice(narrations)
            self.story_narration.append(narration)
            # 내레이션이 너무 많아지면 오래된 것 제거
            if len(self.story_narration) > 3:
                self.story_narration.pop(0)

    def handle_card_click(self, card_index: int):
        """카드 클릭 처리"""
        if card_index < len(self.player.hand):
            self.selected_card_index = card_index

    def use_selected_card(self):
        """선택된 카드 사용"""
        # Phase 가드: VICTORY/DEFEAT 상태에서는 아무것도 하지 않음
        if self.phase in (PHASE_VICTORY_PANEL, PHASE_DEFEAT_PANEL):
            return

        if self.selected_card_index is None or self.phase != PHASE_PLAYER_TURN:
            return

        if self.selected_card_index >= len(self.player.hand):
            self.selected_card_index = None
            return

        card = self.player.hand[self.selected_card_index]

        if not card.can_use(self.player.energy):
            self.add_log("행동력이 부족합니다!", "error")
            return

        # 카드 사용 전 상태 기록
        before_energy = self.player.energy
        before_hp = self.player.hp
        before_def = self.player.defense
        enemy_before_hp = self.enemy.hp if self.enemy else 0

        # 카드 사용
        success, result_message = card.use(self.player, self.enemy)

        # 스토리 컨텍스트 업데이트
        self.story_context.append(
            {
            "timestamp_ms": now_ms(),
            "type": "card_used",
            "card_name": card.name,
            "phase": self.phase,
                "turn": self.turn,
            }
        )

        if success:
            # 무공 텍스트 생성 (story_lines에 추가 - 이벤트 발생 시 1회만)
            card_description = self.story_manager.generate_card_description(card.name)
            self.story_lines.append(card_description)  # 이벤트 발생 시에만 추가
            self.log_lines.append(f"[무공] {card_description}")
            self.add_log(f"[무공] {card_description}", "player")

            # 데미지 정보도 함께 표시
            if result_message:
                self.add_log(f"[결과] {result_message}", "player")

            # 사용한 카드 기록
            self.cards_used_in_battle.append(card.name)

            # 구조화된 로깅
            self.log_event(
                "CARD_PLAYED",
                card.name,
                f"비용: {card.energy_cost}",
                {
                "card_id": card.name,
                "cost": card.energy_cost,
                "before_energy": before_energy,
                    "after_energy": self.player.energy,
                },
            )

            # 데미지 적용 로깅 및 승리 판정 (공격 카드인 경우)
            if card.type == CardType.ATTACK and self.enemy:
                damage_dealt = enemy_before_hp - (self.enemy.hp if self.enemy else 0)
                if damage_dealt > 0:
                    self.log_event(
                        "DAMAGE_APPLIED",
                        f"{damage_dealt} 데미지",
                        f"{card.name} 사용",
                        {
                        "src": "player",
                        "target": "enemy",
                        "amount": damage_dealt,
                        "enemy_before_hp": enemy_before_hp,
                        "enemy_after_hp": self.enemy.hp if self.enemy else 0,
                        "enemy_before_def": 0,
                            "enemy_after_def": 0,
                        },
                    )

                    # resolve_damage() 직후 승리 판정 (딱 1회만)
                    if self.enemy.hp <= 0 and not self.battle_resolved:
                        self.battle_resolved = True
                        self.on_victory()

            self.player.discard_card(card)
            self.selected_card_index = None
        else:
            self.add_log(f"[오류] {result_message}", "error")

    def on_victory(self):
        """승리 처리 (resolve_damage() 직후 딱 1회만 호출) - "한 번만 실행" 가드"""
        if not self.enemy or self.enemy.hp > 0:
            return  # 적이 살아있으면 승리 아님

        # enemy.hp를 0으로 clamp (음수 방지)
        if self.enemy.hp < 0:
            self.enemy.hp = 0

        # "한 번만 실행" 가드: 이미 처리된 enter_id면 실행하지 않음
        if self._handled_enter_ids.get("on_victory") == self.phase_enter_id:
            return

        # 처리 완료 표시
        self._handled_enter_ids["on_victory"] = self.phase_enter_id

        # 전투 요약 생성
        self.battle_summary = self.build_battle_summary()

        # 보상 생성
        enemy_rank = "Minion"
        if isinstance(self.enemy, Boss):
            enemy_rank = "Boss"
        elif isinstance(self.enemy, Elite):
            enemy_rank = "Elite"

        self.rewards = self.roll_rewards(enemy_rank)

        # 보상 적용
        self.xp += self.rewards["xp"]
        self.gold += self.rewards["gold"]

        # 카드 보상 처리 (collection과 last_rewards에 추가)
        if self.rewards.get("card_reward_id"):
            card_id = self.rewards["card_reward_id"]
            self.player.collection.append(card_id)
            self.player.last_rewards.append(card_id)
            self.logger.log(
                "INFO",
                "CARD_REWARD",
                f"카드 획득: {card_id}",
                {"card_id": card_id, "enemy_rank": enemy_rank},
            )

        # 상태 전환 (enter_state 사용 - 1회성 보장)
        victory_text = f"{self.enemy.name}을(를) 쓰러뜨렸다."

        # 반드시 phase를 PHASE_VICTORY_PANEL로 전환 (렌더링/입력 처리의 유일한 기준)
        self.set_phase(PHASE_VICTORY_PANEL, "enemy_dead")

        # enter_state도 호출 (하위 호환성)
        self.enter_state(
            GameState.VICTORY_PANEL,
            "적 HP 0 도달",
            {
                "victory_text": victory_text,
                "rewards": self.rewards,
                "battle_summary": self.battle_summary,
            },
        )

        # battle_resolved 플래그 설정 (보조용, phase 전환의 대체재가 아님)
        self.battle_resolved = True

        # VICTORY_PANEL은 일시적이므로, "다음 적" 버튼 클릭 시 CAMP로 전환
        # (start_next_encounter에서 처리)

        self.logger.log(
            "INFO",
            "VICTORY",
            "승리 처리 완료, phase 전환",
            {"phase": self.phase, "enemy_hp": self.enemy.hp if self.enemy else None},
        )

    def on_defeat(self):
        """패배 처리 (resolve_damage() 직후 딱 1회만 호출) - "한 번만 실행" 가드"""
        if self.player.hp > 0:
            return  # 플레이어가 살아있으면 패배 아님

        # "한 번만 실행" 가드: 이미 처리된 enter_id면 실행하지 않음
        if self._handled_enter_ids.get("on_defeat") == self.phase_enter_id:
            return

        # 처리 완료 표시
        self._handled_enter_ids["on_defeat"] = self.phase_enter_id

        # 상태 전환 (enter_state 사용 - 1회성 보장)
        self.enter_state(
            GameState.GAMEOVER,
            "플레이어 HP 0 도달",
            {"defeat_text": "무인이 쓰러졌다..."},
        )

    def request_end_turn(self):
        """턴 종료 요청 (즉시 처리하지 않고 pending_action에 설정)"""
        # State 가드: VICTORY/GAMEOVER 상태에서는 아무것도 하지 않음
        # 화면-입력 동기화 가드: handle_events()도 phase만 보고 처리한다
        if self.phase in (PHASE_VICTORY_PANEL, PHASE_DEFEAT_PANEL):
            self.logger.log(
                "WARN",
                "TURN_REQUEST_BLOCKED",
                "턴 종료 요청 차단: VICTORY/DEFEAT phase",
                {"phase": self.phase},
            )
            return

        if self.phase != PHASE_PLAYER_TURN:
            self.logger.log(
                "WARN",
                "TURN_REQUEST_BLOCKED",
                "턴 종료 요청 차단: 잘못된 state/phase",
                {
                    "state": self.state.value if hasattr(self.state, 'value') else str(self.state),
                    "phase": self.phase,
                },
            )
            return

        # transition_lock이 이미 설정되어 있으면 무시
        if self.transition_lock:
            self.logger.log(
                "WARN",
                "TURN_REQUEST_BLOCKED",
                "턴 종료 요청 차단: transition_lock=True",
                {
                    "transition_lock": self.transition_lock,
                    "phase": self.phase,
                    "state": self.state.value if hasattr(self.state, 'value') else str(self.state),
                },
            )
            return

        # pending_action 설정 (같은 프레임에서 set_phase/적행동/에너지리셋 금지)
        self.pending_action = {"type": "END_TURN", "at": now_ms()}
        self.pending_end_turn_at = now_ms()  # watchdog용
        self.logger.log(
            "INFO",
            "TURN_REQUEST",
            "턴 종료 요청",
            {"phase": self.phase, "state": self.state.value if hasattr(self.state, 'value') else str(self.state)},
        )

    def end_player_turn(self):
        """플레이어 턴 종료 처리 (update()에서만 호출, 절대 중복 실행 방지)"""
        # 화면-입력 동기화 가드: phase만 보고 처리한다
        if self.phase in (PHASE_VICTORY_PANEL, PHASE_DEFEAT_PANEL):
            return

        # 이미 ENEMY_TURN으로 전환되었으면 무시 (중복 호출 방지)
        if self.phase == PHASE_ENEMY_TURN:
            # 이미 처리되었는데 또 호출된 경우
            if self._end_turn_handled_enter_id == self.phase_enter_id:
                return
            # phase는 ENEMY_TURN이지만 enter_id가 다르면 재처리 필요 없음
            return

        if self.phase != PHASE_PLAYER_TURN:
            return

        # transition_lock이 이미 설정되어 있으면 무시 (중복 호출 방지)
        if self.transition_lock:
            self.logger.log(
                "WARN",
                "TURN_END_DUPLICATE",
                "end_player_turn 중복 호출 방지 (transition_lock=True)",
                {"phase": self.phase, "state": self.state.value if hasattr(self.state, 'value') else str(self.state)},
            )
            return

        # enter_id 기반 중복 실행 방지 (더 강력한 가드)
        current_enter_id = getattr(self, "phase_enter_id", 0)
        if self._end_turn_handled_enter_id == current_enter_id:
            self.logger.log(
                "WARN",
                "TURN_END_DUPLICATE",
                "end_player_turn 중복 호출 방지 (enter_id 기반)",
                {"phase": self.phase, "enter_id": current_enter_id},
            )
            return

        # transition_lock 설정 (버튼 비활성화)
        self.transition_lock = True

        # enter_id 기록 (중복 실행 방지)
        self._end_turn_handled_enter_id = current_enter_id

        self.selected_card_index = None
        self.log_lines.append("[턴] 플레이어 턴 종료")
        self.log_event("TURN", "플레이어 턴 종료", "end_player_turn")

        # 반드시 set_phase(ENEMY_TURN) 수행
        self.set_phase(PHASE_ENEMY_TURN, "end_turn_clicked")

        # enemy_turn_step_done 초기화
        self.enemy_turn_step_done = False

        # ENEMY_TURN 타이머 초기화
        self._enemy_turn_start_time = now_ms()

        # pending_end_turn_at 초기화 (watchdog 해제)
        self.pending_end_turn_at = None

        self.logger.log(
            "INFO",
            "TURN_END",
            "플레이어 턴 종료 처리 완료",
            {
                "phase": self.phase,
                "phase_enter_id": self.phase_enter_id,
                "enemy_turn_step_done": self.enemy_turn_step_done,
            },
        )

    def run_enemy_turn_once(self):
        """적 턴 로직 (ENEMY_TURN 진입 후 1회만 실행)"""
        # enemy 존재/HP>0 검사 (아니면 CRITICAL + snapshot)
        if not self.enemy:
            self.logger.log(
                "CRITICAL",
                "ENEMY_TURN_ERROR",
                "ENEMY_TURN phase인데 enemy가 None",
                {"phase": self.phase, "state_enter_id": self.state_enter_id},
            )
            self.dump_snapshot("enemy_turn_no_enemy")
            self.set_phase(PHASE_PLAYER_TURN, "enemy_turn_error")
            return

        if not self.enemy.is_alive() or self.enemy.hp <= 0:
            self.logger.log(
                "CRITICAL",
                "ENEMY_TURN_ERROR",
                "ENEMY_TURN phase인데 enemy가 죽어있음",
                {"phase": self.phase, "enemy_hp": self.enemy.hp, "state_enter_id": self.state_enter_id},
            )
            self.dump_snapshot("enemy_turn_dead_enemy")
            self.set_phase(PHASE_VICTORY_PANEL, "enemy_turn_dead")
            return

        self.logger.log(
            "INFO",
            "ENEMY_ACTION",
            "적 턴 처리 시작",
            {"phase": self.phase, "enemy_hp": self.enemy.hp, "turn": self.turn},
        )

        action_type, damage_value = self.enemy.get_action(self.player)

        if action_type == "attack":
            actual_damage, message = self.enemy.attack(self.player)
            self.add_log(f"[적] {message}", "enemy")

            # 스토리 내레이션 생성 (이벤트 발생 시 1회만)
            if actual_damage >= 10:
                story_text = "적의 공격이 몸을 관통한다."
                self.story_log.add(
                    story_text,
                    dedupe_key=f"enemy_attack_{self.turn}",
                    state_enter_id=self.on_enter_done.get(self.phase, 0),
                )

            # resolve_damage() 직후 패배 판정 (딱 1회만)
            if self.player.hp <= 0 and not self.battle_resolved:
                self.battle_resolved = True
                self.on_defeat()

        elif action_type == "special_attack":
            damage = damage_value
            actual_damage = self.player.take_damage(damage)
            weapon = random.choice(["도끼", "철퇴", "대도"])

            # 체력 상태에 따른 메시지
            hp_ratio = (
                self.player.hp / self.player.max_hp if self.player.max_hp > 0 else 0
            )
            if hp_ratio > 0.3:
                message = f"{self.enemy.name}이(가) {weapon}로 강공격! ({actual_damage} 데미지)"
            else:
                message = f"{self.enemy.name}이(가) {weapon}로 강타했다! 피가 튄다. ({actual_damage} 데미지)"

            self.add_log(f"[적] {message}", "enemy")

            # resolve_damage() 직후 패배 판정 (딱 1회만)
            if self.player.hp <= 0 and not self.battle_resolved:
                self.battle_resolved = True
                self.on_defeat()

        elif action_type == "ultimate_attack":
            damage = damage_value
            actual_damage = self.player.take_damage(damage)

            # 체력 상태에 따른 메시지
            hp_ratio = (
                self.player.hp / self.player.max_hp if self.player.max_hp > 0 else 0
            )
            if hp_ratio > 0.3:
                message = f"{self.enemy.name}의 필살기! ({actual_damage} 데미지)"
            else:
                message = f"{self.enemy.name}의 필살기가 몸을 관통한다! 하지만 버틴다. ({actual_damage} 데미지)"

            self.add_log(f"[적] {message}", "enemy")

            # resolve_damage() 직후 패배 판정 (딱 1회만)
            if self.player.hp <= 0 and not self.battle_resolved:
                self.battle_resolved = True
                self.on_defeat()

        # 플레이어 사망 시 PHASE_DEFEAT_PANEL로 set_phase
        if self.player.hp <= 0:
            self.battle_resolved = True
            self.on_defeat()
            return

        # 적 턴 처리 완료 -> 플레이어 턴으로 전환
        self.turn += 1
        self.set_phase(PHASE_PLAYER_TURN, "enemy_turn_done")
        # transition_lock 해제 (버튼 활성화)
        self.transition_lock = False

    def draw_health_bar(self, surface, x, y, width, height, current, maximum, color):
        """HP 바를 그립니다."""
        # 배경 (검은색)
        pygame.draw.rect(surface, COLOR_BLACK, (x, y, width, height))

        # HP 바
        if maximum > 0:
            hp_ratio = current / maximum
            hp_width = int(width * hp_ratio)
            pygame.draw.rect(surface, color, (x, y, hp_width, height))

        # 테두리
        pygame.draw.rect(surface, COLOR_WHITE, (x, y, width, height), 2)

    def draw_text(self, surface, text, font, color, x, y, center=False):
        """텍스트를 그립니다."""
        if font is None:
            # 폰트가 None이면 기본 폰트 사용
            font = pygame.font.Font(None, 20)

        try:
            # UTF-8 인코딩으로 텍스트 렌더링 시도
            text_str = str(text)
            text_surface = font.render(text_str, True, color)

            if center:
                text_rect = text_surface.get_rect(center=(x, y))
                surface.blit(text_surface, text_rect)
            else:
                surface.blit(text_surface, (x, y))
        except Exception as e:
            # 한글 렌더링 실패 시 영문으로 대체 시도
            try:
                # ASCII만 남기기
                ascii_text = "".join(c for c in str(text) if ord(c) < 128)
                if ascii_text:
                    text_surface = font.render(ascii_text, True, color)
                    if center:
                        text_rect = text_surface.get_rect(center=(x, y))
                        surface.blit(text_surface, text_rect)
                    else:
                        surface.blit(text_surface, (x, y))
            except:
                # 모든 렌더링 실패 시 아무것도 그리지 않음
                pass

    def draw_card(self, surface, card, x, y, width, height, selected=False):
        """카드를 그립니다."""
        # 카드 배경색 (타입에 따라)
        if selected:
            card_color = COLOR_GOLD
        elif card.type == CardType.ATTACK:
            card_color = COLOR_RED
        elif card.type == CardType.DEFENSE:
            card_color = COLOR_DARK_GREEN
        elif card.type == CardType.SKILL:
            card_color = COLOR_BROWN
        else:  # DEBUFF
            card_color = COLOR_DARK_GRAY

        # 카드 배경
        pygame.draw.rect(surface, card_color, (x, y, width, height))
        pygame.draw.rect(surface, COLOR_WHITE, (x, y, width, height), 2)

        # 카드 이름
        self.draw_text(surface, card.name, FONT_SMALL, COLOR_WHITE, x + 5, y + 5)

        # 카드 설명 (간단히 표시)
        # 설명을 여러 줄로 나누어 표시
        desc_lines = []
        desc_text = card.description
        # 긴 설명은 자르기
        if len(desc_text) > 15:
            # 15자씩 나누기
            for i in range(0, len(desc_text), 15):
                desc_lines.append(desc_text[i : i + 15])
        else:
            desc_lines.append(desc_text)

        # 설명 표시 (최대 2줄)
        desc_y = y + 30
        for i, line in enumerate(desc_lines[:2]):
            if desc_y + i * 15 < y + height - 25:
                self.draw_text(
                    surface, line, FONT_TINY, COLOR_WHITE, x + 5, desc_y + i * 15
                )

        # 카드 비용
        cost_text = f"비용: {card.energy_cost}"
        self.draw_text(
            surface, cost_text, FONT_TINY, COLOR_WHITE, x + 5, y + height - 20
        )

        # 사용 가능 여부 표시
        if not card.can_use(self.player.energy):
            # 반투명 오버레이
            overlay = pygame.Surface((width, height))
            overlay.set_alpha(128)
            overlay.fill(COLOR_BLACK)
            surface.blit(overlay, (x, y))

    def render_victory_panel(self):
        """승리 결과창을 강제 렌더링 (미렌더 감지 포함)"""
        # Phase 가드: PHASE_VICTORY_PANEL이 아니면 그리지 않음 (렌더링의 유일한 기준)
        if self.phase != PHASE_VICTORY_PANEL:
            return

        # 렌더링 플래그 설정
        self.victory_panel_rendered = True

        # 반투명 어두운 오버레이 (전체 화면) - 더 진하게
        overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
        overlay.set_alpha(240)  # 더 진하게
        overlay.fill(COLOR_BLACK)
        self.screen.blit(overlay, (0, 0))

        # 큰 팝업 박스 (화면 중앙)
        center_x = SCREEN_WIDTH // 2
        center_y = SCREEN_HEIGHT // 2
        popup_width = 600
        popup_height = 500
        popup_x = center_x - popup_width // 2
        popup_y = center_y - popup_height // 2

        # 팝업 배경 (검은색)
        pygame.draw.rect(
            self.screen, COLOR_BLACK, (popup_x, popup_y, popup_width, popup_height)
        )
        # 팝업 테두리 (금색)
        pygame.draw.rect(
            self.screen, COLOR_GOLD, (popup_x, popup_y, popup_width, popup_height), 3
        )

        y_offset = popup_y + 30

        # 승리 메시지 (state_payload에서 가져오기)
        victory_text = self.state_payload.get("victory_text", "승리!")
        self.draw_text(
            self.screen,
            victory_text,
            FONT_LARGE,
            COLOR_GOLD,
            center_x,
            y_offset,
            center=True,
        )
        y_offset += 50

        # 전투 요약
        battle_summary = self.state_payload.get("battle_summary") or self.battle_summary
        if battle_summary:
            self.draw_text(
                self.screen,
                f"전투 요약: {battle_summary.get('turns', 0)}합",
                FONT_MEDIUM,
                COLOR_WHITE,
                center_x,
                y_offset,
                center=True,
            )
            y_offset += 30

            # 사용한 무공 목록
            if battle_summary.get("card_counts"):
                card_list = ", ".join(
                    [
                        f"{name}({count})"
                        for name, count in battle_summary["card_counts"].items()
                    ]
                )
                if len(card_list) > 50:
                    card_list = card_list[:47] + "..."
                self.draw_text(
                    self.screen,
                    f"사용한 무공: {card_list}",
                    FONT_SMALL,
                    COLOR_WHITE,
                    center_x,
                    y_offset,
                    center=True,
                )
                y_offset += 25

            # 결정타
            if battle_summary.get("final_blow"):
                self.draw_text(
                    self.screen,
                    f"결정타: {battle_summary['final_blow']}",
                    FONT_SMALL,
                    COLOR_GOLD,
                    center_x,
                    y_offset,
                    center=True,
                )
                y_offset += 25

            # 핵심 턴
            if battle_summary.get("key_turn"):
                max_damage = battle_summary.get("max_damage", 0)
                self.draw_text(
                    self.screen,
                    f"핵심 턴: {battle_summary['key_turn']}턴 ({max_damage} 데미지)",
                    FONT_SMALL,
                    COLOR_GOLD,
                    center_x,
                    y_offset,
                    center=True,
                )
                y_offset += 30

        # 획득 보상 (state_payload에서 가져오기)
        rewards = self.state_payload.get("rewards") or self.rewards
        if rewards:
            self.draw_text(
                self.screen,
                "획득:",
                FONT_MEDIUM,
                COLOR_WHITE,
                center_x,
                y_offset,
                center=True,
            )
            y_offset += 30

            xp_gain = rewards.get("xp", 0)
            self.draw_text(
                self.screen,
                f"경험치: +{xp_gain} (총 {self.xp})",
                FONT_SMALL,
                COLOR_WHITE,
                center_x,
                y_offset,
                center=True,
            )
            y_offset += 25

            gold_gain = rewards.get("gold", 0)
            self.draw_text(
                self.screen,
                f"금전: +{gold_gain} (총 {self.gold})",
                FONT_SMALL,
                COLOR_WHITE,
                center_x,
                y_offset,
                center=True,
            )
            y_offset += 25

            if rewards.get("card_reward_id"):
                card_id = rewards["card_reward_id"]
                self.draw_text(
                    self.screen,
                    f"카드: {card_id}",
                    FONT_SMALL,
                    COLOR_GOLD,
                    center_x,
                    y_offset,
                    center=True,
                )
                y_offset += 25

        # 보상 선택 버튼 (패널 내부)
        button_y = popup_y + popup_height - 80
        button_width = 180
        button_height = 50
        button_spacing = 10

        # "덱 정비" 버튼 (왼쪽)
        deck_button_x = center_x - button_width - button_spacing // 2
        deck_button_rect = pygame.Rect(
            deck_button_x, button_y, button_width, button_height
        )

        pygame.draw.rect(self.screen, COLOR_BLUE, deck_button_rect)
        pygame.draw.rect(self.screen, COLOR_WHITE, deck_button_rect, 2)
        self.draw_text(
            self.screen,
            "덱 정비",
            FONT_MEDIUM,
            COLOR_WHITE,
            deck_button_x + button_width // 2,
            button_y + button_height // 2,
            center=True,
        )

        # 버튼을 ui_buttons_next에 등록 (MODAL 레이어, 우선순위 3)
        self.ui_buttons_next["victory_deck"] = {
            "rect": deck_button_rect,
            "layer": "modal",
            "enabled": True,
            "on_click": lambda: self.set_phase(PHASE_DECK, "덱 정비 버튼 클릭"),
            "priority": 3,
        }

        # "다음 적" 버튼 (오른쪽, hitbox 저장)
        next_button_x = center_x + button_spacing // 2
        next_button_rect = pygame.Rect(
            next_button_x, button_y, button_width, button_height
        )
        self.victory_next_btn_rect = next_button_rect  # hitbox 저장 (하위 호환성)
        self.modal_rect = pygame.Rect(
            popup_x, popup_y, popup_width, popup_height
        )  # 모달 전체 hitbox (하위 호환성)

        pygame.draw.rect(self.screen, COLOR_DARK_GREEN, next_button_rect)
        pygame.draw.rect(self.screen, COLOR_WHITE, next_button_rect, 2)
        self.draw_text(
            self.screen,
            "다음 적",
            FONT_MEDIUM,
            COLOR_WHITE,
            next_button_x + button_width // 2,
            button_y + button_height // 2,
            center=True,
        )

        # 버튼을 ui_buttons_next에 등록 (MODAL 레이어, 우선순위 3)
        self.ui_buttons_next["victory_next"] = {
            "rect": next_button_rect,
            "layer": "modal",
            "enabled": True,
            "on_click": self.start_next_encounter,
            "priority": 3,
        }

        # 하위 호환성: UI 레이어에도 추가
        self.ui_layers["modal"].append(
            {
            "label": "다음 적",
            "on_click": self.start_next_encounter,
            "enabled": True,
            "visible": True,
            "color": COLOR_DARK_GREEN,
                "rect": next_button_rect,
            }
        )

    def render_victory_screen(self):
        """하위 호환성을 위한 래퍼"""
        self.render_victory_panel()

    # ==================== 디버깅 시스템: 디버그 오버레이 ====================
    def render_debug_overlay(self):
        """디버그 오버레이 렌더링"""
        y_offset = 10

        # 상태 정보 (phase 기반으로만 표시)
        state_info = f"PHASE={self.phase} chapter={self.chapter} encounter={self.encounter_index}"
        # CAMP/TRAINING에서는 전투 정보 표시하지 않음
        if self.phase not in (PHASE_CAMP, PHASE_TRAINING) and self.enemy:
            enemy_rank = "Minion"
            if isinstance(self.enemy, Boss):
                enemy_rank = "Boss"
            elif isinstance(self.enemy, Elite):
                enemy_rank = "Elite"
            state_info += f" enemy_rank={enemy_rank} enemy_hp={self.enemy.hp}"
        # 전투 중일 때만 에너지 표시
        if self.phase in (PHASE_PLAYER_TURN, PHASE_ENEMY_TURN):
            state_info += f" player_energy={self.player.energy}"

        self.draw_text(self.screen, state_info, FONT_TINY, COLOR_WHITE, 10, y_offset)
        y_offset += 20

        # 스토리 로그 정보
        story_info = f"story_lines={self.story_log.get_count()} last_key={self.story_log.last_story_key} state_enter_id={self.state_enter_id}"
        self.draw_text(self.screen, story_info, FONT_TINY, COLOR_WHITE, 10, y_offset)
        y_offset += 20

        # battle_resolved 플래그
        if self.battle_resolved:
            self.draw_text(
                self.screen, f"battle_resolved=True", FONT_TINY, COLOR_RED, 10, y_offset
            )
            y_offset += 20

        # 불변조건 위반 표시
        if self.invariant_failures:
            for i, failure in enumerate(self.invariant_failures[:3]):  # 최대 3개만 표시
                fail_text = f"INVARIANT FAIL: {failure['condition']}"
                self.draw_text(
                    self.screen, fail_text, FONT_TINY, COLOR_RED, 10, y_offset
                )
                y_offset += 15

        # VICTORY 패널 미렌더 감지
        if self.phase == PHASE_VICTORY_PANEL and not self.victory_panel_rendered:
            self.draw_text(
                self.screen,
                "VICTORY PANEL NOT RENDERED!",
                FONT_MEDIUM,
                COLOR_RED,
                SCREEN_WIDTH // 2,
                SCREEN_HEIGHT // 2,
                center=True,
            )

        # UI 버튼 영역 표시 (F3 활성화 시) - active 기준으로만 그리기
        if self.debug_ui_bounds_visible:
            # ui_buttons_active의 모든 버튼 표시 (현재 화면에 실제 클릭 가능한 영역)
            for button_id, btn_info in self.ui_buttons_active.items():
                rect = btn_info.get("rect")
                if rect:
                    enabled = btn_info.get("enabled", True)
                    layer = btn_info.get("layer", "unknown")
                    priority = btn_info.get("priority", 0)
                    # enabled면 초록색, disabled면 빨간색
                    color = COLOR_GREEN if enabled else COLOR_RED
                    pygame.draw.rect(self.screen, color, rect, 2)
                    # 버튼 ID, 레이어, 우선순위 표시
                    label = f"{button_id} [{layer}:{priority}]"
                    self.draw_text(
                        self.screen, label, FONT_TINY, color, rect.x, rect.y - 15
                    )

    def render_error_overlay(self, error_msg: str, traceback_str: str):
        """에러 오버레이 렌더링"""
        # 반투명 빨간 배경
        overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
        overlay.set_alpha(200)
        overlay.fill(COLOR_RED)
        self.screen.blit(overlay, (0, 0))

        # 에러 박스
        center_x = SCREEN_WIDTH // 2
        center_y = SCREEN_HEIGHT // 2
        box_width = 800
        box_height = 400
        box_x = center_x - box_width // 2
        box_y = center_y - box_height // 2

        pygame.draw.rect(
            self.screen, COLOR_BLACK, (box_x, box_y, box_width, box_height)
        )
        pygame.draw.rect(
            self.screen, COLOR_RED, (box_x, box_y, box_width, box_height), 3
        )

        # 에러 메시지
        self.draw_text(
            self.screen,
            "EXCEPTION 발생!",
            FONT_LARGE,
            COLOR_RED,
            center_x,
            box_y + 30,
            center=True,
        )
        self.draw_text(
            self.screen,
            error_msg,
            FONT_MEDIUM,
            COLOR_WHITE,
            center_x,
            box_y + 70,
            center=True,
        )

        # 트레이스백 (최근 10줄만)
        trace_lines = traceback_str.split("\n")[-10:]
        for i, line in enumerate(trace_lines):
            if line.strip():
                self.draw_text(
                    self.screen,
                    line[:80],
                    FONT_TINY,
                    COLOR_WHITE,
                    box_x + 10,
                    box_y + 120 + i * 20,
                )

        # 안내 메시지
        self.draw_text(
            self.screen,
            "F1: 스냅샷 저장 | F2: 디버그 토글 | F3: UI 영역 표시",
            FONT_SMALL,
            COLOR_WHITE,
            center_x,
            box_y + box_height - 30,
            center=True,
        )

        y_offset = popup_y + 30

        # 승리 메시지
        if self.enemy:
            victory_text = f"승리! {self.enemy.name}을(를) 쓰러뜨렸다."
        else:
            victory_text = "승리!"

        self.draw_text(
            self.screen,
            victory_text,
            FONT_LARGE,
            COLOR_GOLD,
            center_x,
            y_offset,
            center=True,
        )
        y_offset += 50

        # 전투 요약
        if self.battle_summary:
            self.draw_text(
                self.screen,
                f"전투 요약: {self.battle_summary.get('turns', 0)}합",
                FONT_MEDIUM,
                COLOR_WHITE,
                center_x,
                y_offset,
                center=True,
            )
            y_offset += 30

            # 사용한 무공 목록
            if self.battle_summary.get("card_counts"):
                card_list = ", ".join(
                    [
                        f"{name}({count})"
                        for name, count in self.battle_summary["card_counts"].items()
                    ]
                )
                self.draw_text(
                    self.screen,
                    f"사용한 무공: {card_list}",
                    FONT_SMALL,
                    COLOR_WHITE,
                    center_x,
                    y_offset,
                    center=True,
                )
                y_offset += 25

            # 결정타
            if self.battle_summary.get("final_blow"):
                self.draw_text(
                    self.screen,
                    f"결정타: {self.battle_summary['final_blow']}",
                    FONT_SMALL,
                    COLOR_GOLD,
                    center_x,
                    y_offset,
                    center=True,
                )
                y_offset += 25

            # 핵심 턴
            if self.battle_summary.get("key_turn"):
                self.draw_text(
                    self.screen,
                    f"핵심 턴: {self.battle_summary['key_turn']}턴 ({self.battle_summary.get('max_damage', 0)} 데미지)",
                    FONT_SMALL,
                    COLOR_GOLD,
                    center_x,
                    y_offset,
                    center=True,
                )
                y_offset += 30
        else:
            # battle_summary가 없으면 기본 메시지
            self.draw_text(
                self.screen,
                "전투 요약: 정보 없음",
                FONT_MEDIUM,
                COLOR_WHITE,
                center_x,
                y_offset,
                center=True,
            )
            y_offset += 30

        # 획득 보상 (항상 표시)
        if self.rewards:
            self.draw_text(
                self.screen,
                "획득:",
                FONT_MEDIUM,
                COLOR_WHITE,
                center_x,
                y_offset,
                center=True,
            )
            y_offset += 30

            xp_gain = self.rewards.get("xp", 0)
            self.draw_text(
                self.screen,
                f"경험치: +{xp_gain} (총 {self.xp})",
                FONT_SMALL,
                COLOR_WHITE,
                center_x,
                y_offset,
                center=True,
            )
            y_offset += 25

            gold_gain = self.rewards.get("gold", 0)
            self.draw_text(
                self.screen,
                f"금전: +{gold_gain} (총 {self.gold})",
                FONT_SMALL,
                COLOR_WHITE,
                center_x,
                y_offset,
                center=True,
            )
            y_offset += 25

            if self.rewards.get("card_reward_id"):
                card_id = self.rewards["card_reward_id"]
                self.draw_text(
                    self.screen,
                    f"카드: {card_id}",
                    FONT_SMALL,
                    COLOR_GOLD,
                    center_x,
                    y_offset,
                    center=True,
                )
                y_offset += 25
        else:
            # rewards가 없으면 기본 메시지
            self.draw_text(
                self.screen,
                "획득: 보상 없음",
                FONT_MEDIUM,
                COLOR_WHITE,
                center_x,
                y_offset,
                center=True,
            )
            y_offset += 30

        # 안내 메시지 (우하단 버튼 사용 안내)
        self.draw_text(
            self.screen,
            "우하단 '다음 적' 버튼을 클릭하세요",
            FONT_SMALL,
            COLOR_WHITE,
            center_x,
            popup_y + popup_height - 30,
            center=True,
        )

    def render_world_screen(self):
        """월드 화면을 렌더링합니다."""
        # 배경
        self.screen.fill(COLOR_DARK_GRAY)

        center_x = SCREEN_WIDTH // 2
        center_y = SCREEN_HEIGHT // 2

        # 제목
        self.draw_text(
            self.screen,
            "산길을 걷는다",
            FONT_LARGE,
            COLOR_WHITE,
            center_x,
            50,
            center=True,
        )

        # 플레이어 정보
        info_y = 120
        self.draw_text(
            self.screen,
            f"체력: {self.player.hp}/{self.player.max_hp}",
            FONT_MEDIUM,
            COLOR_WHITE,
            50,
            info_y,
        )
        self.draw_text(
            self.screen, f"경험치: {self.xp}", FONT_MEDIUM, COLOR_WHITE, 50, info_y + 30
        )
        self.draw_text(
            self.screen, f"금전: {self.gold}", FONT_MEDIUM, COLOR_WHITE, 50, info_y + 60
        )
        self.draw_text(
            self.screen,
            f"챕터: {self.chapter}",
            FONT_MEDIUM,
            COLOR_WHITE,
            50,
            info_y + 90,
        )

        # 수련하기 버튼
        train_button_x = center_x - 100
        train_button_y = center_y - 50
        train_button_width = 200
        train_button_height = 50
        train_button_rect = pygame.Rect(
            train_button_x, train_button_y, train_button_width, train_button_height
        )

        pygame.draw.rect(self.screen, COLOR_DARK_GREEN, train_button_rect)
        pygame.draw.rect(self.screen, COLOR_WHITE, train_button_rect, 2)

        self.draw_text(
            self.screen,
            "수련하기",
            FONT_MEDIUM,
            COLOR_WHITE,
            center_x,
            train_button_y + train_button_height // 2,
            center=True,
        )

        # 버튼을 ui_buttons_next에 등록 (HUD 레이어, 우선순위 1)
        self.ui_buttons_next["camp_train"] = {
            "rect": train_button_rect,
            "layer": "hud",
            "enabled": True,
            "on_click": lambda: self.set_phase(PHASE_TRAINING, "수련하기 버튼 클릭")
            or setattr(self, "training_menu_open", True),
            "priority": 1,
        }

        # 계속 걷기 버튼 (다음 인카운터로)
        continue_button_x = center_x - 100
        continue_button_y = center_y + 30
        continue_button_width = 200
        continue_button_height = 50
        continue_button_rect = pygame.Rect(
            continue_button_x,
            continue_button_y,
            continue_button_width,
            continue_button_height,
        )

        pygame.draw.rect(self.screen, COLOR_DARK_GREEN, continue_button_rect)
        pygame.draw.rect(self.screen, COLOR_WHITE, continue_button_rect, 2)

        self.draw_text(
            self.screen,
            "계속 걷기",
            FONT_MEDIUM,
            COLOR_WHITE,
            center_x,
            continue_button_y + continue_button_height // 2,
            center=True,
        )

        # 버튼을 ui_buttons_next에 등록 (HUD 레이어, 우선순위 1)
        def on_continue_click():
            # 새 적 생성
            enemy_rank = self.generate_enemy(self.encounter_index, self.chapter)
            # 전투 시작
            self.start_battle()

        self.ui_buttons_next["camp_continue"] = {
            "rect": continue_button_rect,
            "layer": "hud",
            "enabled": True,
            "on_click": on_continue_click,
            "priority": 1,
        }

        # 수련 UI (수련 메뉴가 열려있을 때)
        if hasattr(self, "training_menu_open") and self.training_menu_open:
            self.render_training_menu()

    def render_training_menu(self):
        """수련 메뉴를 렌더링합니다."""
        # 반투명 오버레이
        overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
        overlay.set_alpha(200)
        overlay.fill(COLOR_BLACK)
        self.screen.blit(overlay, (0, 0))

        # 수련 패널
        center_x = SCREEN_WIDTH // 2
        center_y = SCREEN_HEIGHT // 2
        panel_width = 500
        panel_height = 400
        panel_x = center_x - panel_width // 2
        panel_y = center_y - panel_height // 2

        # 패널 배경
        pygame.draw.rect(
            self.screen, COLOR_BLACK, (panel_x, panel_y, panel_width, panel_height)
        )
        pygame.draw.rect(
            self.screen, COLOR_GOLD, (panel_x, panel_y, panel_width, panel_height), 3
        )

        # 제목
        self.draw_text(
            self.screen,
            "수련",
            FONT_LARGE,
            COLOR_GOLD,
            center_x,
            panel_y + 30,
            center=True,
        )

        y_offset = panel_y + 80

        # 업그레이드 버튼들
        upgrades = [
            {"name": "체력 증가", "stat": "hp", "cost": 20, "value": 10},
            {"name": "방어도 증가", "stat": "def", "cost": 15, "value": 5},
            {"name": "행동력 증가", "stat": "energy", "cost": 25, "value": 2},
        ]

        for i, upgrade in enumerate(upgrades):
            button_y = y_offset + i * 80
            button_width = 400
            button_height = 60
            button_rect = pygame.Rect(
                center_x - button_width // 2, button_y, button_width, button_height
            )

            # 구매 가능 여부 확인
            can_afford = self.xp >= upgrade["cost"]
            button_color = COLOR_DARK_GREEN if can_afford else COLOR_DARK_GRAY

            # 버튼 배경
            pygame.draw.rect(self.screen, button_color, button_rect)
            pygame.draw.rect(self.screen, COLOR_WHITE, button_rect, 2)

            # 버튼 텍스트
            stat_text = ""
            if upgrade["stat"] == "hp":
                stat_text = f"최대 HP +{upgrade['value']} (현재: {self.player.max_hp})"
            elif upgrade["stat"] == "def":
                stat_text = f"기본 방어도 +{upgrade['value']}"
            elif upgrade["stat"] == "energy":
                stat_text = (
                    f"최대 행동력 +{upgrade['value']} (현재: {self.player.max_energy})"
                )

            self.draw_text(
                self.screen,
                f"{upgrade['name']}: {stat_text}",
                FONT_SMALL,
                COLOR_WHITE,
                center_x,
                button_y + 15,
                center=True,
            )
            self.draw_text(
                self.screen,
                f"비용: {upgrade['cost']} XP",
                FONT_TINY,
                COLOR_WHITE,
                center_x,
                button_y + 35,
                center=True,
            )

            # 비활성화 표시
            if not can_afford:
                disabled_overlay = pygame.Surface((button_width, button_height))
                disabled_overlay.set_alpha(128)
                disabled_overlay.fill(COLOR_BLACK)
                self.screen.blit(
                    disabled_overlay, (center_x - button_width // 2, button_y)
                )

            # 버튼을 ui_buttons_next에 등록 (MODAL 레이어, 우선순위 3)
            def make_upgrade_handler(upgrade_stat, upgrade_cost, upgrade_value):
                def handler():
                    if self.xp >= upgrade_cost:
                        self.xp -= upgrade_cost
                        if upgrade_stat == "hp":
                            self.player.max_hp += upgrade_value
                            self.player.hp += upgrade_value
                            self.add_log(
                                f"[수련] 최대 HP가 {upgrade_value} 증가했다! (현재: {self.player.max_hp})",
                                "system",
                            )
                        elif upgrade_stat == "def":
                            self.add_log(
                                f"[수련] 방어도가 {upgrade_value} 증가했다!", "system"
                            )
                        elif upgrade_stat == "energy":
                            self.player.max_energy += upgrade_value
                            self.player.energy = self.player.max_energy
                            self.add_log(
                                f"[수련] 최대 행동력이 {upgrade_value} 증가했다! (현재: {self.player.max_energy})",
                                "system",
                            )

                return handler

            self.ui_buttons_next[f"training_upgrade_{i}"] = {
                "rect": button_rect,
                "layer": "modal",
                "enabled": can_afford,
                "on_click": make_upgrade_handler(
                    upgrade["stat"], upgrade["cost"], upgrade["value"]
                ),
                "priority": 3,
            }

        # 닫기 버튼 (CAMP로 돌아가기)
        close_button_x = center_x - 50
        close_button_y = panel_y + panel_height - 50
        close_button_width = 100
        close_button_height = 40
        close_button_rect = pygame.Rect(
            close_button_x, close_button_y, close_button_width, close_button_height
        )

        pygame.draw.rect(self.screen, COLOR_DARK_RED, close_button_rect)
        pygame.draw.rect(self.screen, COLOR_WHITE, close_button_rect, 2)

        self.draw_text(
            self.screen,
            "닫기",
            FONT_SMALL,
            COLOR_WHITE,
            center_x,
            close_button_y + close_button_height // 2,
            center=True,
        )

        # 버튼을 ui_buttons_next에 등록 (MODAL 레이어, 우선순위 3)
        def on_close_training():
            self.set_phase(PHASE_CAMP)
            self.training_menu_open = False
            self.log_event("UI", "수련 메뉴 닫기", "TRAINING -> CAMP", {})

        self.ui_buttons_next["training_close"] = {
            "rect": close_button_rect,
            "layer": "modal",
            "enabled": True,
            "on_click": on_close_training,
            "priority": 3,
        }

    def handle_training_menu_click(self, mouse_pos):
        """수련 메뉴 클릭 처리"""
        center_x = SCREEN_WIDTH // 2
        center_y = SCREEN_HEIGHT // 2
        panel_width = 500
        panel_height = 400
        panel_x = center_x - panel_width // 2
        panel_y = center_y - panel_height // 2

        y_offset = panel_y + 80

        # 업그레이드 버튼들
        upgrades = [
            {"name": "체력 증가", "stat": "hp", "cost": 20, "value": 10},
            {"name": "방어도 증가", "stat": "def", "cost": 15, "value": 5},
            {"name": "행동력 증가", "stat": "energy", "cost": 25, "value": 2},
        ]

        for i, upgrade in enumerate(upgrades):
            button_y = y_offset + i * 80
            button_width = 400
            button_height = 60

            button_rect = pygame.Rect(
                center_x - button_width // 2, button_y, button_width, button_height
            )
            if button_rect.collidepoint(mouse_pos):
                # 구매 가능 여부 확인
                if self.xp >= upgrade["cost"]:
                    # 구매 처리
                    self.xp -= upgrade["cost"]

                    if upgrade["stat"] == "hp":
                        self.player.max_hp += upgrade["value"]
                        self.player.hp += upgrade["value"]  # 현재 HP도 증가
                        self.add_log(
                            f"[수련] 최대 HP가 {upgrade['value']} 증가했다! (현재: {self.player.max_hp})",
                            "system",
                        )
                    elif upgrade["stat"] == "def":
                        # 기본 방어도는 Player 클래스에 저장되어야 함 (현재는 임시로 처리)
                        self.add_log(
                            f"[수련] 방어도가 {upgrade['value']} 증가했다!", "system"
                        )
                    elif upgrade["stat"] == "energy":
                        self.player.max_energy += upgrade["value"]
                        self.player.energy = (
                            self.player.max_energy
                        )  # 현재 에너지도 최대치로
                        self.add_log(
                            f"[수련] 최대 행동력이 {upgrade['value']} 증가했다! (현재: {self.player.max_energy})",
                            "system",
                        )

                    return True

        # 닫기 버튼 (CAMP로 돌아가기)
        close_button_x = center_x - 50
        close_button_y = panel_y + panel_height - 50
        close_button_width = 100
        close_button_height = 40

        close_button_rect = pygame.Rect(
            close_button_x, close_button_y, close_button_width, close_button_height
        )
        if close_button_rect.collidepoint(mouse_pos):
            self.set_phase(PHASE_CAMP)
            self.training_menu_open = False
            self.log_event("UI", "수련 메뉴 닫기", "TRAINING -> CAMP", {})
            return True

        return False

    def render_deck_screen(self):
        """덱 빌더 화면을 렌더링합니다."""
        # 배경
        self.screen.fill(COLOR_DARK_GRAY)

        center_x = SCREEN_WIDTH // 2

        # 제목
        self.draw_text(
            self.screen,
            "덱 정비",
            FONT_LARGE,
            COLOR_WHITE,
            center_x,
            30,
            center=True,
        )

        # 화면 분할: 좌측 Collection, 우측 Deck
        panel_width = SCREEN_WIDTH // 2 - 20
        panel_height = SCREEN_HEIGHT - 150
        panel_y = 80

        # 좌측: Collection 패널
        collection_x = 10
        collection_panel_rect = pygame.Rect(
            collection_x, panel_y, panel_width, panel_height
        )
        pygame.draw.rect(self.screen, COLOR_BLACK, collection_panel_rect)
        pygame.draw.rect(self.screen, COLOR_WHITE, collection_panel_rect, 2)

        self.draw_text(
            self.screen,
            f"보유 카드 ({len(self.player.collection)}장)",
            FONT_MEDIUM,
            COLOR_WHITE,
            collection_x + panel_width // 2,
            panel_y + 10,
            center=True,
        )

        # 우측: Deck 패널
        deck_x = SCREEN_WIDTH // 2 + 10
        deck_panel_rect = pygame.Rect(deck_x, panel_y, panel_width, panel_height)
        pygame.draw.rect(self.screen, COLOR_BLACK, deck_panel_rect)
        pygame.draw.rect(self.screen, COLOR_GOLD, deck_panel_rect, 2)

        self.draw_text(
            self.screen,
            f"전투 덱 ({len(self.player.deck)}/10장)",
            FONT_MEDIUM,
            COLOR_GOLD,
            deck_x + panel_width // 2,
            panel_y + 10,
            center=True,
        )

        # 카드 그리드 설정
        card_width = 100
        card_height = 140
        card_spacing = 10
        cards_per_row = 4
        start_y = panel_y + 50

        # 좌측: Collection 카드 렌더링
        collection_cards = {}
        for card_id in self.player.collection:
            collection_cards[card_id] = collection_cards.get(card_id, 0) + 1

        row = 0
        col = 0
        for card_id, count in sorted(collection_cards.items()):
            card_x = collection_x + 10 + col * (card_width + card_spacing)
            card_y = start_y + row * (card_height + card_spacing)

            if card_y + card_height > panel_y + panel_height - 10:
                break  # 화면을 벗어나면 중단

            card_rect = pygame.Rect(card_x, card_y, card_width, card_height)
            card = get_card_by_id(card_id)

            if card:
                # 카드 배경
                card_color = COLOR_DARK_GREEN
                if card.type == CardType.ATTACK:
                    card_color = COLOR_RED
                elif card.type == CardType.DEFENSE:
                    card_color = COLOR_BLUE
                elif card.type == CardType.DEBUFF:
                    card_color = COLOR_DARK_GRAY

                pygame.draw.rect(self.screen, card_color, card_rect)
                pygame.draw.rect(self.screen, COLOR_WHITE, card_rect, 2)

                # 카드 이름
                self.draw_text(
                    self.screen,
                    card.name,
                    FONT_TINY,
                    COLOR_WHITE,
                    card_x + card_width // 2,
                    card_y + 10,
                    center=True,
                )

                # 카드 개수 표시
                if count > 1:
                    count_text = f"x{count}"
                    self.draw_text(
                        self.screen,
                        count_text,
                        FONT_TINY,
                        COLOR_GOLD,
                        card_x + card_width - 15,
                        card_y + card_height - 20,
                    )

                # NEW 뱃지 (last_rewards에 포함된 경우)
                if card_id in self.player.last_rewards:
                    new_badge_rect = pygame.Rect(
                        card_x + 5, card_y + 5, 30, 15
                    )
                    pygame.draw.rect(self.screen, COLOR_RED, new_badge_rect)
                    pygame.draw.rect(self.screen, COLOR_WHITE, new_badge_rect, 1)
                    self.draw_text(
                        self.screen,
                        "NEW",
                        FONT_TINY,
                        COLOR_WHITE,
                        card_x + 20,
                        card_y + 12,
                        center=True,
                    )

                # 버튼 등록 (Collection -> Deck 이동)
                button_id = f"collection_card_{card_id}_{row}_{col}"
                self.ui_buttons_next[button_id] = {
                    "rect": card_rect,
                    "layer": "hud",
                    "enabled": len(self.player.deck) < 10,
                    "on_click": lambda cid=card_id: self.move_card_to_deck(cid),
                    "priority": 1,
                }

            col += 1
            if col >= cards_per_row:
                col = 0
                row += 1

        # 우측: Deck 카드 렌더링
        deck_cards = {}
        for card_id in self.player.deck:
            deck_cards[card_id] = deck_cards.get(card_id, 0) + 1

        row = 0
        col = 0
        for card_id, count in sorted(deck_cards.items()):
            card_x = deck_x + 10 + col * (card_width + card_spacing)
            card_y = start_y + row * (card_height + card_spacing)

            if card_y + card_height > panel_y + panel_height - 10:
                break  # 화면을 벗어나면 중단

            card_rect = pygame.Rect(card_x, card_y, card_width, card_height)
            card = get_card_by_id(card_id)

            if card:
                # 카드 배경
                card_color = COLOR_DARK_GREEN
                if card.type == CardType.ATTACK:
                    card_color = COLOR_RED
                elif card.type == CardType.DEFENSE:
                    card_color = COLOR_BLUE
                elif card.type == CardType.DEBUFF:
                    card_color = COLOR_DARK_GRAY

                pygame.draw.rect(self.screen, card_color, card_rect)
                pygame.draw.rect(self.screen, COLOR_GOLD, card_rect, 2)

                # 카드 이름
                self.draw_text(
                    self.screen,
                    card.name,
                    FONT_TINY,
                    COLOR_WHITE,
                    card_x + card_width // 2,
                    card_y + 10,
                    center=True,
                )

                # 카드 개수 표시
                if count > 1:
                    count_text = f"x{count}"
                    self.draw_text(
                        self.screen,
                        count_text,
                        FONT_TINY,
                        COLOR_GOLD,
                        card_x + card_width - 15,
                        card_y + card_height - 20,
                    )

                # 버튼 등록 (Deck -> Collection 반환)
                button_id = f"deck_card_{card_id}_{row}_{col}"
                self.ui_buttons_next[button_id] = {
                    "rect": card_rect,
                    "layer": "hud",
                    "enabled": True,
                    "on_click": lambda cid=card_id: self.move_card_to_collection(cid),
                    "priority": 1,
                }

            col += 1
            if col >= cards_per_row:
                col = 0
                row += 1

        # 하단: [여정 계속하기] 버튼
        continue_button_y = SCREEN_HEIGHT - 60
        continue_button_width = 200
        continue_button_height = 40
        continue_button_x = center_x - continue_button_width // 2
        continue_button_rect = pygame.Rect(
            continue_button_x, continue_button_y, continue_button_width, continue_button_height
        )

        pygame.draw.rect(self.screen, COLOR_DARK_GREEN, continue_button_rect)
        pygame.draw.rect(self.screen, COLOR_WHITE, continue_button_rect, 2)
        self.draw_text(
            self.screen,
            "여정 계속하기",
            FONT_MEDIUM,
            COLOR_WHITE,
            center_x,
            continue_button_y + continue_button_height // 2,
            center=True,
        )

        # 버튼 등록
        def on_continue_journey():
            self.player.last_rewards = []  # last_rewards 비우기
            self.start_next_encounter()  # 다음 인카운터로 이동

        self.ui_buttons_next["deck_continue"] = {
            "rect": continue_button_rect,
            "layer": "hud",
            "enabled": True,
            "on_click": on_continue_journey,
            "priority": 1,
        }

    def move_card_to_deck(self, card_id: str):
        """Collection에서 Deck으로 카드 이동"""
        if len(self.player.deck) >= 10:
            self.logger.log(
                "WARN",
                "DECK",
                f"덱이 꽉 참 (10/10), 카드 추가 불가: {card_id}",
                {"card_id": card_id},
            )
            return

        if card_id in self.player.collection:
            self.player.collection.remove(card_id)
            self.player.deck.append(card_id)
            self.logger.log(
                "INFO",
                "DECK",
                f"Card Moved: {card_id} (Collection -> Deck)",
                {"card_id": card_id, "deck_size": len(self.player.deck)},
            )
            self.log_event("DECK", f"카드 이동: {card_id}", "Collection -> Deck", {
                "card_id": card_id,
                "deck_size": len(self.player.deck),
            })

    def move_card_to_collection(self, card_id: str):
        """Deck에서 Collection으로 카드 반환"""
        if card_id in self.player.deck:
            self.player.deck.remove(card_id)
            self.player.collection.append(card_id)
            self.logger.log(
                "INFO",
                "DECK",
                f"Card Moved: {card_id} (Deck -> Collection)",
                {"card_id": card_id, "deck_size": len(self.player.deck)},
            )
            self.log_event("DECK", f"카드 이동: {card_id}", "Deck -> Collection", {
                "card_id": card_id,
                "deck_size": len(self.player.deck),
            })

    def render_defeat_screen(self):
        """패배 화면을 렌더링합니다."""
        # Phase 가드: DEFEAT_PANEL 상태가 아니면 그리지 않음
        if self.phase != PHASE_DEFEAT_PANEL:
            return

        # 반투명 오버레이
        overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
        overlay.set_alpha(200)
        overlay.fill(COLOR_BLACK)
        self.screen.blit(overlay, (0, 0))

        # 패배 메시지
        center_x = SCREEN_WIDTH // 2
        center_y = SCREEN_HEIGHT // 2

        self.draw_text(
            self.screen,
            "패배",
            FONT_LARGE,
            COLOR_RED,
            center_x,
            center_y - 100,
            center=True,
        )
        self.draw_text(
            self.screen,
            "여기서 멈추게 되었다.",
            FONT_MEDIUM,
            COLOR_WHITE,
            center_x,
            center_y - 50,
            center=True,
        )

        # 다시 시작 버튼
        button_x = center_x - 100
        button_y = center_y + 50
        button_width = 200
        button_height = 50
        retry_button_rect = pygame.Rect(button_x, button_y, button_width, button_height)

        pygame.draw.rect(self.screen, COLOR_DARK_RED, retry_button_rect)
        pygame.draw.rect(self.screen, COLOR_WHITE, retry_button_rect, 2)

        self.draw_text(
            self.screen,
            "다시 시작",
            FONT_MEDIUM,
            COLOR_WHITE,
            center_x,
            button_y + button_height // 2,
            center=True,
        )

        # 버튼을 ui_buttons_next에 등록 (MODAL 레이어, 우선순위 3)
        self.ui_buttons_next["defeat_retry"] = {
            "rect": retry_button_rect,
            "layer": "modal",
            "enabled": True,
            "on_click": self.reset_game,
            "priority": 3,
        }

    def handle_victory_click(self, mouse_x, mouse_y):
        """승리 화면 버튼 클릭 처리"""
        # Phase 가드: VICTORY 상태가 아니면 처리하지 않음
        if self.phase != PHASE_VICTORY_PANEL:
            return False

        center_x = SCREEN_WIDTH // 2
        center_y = SCREEN_HEIGHT // 2
        popup_width = 500
        popup_height = 250
        popup_x = center_x - popup_width // 2
        popup_y = center_y - popup_height // 2

        # 다음 적 버튼
        button_x = center_x - 100
        button_y = popup_y + 150
        button_width = 200
        button_height = 60

        if (
            button_x <= mouse_x <= button_x + button_width
            and button_y <= mouse_y <= button_y + button_height
        ):
            # 다음 인카운터 시작
            self.start_next_encounter()
            return True

        return False

    def handle_defeat_click(self, mouse_x, mouse_y):
        """패배 화면 버튼 클릭 처리"""
        center_x = SCREEN_WIDTH // 2
        center_y = SCREEN_HEIGHT // 2
        button_x = center_x - 100
        button_y = center_y + 50
        button_width = 200
        button_height = 50

        if (
            button_x <= mouse_x <= button_x + button_width
            and button_y <= mouse_y <= button_y + button_height
        ):
            # 게임 리셋
            self.reset_game()

    def reset_game(self):
        """게임을 초기 상태로 리셋합니다."""
        self.player = Player()
        self.turn = 0
        self.selected_card_index = None
        self.battle_log = []
        self.story_narration = []
        self.story_lines.clear()  # 스토리 라인 초기화
        self.log_lines.clear()  # 로그 라인 초기화
        self.enemy_level = 1  # 난이도도 리셋
        self.encounter_index = 0
        self.chapter = 1
        self.defeated_counts = {"Minion": 0, "Elite": 0, "Boss": 0}
        self.xp = 0
        self.gold = 0
        self.training_menu_open = False
        self.victory_message_shown = False  # 플래그 리셋
        self.defeat_message_shown = False  # 플래그 리셋
        self.battle_resolved = False  # 전투 해결 플래그 리셋

        # 덱 초기화
        self.initialize_deck()

        # 첫 번째 적 생성
        self.spawn_enemy()

        # 전투용 draw_pile 구성
        self.player.draw_pile = []
        self.player.hand = []
        self.player.discard_pile = []

        # player.deck을 Card 객체로 변환
        for card_id in self.player.deck:
            card = get_card_by_id(card_id)
            if card:
                self.player.draw_pile.append(card)
        random.shuffle(self.player.draw_pile)

        # 상태 초기화 (set_phase가 전투 진입 훅을 호출함)
        self.enter_state(GameState.BATTLE, "게임 리셋")
        self.set_phase(PHASE_PLAYER_TURN, "게임 리셋")

        # button_registry 초기화
        self.button_registry.clear()

    def build_battle_summary(self):
        """전투 요약을 생성합니다."""
        # 사용한 카드 카운트
        card_counts = {}
        for card_name in self.cards_used_in_battle:
            card_counts[card_name] = card_counts.get(card_name, 0) + 1

        # 결정타 찾기 (마지막으로 적에게 데미지를 준 카드)
        final_blow = None
        for log_entry in reversed(self.battle_log):
            if "[결과]" in log_entry and "데미지를 입혔다" in log_entry:
                # 카드 이름 추출
                for card_name in card_counts.keys():
                    if card_name in log_entry:
                        final_blow = card_name
                        break
                if final_blow:
                    break

        # 핵심 턴 (가장 큰 데미지를 준 턴)
        key_turn = None
        max_damage = 0
        for i, log_entry in enumerate(self.battle_log):
            if "[결과]" in log_entry and "데미지를 입혔다" in log_entry:
                # 데미지 추출
                try:
                    damage_str = log_entry.split("데미지를 입혔다")[0].split()[-1]
                    damage = int(damage_str)
                    if damage > max_damage:
                        max_damage = damage
                        key_turn = i // 3 + 1  # 대략적인 턴 계산
                except:
                    pass

        return {
            "turns": self.turn,
            "card_counts": card_counts,
            "final_blow": final_blow,
            "key_turn": key_turn,
            "max_damage": max_damage,
        }

    def roll_rewards(self, enemy_rank: str):
        """적 등급에 따라 보상을 생성합니다."""
        base_xp = {"Minion": 10, "Elite": 25, "Boss": 50}
        base_gold = {"Minion": 5, "Elite": 15, "Boss": 30}

        xp = base_xp.get(enemy_rank, 10) + random.randint(0, 5)
        gold = base_gold.get(enemy_rank, 5) + random.randint(0, 5)

        # 카드 보상 (Boss만 확률적으로, Elite는 낮은 확률)
        card_reward_id = None
        if enemy_rank == "Boss" and random.random() < 0.3:
            # 기존 카드 중 하나를 선택 (나중에 확장 가능)
            available_cards = list(CARD_REGISTRY.keys())
            if available_cards:
                card_reward_id = random.choice(available_cards)
        elif enemy_rank == "Elite" and random.random() < 0.1:
            available_cards = list(CARD_REGISTRY.keys())
            if available_cards:
                card_reward_id = random.choice(available_cards)

        return {"xp": xp, "gold": gold, "card_reward_id": card_reward_id}

    # ==================== 디버깅 시스템: UI 빌드 ====================
    def build_ui(self):
        """현재 상태에 맞는 UI 버튼 구성"""
        self.ui_layers = {"hud": [], "panel": [], "modal": []}
        self.victory_panel_rendered = False  # 프레임마다 리셋

        if self.phase == PHASE_PLAYER_TURN:
            # 턴 종료 버튼 (직접 set_phase 호출)
            button_rect = pygame.Rect(SCREEN_WIDTH - 150, SCREEN_HEIGHT - 50, 120, 40)
            enabled = not self.transition_lock  # transition_lock이 True면 비활성화
            # ui_buttons_next에 등록 (클릭 처리용)
            self.ui_buttons_next["turn_end"] = {
                "rect": button_rect,
                "layer": "hud",
                "enabled": enabled,
                "on_click": None,  # handle_events()에서 직접 처리
                "priority": 1,
            }
            # 하위 호환성: UI 레이어에도 추가
            self.ui_layers["hud"].append(
                {
                "label": "턴 종료",
                    "on_click": None,  # handle_events()에서 직접 처리
                    "enabled": enabled,
                "visible": True,
                "color": COLOR_DARK_GREEN,
                    "rect": button_rect,
                }
            )
        elif self.phase == PHASE_VICTORY_PANEL:
            # VICTORY 패널 내부 버튼들 (패널이 렌더링되면 추가)
            # 우하단 "다음 적" 버튼은 패널 내부에만 표시
            pass
        elif self.phase == PHASE_DEFEAT_PANEL:
            # 재시도 버튼
            button_rect = pygame.Rect(SCREEN_WIDTH - 150, SCREEN_HEIGHT - 50, 120, 40)
            self.ui_layers["hud"].append(
                {
                "label": "재시도",
                "on_click": self.reset_game,
                "enabled": True,
                "visible": True,
                "color": COLOR_DARK_RED,
                    "rect": button_rect,
                }
            )
        elif self.phase == PHASE_WORLD:
            # 전투 시작 버튼
            button_rect = pygame.Rect(SCREEN_WIDTH - 150, SCREEN_HEIGHT - 50, 120, 40)
            self.ui_layers["hud"].append(
                {
                "label": "전투 시작",
                "on_click": self.start_battle,
                "enabled": True,
                "visible": True,
                "color": COLOR_DARK_GREEN,
                    "rect": button_rect,
                }
            )

    def update(self):
        """매 프레임마다 게임 상태를 업데이트합니다."""
        try:
            # UI 재구성
            self.build_ui()

            # 불변조건 검증
            self.validate_invariants()

            # 불변조건 엄격 검증 (즉시 실패 로그, 자동복구)
            self.validate_invariants_strict()

            # Battle Ready Invariant 검증 및 자동 복구
            self.ensure_battle_ready()

            # 적 턴 로직: ENEMY_TURN 진입 후 1회만 실행 (원칙 3)
            if self.phase == PHASE_ENEMY_TURN:
                # enter_id 기반 중복 실행 방지
                if self._handled_enter_ids.get("enemy_turn_enter_id") == self.state_enter_id:
                    return
                # 처리 완료 표시
                self._handled_enter_ids["enemy_turn_enter_id"] = self.state_enter_id
                # 적 턴 실행
                self.run_enemy_turn_once()

            # Watchdog: TURN_END 클릭 후 200ms 이내에 phase 전환 안되면 ERROR (원칙 4)
            if self.last_turn_end_click_at is not None:
                elapsed = now_ms() - self.last_turn_end_click_at
                if elapsed > 200:
                    if self.phase == PHASE_PLAYER_TURN:
                        self.logger.log(
                            "ERROR",
                            "TURN_END_STUCK",
                            f"TURN_END 클릭 후 200ms 경과, phase가 여전히 PLAYER_TURN (현재: {self.phase})",
                            {
                                "elapsed_ms": elapsed,
                                "current_phase": self.phase,
                                "last_ui_click": self.last_ui_click,
                            },
                        )
                        self.dump_snapshot("turn_end_stuck")
                        # 강제로 set_phase(ENEMY_TURN)
                        self.set_phase(PHASE_ENEMY_TURN, "watchdog_force")
                    self.last_turn_end_click_at = None

            # 화면-입력 동기화 가드: update()도 phase만 보고 처리한다
            # 안전장치: VICTORY_PANEL/DEFEAT_PANEL/CAMP phase에서는 더 이상 로직 실행하지 않음
            # (단, ENEMY_TURN 처리는 위에서 이미 완료되었으므로 여기서는 승리/패배 체크만 수행)
            if self.phase in (PHASE_VICTORY_PANEL, PHASE_DEFEAT_PANEL, PHASE_CAMP, PHASE_TRAINING, PHASE_DECK):
                return

            # 화면-입력 동기화 가드: enemy.hp <= 0 같은 조건은 update()에서 phase를 바꾸는 트리거로만 사용
            # 전투 phase에서만 승리/패배 체크 (ENEMY_TURN 처리 후에도 체크)
            if self.phase in (PHASE_PLAYER_TURN, PHASE_ENEMY_TURN):
                # battle_resolved 플래그로 가드 (이미 처리된 경우)
                if self.battle_resolved:
                    return


                # 적이 죽었는지 체크 (1회성 전환 보장)
                # 주의: ENEMY_TURN 처리 중에 플레이어가 죽었을 수 있으므로 여기서도 체크
                    self.battle_resolved = True
                    self.on_victory()  # on_victory() 내부에서 set_phase(PHASE_VICTORY_PANEL) 호출
                    return

                # 플레이어가 죽었는지 체크 (1회성 전환 보장)
                # 주의: ENEMY_TURN 처리 중에 플레이어가 죽었을 수 있으므로 여기서도 체크
                if self.player.hp <= 0:
                    self.battle_resolved = True
                    self.on_defeat()  # on_defeat() 내부에서 set_phase(PHASE_DEFEAT_PANEL) 호출
                    return
        except Exception as e:
            # 예외 처리 강화
            error_trace = traceback.format_exc()
            self.log_event(
                "EXCEPTION",
                f"update() 중 예외 발생: {str(e)}",
                "",
                {"traceback": error_trace},
            )
            self.dump_snapshot("exception")
            # 화면에 에러 오버레이 표시는 render()에서 처리

    def render(self):
        """화면을 렌더링합니다."""
        try:
            # render() 시작에 button_registry 초기화 (보이지 않는 버튼 제거)
            self.button_registry.clear()
            self.ui_buttons_next = {}  # 더블버퍼도 초기화
            # 프레임 클릭 소비 플래그 초기화 (매 프레임마다 리셋)
            self.frame_click_consumed = False

            # 배경
            self.screen.fill(COLOR_DARK_GRAY)

            # UI 레이어별 렌더링 (hud -> panel -> modal -> debug_overlay)
            # 1. HUD 레이어 (항상 배경 게임 화면)
            # 화면-입력 동기화 가드: render()는 phase만 보고 그린다
            if self.phase == PHASE_CAMP:
                # CAMP 화면 (산길을 걷는다)
                self.render_world_screen()
            elif self.phase == PHASE_TRAINING:
                # TRAINING 화면 (수련 메뉴)
                self.render_world_screen()  # 배경은 동일
            elif self.phase in (PHASE_PLAYER_TURN, PHASE_ENEMY_TURN):
                # 전투 화면 (phase 기준으로만 결정)
                self.render_game_screen()
            elif self.phase in (PHASE_VICTORY_PANEL, PHASE_DEFEAT_PANEL):
                # 승리/패배 화면도 배경 게임 화면 표시
                self.render_game_screen()
            else:
                # 기타 phase는 기본 화면
                self.render_game_screen()

            # 2. Panel 레이어 (phase 기준으로만 렌더링)
            if self.phase == PHASE_VICTORY_PANEL:
                self.render_victory_panel()  # phase == PHASE_VICTORY_PANEL일 때만 렌더링
            elif self.phase == PHASE_DEFEAT_PANEL:
                self.render_defeat_screen()

            # 3. Modal 레이어 (수련 메뉴, 덱 빌더 등)
            if self.phase == PHASE_TRAINING:
                self.render_training_menu()
            elif self.phase == PHASE_DECK:
                self.render_deck_screen()

            # 4. Debug Overlay (가장 마지막)
            if self.debug_overlay_visible:
                self.render_debug_overlay()

            # UI 레지스트리 더블버퍼 스왑 (프레임 렌더 끝에서)
            # active = next; next = {}로 스왑 (절대 프레임 시작에 active를 clear하지 않음)
            self.ui_buttons_active = self.ui_buttons_next
            self.ui_buttons_next = {}
            self.button_registry = self.ui_buttons_active  # 하위 호환성 업데이트

            # 화면 업데이트
            pygame.display.flip()
        except Exception as e:
            # 예외 처리 강화
            error_trace = traceback.format_exc()
            self.log_event(
                "EXCEPTION",
                f"render() 중 예외 발생: {str(e)}",
                "",
                {"traceback": error_trace},
            )
            self.dump_snapshot("exception")
            self.render_error_overlay(str(e), error_trace)

    def render_game_screen(self):
        """일반 게임 화면을 렌더링합니다."""

        # 디버그 오버레이 (좌상단)
        enemy_rank = "None"
        if self.enemy:
            if isinstance(self.enemy, Boss):
                enemy_rank = "Boss"
            elif isinstance(self.enemy, Elite):
                enemy_rank = "Elite"
            elif isinstance(self.enemy, Minion):
                enemy_rank = "Minion"

        debug_text = f"PHASE={self.phase} chapter={self.chapter} encounter={self.encounter_index} enemy_rank={enemy_rank}"
        self.draw_text(self.screen, debug_text, FONT_TINY, COLOR_WHITE, 10, 10)

        debug_text2 = f"enemy_hp={self.enemy.hp if self.enemy else 0} player_energy={self.player.energy}"
        self.draw_text(self.screen, debug_text2, FONT_TINY, COLOR_WHITE, 10, 25)

        # 상단: 적 정보
        enemy_y = 20
        enemy_box_width = 200
        enemy_box_height = 150

        # 적 박스
        pygame.draw.rect(
            self.screen, COLOR_BLACK, (50, enemy_y, enemy_box_width, enemy_box_height)
        )
        pygame.draw.rect(
            self.screen,
            COLOR_WHITE,
            (50, enemy_y, enemy_box_width, enemy_box_height),
            2,
        )

        # 적 이름
        if self.enemy:
            self.draw_text(
                self.screen,
                self.enemy.name,
                FONT_MEDIUM,
                COLOR_WHITE,
                50 + enemy_box_width // 2,
                enemy_y + 20,
                center=True,
            )

            # 적 공격력과 방어도 표시
            atk_text = f"ATK: {self.enemy.attack_power}"
            def_text = f"DEF: 0"  # 적은 방어도가 없음
            self.draw_text(
                self.screen, atk_text, FONT_TINY, COLOR_RED, 50 + 10, enemy_y + 45
            )
            self.draw_text(
                self.screen, def_text, FONT_TINY, COLOR_BLUE, 50 + 100, enemy_y + 45
            )

            # 적 HP 바
            self.draw_health_bar(
                self.screen,
                50 + 10,
                enemy_y + 60,
                enemy_box_width - 20,
                20,
                self.enemy.hp,
                self.enemy.max_hp,
                COLOR_RED,
            )

            # 적 HP 텍스트
            hp_text = f"HP: {self.enemy.hp}/{self.enemy.max_hp}"
            self.draw_text(
                self.screen, hp_text, FONT_SMALL, COLOR_WHITE, 50 + 10, enemy_y + 90
            )

        # 중앙: 전투 영역
        center_x = SCREEN_WIDTH // 2
        center_y = SCREEN_HEIGHT // 2 - 50

        # 전투 연출 텍스트 (간단히)
        if self.phase == PHASE_ENEMY_TURN:
            self.draw_text(
                self.screen,
                "적의 턴...",
                FONT_LARGE,
                COLOR_RED,
                center_x,
                center_y,
                center=True,
            )

        # 하단: 플레이어 정보
        player_info_y = SCREEN_HEIGHT - 200

        # 플레이어 이름
        self.draw_text(
            self.screen, self.player.name, FONT_MEDIUM, COLOR_WHITE, 50, player_info_y
        )

        # 플레이어 공격력과 방어도 표시
        atk_text = f"ATK: {self.player.attack_power}"
        def_text = f"DEF: {self.player.defense}"
        self.draw_text(
            self.screen, atk_text, FONT_SMALL, COLOR_RED, 50, player_info_y + 30
        )
        self.draw_text(
            self.screen, def_text, FONT_SMALL, COLOR_BLUE, 50 + 100, player_info_y + 30
        )

        # 플레이어 스탯 (행동력)
        stats_y = player_info_y + 60
        energy_text = f"행동력: {self.player.energy}/{self.player.max_energy}"
        self.draw_text(self.screen, energy_text, FONT_SMALL, COLOR_WHITE, 50, stats_y)

        # 플레이어 체력 게이지 바 (왼쪽 하단, 카드 위)
        hp_bar_y = SCREEN_HEIGHT - 180  # 카드 위쪽
        hp_bar_x = 50
        hp_bar_width = 300
        hp_bar_height = 30

        # 체력 게이지 바 (붉은색)
        self.draw_health_bar(
            self.screen,
            hp_bar_x,
            hp_bar_y,
            hp_bar_width,
            hp_bar_height,
            self.player.hp,
            self.player.max_hp,
            COLOR_RED,
        )

        # 체력 텍스트 (게이지 바 위에)
        hp_text = f"체력: {self.player.hp}/{self.player.max_hp}"
        self.draw_text(
            self.screen, hp_text, FONT_SMALL, COLOR_WHITE, hp_bar_x, hp_bar_y - 25
        )

        # 최하단: 카드 손패
        card_width = 120
        card_height = 160
        card_spacing = 10
        cards_start_x = 50
        cards_y = SCREEN_HEIGHT - card_height - 10

        for i, card in enumerate(self.player.hand):
            card_x = cards_start_x + i * (card_width + card_spacing)
            is_selected = i == self.selected_card_index
            self.draw_card(
                self.screen, card, card_x, cards_y, card_width, card_height, is_selected
            )

        # 선택된 카드 상세 설명 패널
        if self.selected_card_index is not None and self.selected_card_index < len(
            self.player.hand
        ):
            selected_card = self.player.hand[self.selected_card_index]
            desc_panel_x = 400
            desc_panel_y = player_info_y
            desc_panel_width = 300
            desc_panel_height = 120

            # 설명 패널 배경
            pygame.draw.rect(
                self.screen,
                COLOR_BLACK,
                (desc_panel_x, desc_panel_y, desc_panel_width, desc_panel_height),
            )
            pygame.draw.rect(
                self.screen,
                COLOR_GOLD,
                (desc_panel_x, desc_panel_y, desc_panel_width, desc_panel_height),
                2,
            )

            # 카드 이름
            self.draw_text(
                self.screen,
                f"무공: {selected_card.name}",
                FONT_SMALL,
                COLOR_GOLD,
                desc_panel_x + 10,
                desc_panel_y + 5,
            )

            # 카드 타입
            type_text = f"타입: {selected_card.type.value}"
            self.draw_text(
                self.screen,
                type_text,
                FONT_TINY,
                COLOR_WHITE,
                desc_panel_x + 10,
                desc_panel_y + 30,
            )

            # 카드 설명
            desc_text = f"효과: {selected_card.description}"
            # 긴 설명은 여러 줄로 나누기
            words = desc_text.split()
            lines = []
            current_line = ""
            for word in words:
                if len(current_line + word) < 35:
                    current_line += word + " "
                else:
                    if current_line:
                        lines.append(current_line.strip())
                    current_line = word + " "
            if current_line:
                lines.append(current_line.strip())

            for i, line in enumerate(lines[:3]):  # 최대 3줄
                self.draw_text(
                    self.screen,
                    line,
                    FONT_TINY,
                    COLOR_WHITE,
                    desc_panel_x + 10,
                    desc_panel_y + 50 + i * 18,
                )

            # 비용 표시
            cost_text = f"행동력 비용: {selected_card.energy_cost}"
            self.draw_text(
                self.screen,
                cost_text,
                FONT_TINY,
                COLOR_WHITE,
                desc_panel_x + 10,
                desc_panel_y + desc_panel_height - 20,
            )

        # Primary Action 버튼 (항상 우하단에 표시)
        primary_action = self.get_primary_action()
        button_rect = primary_action["rect"]

        # 버튼 배경
        pygame.draw.rect(self.screen, primary_action["color"], button_rect)
        pygame.draw.rect(self.screen, COLOR_WHITE, button_rect, 2)

        # 버튼 텍스트
        self.draw_text(
            self.screen,
            primary_action["label"],
            FONT_SMALL,
            COLOR_WHITE,
            button_rect.centerx,
            button_rect.centery,
            center=True,
        )

        # 비활성화 상태 표시
        if not primary_action["enabled"]:
            overlay = pygame.Surface((button_rect.width, button_rect.height))
            overlay.set_alpha(128)
            overlay.fill(COLOR_BLACK)
            self.screen.blit(overlay, button_rect.topleft)

        # 버튼을 ui_buttons_next에 등록 (HUD 레이어, 우선순위 1)
        if primary_action.get("on_click"):
            self.ui_buttons_next["primary_action"] = {
                "rect": button_rect,
                "layer": "hud",
                "enabled": primary_action.get("enabled", False),
                "on_click": primary_action["on_click"],
                "priority": 1,
            }

        # 우측: 전투 로그 패널
        log_panel_x = SCREEN_WIDTH - 350
        log_panel_y = 20
        log_panel_width = 320
        log_panel_height = 400

        # 로그 패널 배경
        pygame.draw.rect(
            self.screen,
            COLOR_BLACK,
            (log_panel_x, log_panel_y, log_panel_width, log_panel_height),
        )
        pygame.draw.rect(
            self.screen,
            COLOR_WHITE,
            (log_panel_x, log_panel_y, log_panel_width, log_panel_height),
            2,
        )

        # 로그 제목
        self.draw_text(
            self.screen,
            "전투 로그",
            FONT_SMALL,
            COLOR_WHITE,
            log_panel_x + 10,
            log_panel_y + 5,
        )

        # 로그 내용 (최근 15개) - log_lines 사용
        log_start_y = log_panel_y + 30
        recent_logs = list(self.log_lines)[-15:]  # deque를 list로 변환
        for i, log_entry in enumerate(recent_logs):
            log_y = log_start_y + i * 22
            if log_y + 20 < log_panel_y + log_panel_height:
                # 로그 타입에 따라 색상 변경
                # 중요한 로그: 금색, 붉은색, 초록색
                # 덜 중요한 로그: 회색
                if "[error]" in log_entry.lower() or "[defeat]" in log_entry.lower():
                    log_color = COLOR_RED
                elif "[victory]" in log_entry.lower():
                    log_color = COLOR_GREEN
                elif "[player]" in log_entry.lower() or "[카드]" in log_entry:
                    log_color = COLOR_GOLD
                elif "[enemy]" in log_entry.lower():
                    log_color = COLOR_RED
                elif "[턴]" in log_entry or "[system]" in log_entry.lower():
                    # 턴 관련, 시스템 메시지는 회색
                    log_color = COLOR_GRAY
                elif "[story]" in log_entry.lower():
                    # 스토리 메시지는 금색
                    log_color = COLOR_GOLD
                else:
                    # 기본적으로 오래된 로그는 회색, 최근 로그는 흰색
                    # 최근 5개는 흰색, 그 이전은 회색
                    if i >= len(recent_logs) - 5:
                        log_color = COLOR_WHITE
                    else:
                        log_color = COLOR_GRAY

                # 긴 로그는 잘라서 표시
                display_text = (
                    log_entry[:40] + "..." if len(log_entry) > 40 else log_entry
                )
                self.draw_text(
                    self.screen,
                    display_text,
                    FONT_TINY,
                    log_color,
                    log_panel_x + 5,
                    log_y,
                )

        # 스토리 내레이션 (좌측 상단)
        # story_lines 렌더링 (draw 단계에서만, 추가는 하지 않음 - 절대 append 금지!)
        narration_y = 200
        for i, story_line in enumerate(self.story_lines):
            self.draw_text(
                self.screen,
                story_line,
                FONT_SMALL,
                COLOR_GOLD,
                50,
                narration_y + i * 30,
            )

    def handle_events(self):
        """이벤트를 처리합니다."""
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.running = False

            elif event.type == pygame.MOUSEBUTTONDOWN:
                # 클릭 처리: MOUSEBUTTONDOWN 이벤트만으로 처리 (원칙 1)
                if event.button == 1:  # 왼쪽 클릭
                    # frame_click_consumed 플래그로 한 프레임 1클릭만 처리
                    if self.frame_click_consumed:
                        continue

                    mouse_pos = event.pos
                    # 좌표계 변환 (SCALED/HiDPI 안전장치)
                    window_w, window_h = pygame.display.get_window_size()
                    screen_w, screen_h = SCREEN_WIDTH, SCREEN_HEIGHT
                    if window_w != screen_w or window_h != screen_h:
                        mx = mouse_pos[0] * screen_w / window_w
                        my = mouse_pos[1] * screen_h / window_h
                        mouse_pos = (mx, my)

                    # UI_MOUSEDOWN 로그 (항상 기록)
                    active_buttons_count = len(self.ui_buttons_active)
                    self.logger.log(
                        "INFO",
                        "UI_MOUSEDOWN",
                        f"마우스 다운 pos=({mouse_pos[0]:.1f},{mouse_pos[1]:.1f}) active_buttons={active_buttons_count}",
                        {
                            "pos": {"x": mouse_pos[0], "y": mouse_pos[1]},
                            "active_buttons": active_buttons_count,
                            "phase": self.phase,
                        },
                    )

                    # UI 클릭 라우팅: active 버튼에서 클릭된 버튼 찾기 (레이어 우선순위 고려)
                    clicked_button_id = None
                    clicked_layer = None
                    clicked_priority = -1
                    layer_priority_map = {
                        "modal": 3,
                        "panel": 2,
                        "hud": 1,
                    }  # 높을수록 우선

                    # 모든 버튼을 확인하고 우선순위가 가장 높은 것 선택
                    for button_id, btn_info in self.ui_buttons_active.items():
                        if not btn_info.get("enabled", True):
                            continue
                        rect = btn_info.get("rect")
                        if rect and rect.collidepoint(mouse_pos):
                            layer = btn_info.get("layer", "hud")
                            priority = btn_info.get(
                                "priority", layer_priority_map.get(layer, 0)
                            )
                            if priority > clicked_priority:
                                clicked_button_id = button_id
                                clicked_layer = layer
                                clicked_priority = priority
                    # 클릭 디바운스 체크 (150ms 내 연속 클릭 무시)
                    current_time = now_ms()
                    if clicked_button_id:
                        last_click_time = self.last_click_time.get(clicked_button_id, 0)
                        last_click_time = self.last_click_time.get(clicked_button_id, 0)
                        if current_time - last_click_time < self.click_cooldown_ms:
                            self.logger.log(
                                "INFO",
                                "UI_MISS",
                                f"클릭 디바운스: button_id={clicked_button_id} reason=cooldown",
                                {
                                    "button_id": clicked_button_id,
                                    "reason": "cooldown",
                                    "time_since_last": current_time - last_click_time,
                                },
                            )
                            continue
                        self.last_click_time[clicked_button_id] = current_time

                    # UI_HIT 또는 UI_MISS 로그
                    if clicked_button_id:
                        btn_info = self.ui_buttons_active[clicked_button_id]
                        self.last_ui_click = {
                            "button_id": clicked_button_id,
                            "timestamp_ms": current_time,
                            "phase": self.phase,
                            "layer": clicked_layer,
                            "pos": {"x": mouse_pos[0], "y": mouse_pos[1]},
                        }

                        # TURN_END 버튼 처리 규칙 (원칙 2)
                        if clicked_button_id == "turn_end" and self.phase == PHASE_PLAYER_TURN:
                            self.log_event(
                                "UI_CLICK",
                                "TURN_END 버튼 클릭",
                                "",
                                {
                                    "id": "TURN_END",
                                    "phase": self.phase,
                                    "enter_id": self.state_enter_id,
                                },
                            )
                            # 직접 set_phase(PHASE_ENEMY_TURN) 호출
                            self.last_turn_end_click_at = current_time
                            self.set_phase(PHASE_ENEMY_TURN, "turn_end_button")
                            self.frame_click_consumed = True
                            continue

                        self.logger.log(
                            "INFO",
                            "UI_HIT",
                            f"버튼 클릭 성공: {clicked_button_id}",
                            {
                                "button_id": clicked_button_id,
                                "layer": clicked_layer,
                                "enabled": btn_info.get("enabled", True),
                                "priority": clicked_priority,
                                "pos": {"x": mouse_pos[0], "y": mouse_pos[1]},
                            },
                        )

                        # VICTORY_PANEL 버튼 클릭 라우팅 (phase == PHASE_VICTORY_PANEL일 때만)
                        if self.phase == PHASE_VICTORY_PANEL:
                            if clicked_button_id == "victory_deck":
                                self.logger.log(
                                    "INFO",
                                    "UI_CLICK",
                                    "VICTORY_PANEL: 덱 정비 버튼 클릭",
                                    {"button_id": clicked_button_id, "phase": self.phase},
                                )
                            elif clicked_button_id == "victory_next":
                                self.logger.log(
                                    "INFO",
                                    "UI_CLICK",
                                    "VICTORY_PANEL: 다음 적 버튼 클릭",
                                    {"button_id": clicked_button_id, "phase": self.phase},
                                )

                        # 버튼 클릭 핸들러 실행
                        on_click = btn_info.get("on_click")
                        if on_click:
                            try:
                                prev_phase = self.phase
                                on_click()
                                # phase 전환 로그
                                if prev_phase != self.phase:
                                    self.logger.log(
                                        "INFO",
                                        "PHASE_TRANSITION",
                                        f"버튼 클릭으로 phase 전환: {prev_phase} -> {self.phase}",
                                        {
                                            "button_id": clicked_button_id,
                                            "prev_phase": prev_phase,
                                            "new_phase": self.phase,
                                        },
                                    )
                            except Exception as e:
                                self.logger.log(
                                    "ERROR",
                                    "UI_CLICK_ERROR",
                                    f"버튼 클릭 핸들러 실행 실패: {clicked_button_id}",
                                    {"error": str(e), "button_id": clicked_button_id, "phase": self.phase},
                                )
                        self.frame_click_consumed = True
                    else:
                        # 히트가 없으면 UI_MISS 로그 (강화된 디버깅)
                        self.logger.log(
                            "INFO",
                            "UI_MISS",
                            f"버튼 클릭 실패: reason=no_hit pos=({int(mouse_pos[0])},{int(mouse_pos[1])}) phase={self.phase} registry_buttons={len(self.ui_buttons_active)}",
                            {
                                "reason": "no_hit",
                                "pos": {"x": int(mouse_pos[0]), "y": int(mouse_pos[1])},
                                "phase": self.phase,
                                "registry_buttons_count": len(self.ui_buttons_active),
                                "active_button_ids": list(self.ui_buttons_active.keys()),
                            },
                        )

                        # TURN_END 버튼 처리 규칙 (원칙 2)
                        if clicked_button_id == "turn_end" and self.phase == PHASE_PLAYER_TURN:
                            self.log_event(
                                "UI_CLICK",
                                "TURN_END 버튼 클릭",
                                "",
                                {
                                    "id": "TURN_END",
                                    "phase": self.phase,
                                    "enter_id": self.state_enter_id,
                                },
                            )
                            continue
                            continue
                    # UI 클릭 라우팅: active 버튼에서 클릭된 버튼 찾기 (레이어 우선순위 고려)
                    clicked_button_id = None
                    clicked_layer = None
                    clicked_priority = -1
                    layer_priority_map = {
                        "modal": 3,
                        "panel": 2,
                        "hud": 1,
                    }  # 높을수록 우선

- The above suggested edit involves adding a new line of code.
- The new line will be added after `layer = btn_info.get("layer", "hud")`.
- The new line should draw a rectangle using Pygame.

Here is the updated code with the suggested edit applied:


                    # 모든 버튼을 확인하고 우선순위가 가장 높은 것 선택
                    for button_id, btn_info in self.ui_buttons_active.items():
                        if not btn_info.get(
                            "enabled", True
                        ):  # enabled=False인 버튼은 절대 클릭 처리하지 않음
                            continue
                                rect = btn_info.get("rect")
                                if rect and rect.collidepoint(mouse_pos):
                            layer = btn_info.get("layer", "hud")
        pygame.draw.rect(self.screen, COLOR_BLUE, deck_button_rect)
                            priority = btn_info.get(
                                "priority", layer_priority_map.get(layer, 0)
                            )
                            if priority > clicked_priority:
                                        clicked_button_id = button_id
                                clicked_layer = layer
                                clicked_priority = priority
                    # 클릭 디바운스 체크 (150ms 내 연속 클릭 무시)
                    current_time = now_ms()
                        if clicked_button_id:
                        last_click_time = self.last_click_time.get(clicked_button_id, 0)
                        if current_time - last_click_time < self.click_cooldown_ms:
                            self.logger.log(
                                "INFO",
                                "UI_MISS",
                                f"클릭 디바운스: button_id={clicked_button_id} reason=cooldown",
                                {
                                    "button_id": clicked_button_id,
                                    "reason": "cooldown",
                                    "time_since_last": current_time - last_click_time,
                                },
                            )
                            continue
                        self.last_click_time[clicked_button_id] = current_time

                    # UI_HIT 또는 UI_MISS 로그
                    if clicked_button_id:
                        btn_info = self.ui_buttons_active[clicked_button_id]
                        self.last_ui_click = {
                            "button_id": clicked_button_id,
                            "timestamp_ms": current_time,
                            "phase": self.phase,
                            "layer": clicked_layer,
                            "pos": {"x": mouse_pos[0], "y": mouse_pos[1]},
                        }
                        self.logger.log(
                            "INFO",
                            "UI_HIT",
                            f"버튼 클릭 성공: {clicked_button_id}",
                            {
                                "button_id": clicked_button_id,
                                "layer": clicked_layer,
                                "enabled": btn_info.get("enabled", True),
                                "priority": clicked_priority,
                                "pos": {"x": mouse_pos[0], "y": mouse_pos[1]},
                            },
                        )

                        # VICTORY_PANEL 버튼 클릭 라우팅 (phase == PHASE_VICTORY_PANEL일 때만)
                        if self.phase == PHASE_VICTORY_PANEL:
                            if clicked_button_id == "victory_deck":
                                self.logger.log(
                                    "INFO",
                                    "UI_CLICK",
                                    "VICTORY_PANEL: 덱 정비 버튼 클릭",
                                    {"button_id": clicked_button_id, "phase": self.phase},
                                )
                            elif clicked_button_id == "victory_next":
                                self.logger.log(
                                    "INFO",
                                    "UI_CLICK",
                                    "VICTORY_PANEL: 다음 적 버튼 클릭",
                                    {"button_id": clicked_button_id, "phase": self.phase},
                                )

                        # 버튼 클릭 핸들러 실행
                        on_click = btn_info.get("on_click")
                        if on_click:
                            try:
                                prev_phase = self.phase
                                on_click()
                                # phase 전환 로그
                                if prev_phase != self.phase:
                                    self.logger.log(
                                        "INFO",
                                        "PHASE_TRANSITION",
                                        f"버튼 클릭으로 phase 전환: {prev_phase} -> {self.phase}",
                                        {
                                            "button_id": clicked_button_id,
                                            "prev_phase": prev_phase,
                                            "new_phase": self.phase,
                                        },
                                    )
                            except Exception as e:
                                self.logger.log(
                                    "ERROR",
                                    "UI_CLICK_ERROR",
                                    f"버튼 클릭 핸들러 실행 실패: {clicked_button_id}",
                                    {"error": str(e), "button_id": clicked_button_id, "phase": self.phase},
                                )
                    else:
                        # 히트가 없으면 UI_MISS 로그 (강화된 디버깅)
                        self.logger.log(
                            "INFO",
                            "UI_MISS",
                            f"버튼 클릭 실패: reason=no_hit pos=({int(mouse_pos[0])},{int(mouse_pos[1])}) phase={self.phase} registry_buttons={len(self.ui_buttons_active)}",
                            {
                                "reason": "no_hit",
                                "pos": {"x": int(mouse_pos[0]), "y": int(mouse_pos[1])},
                                "phase": self.phase,
                                "registry_buttons_count": len(self.ui_buttons_active),
                                "active_button_ids": list(self.ui_buttons_active.keys()),
                            },
                        )

                    # 전투 phase에서 카드 클릭 처리 (버튼이 아닌 경우)
                    # 화면-입력 동기화 가드: handle_events()도 phase만 보고 처리한다
                    if (
                        not clicked_button_id
                        and self.phase == PHASE_PLAYER_TURN
                    ):
                        # Primary Action 버튼 클릭 확인
                        primary_action = self.get_primary_action()
                        if primary_action["rect"].collidepoint(mouse_pos):
                            if primary_action["enabled"] and primary_action["on_click"]:
                                primary_action["on_click"]()
                            continue

                        # 카드 클릭 확인
                        card_width = 120
                        card_height = 160
                        card_spacing = 10
                        cards_start_x = 50
                        cards_y = SCREEN_HEIGHT - card_height - 10

                        for i, card in enumerate(self.player.hand):
                            card_x = cards_start_x + i * (card_width + card_spacing)
                            card_rect = pygame.Rect(
                                card_x, cards_y, card_width, card_height
                            )
                            if card_rect.collidepoint(mouse_pos):
                                if i == self.selected_card_index:
                                    # 같은 카드 다시 클릭하면 사용
                                    self.use_selected_card()
                                else:
                                    # 카드 선택
                                    self.handle_card_click(i)
                                break

            elif event.type == pygame.KEYDOWN:
                # 디버그 단축키
                if event.key == pygame.K_F1:
                    self.dump_snapshot("manual")
                    self.logger.log(
                        "INFO", "SNAPSHOT", "F1 수동 스냅샷 저장", {"tag": "manual"}
                    )
                    continue
                elif event.key == pygame.K_F9:
                    # F9: 현재 상태 스냅샷 저장
                    self.dump_snapshot("f9_manual")
                    self.logger.log(
                        "INFO", "SNAPSHOT", "F9 수동 스냅샷 저장", {"tag": "f9_manual"}
                    )
                    continue
                elif event.key == pygame.K_F2:
                    self.debug_overlay_visible = not self.debug_overlay_visible
                    self.log_event(
                        "DEBUG",
                        f"디버그 오버레이 {'표시' if self.debug_overlay_visible else '숨김'}",
                    )
                    continue
                elif event.key == pygame.K_F3:
                    self.debug_ui_bounds_visible = not self.debug_ui_bounds_visible
                    self.log_event(
                        "DEBUG",
                        f"UI 영역 표시 {'켜짐' if self.debug_ui_bounds_visible else '꺼짐'}",
                    )
                    continue

                # Primary Action 키보드 단축키 (SPACE 또는 ENTER)
                primary_action = self.get_primary_action()
                if event.key == pygame.K_SPACE:
                    if primary_action["enabled"] and primary_action["on_click"]:
                        primary_action["on_click"]()
                        continue
                elif event.key == pygame.K_RETURN:
                    # ENTER는 Primary Action 또는 카드 사용
                    if primary_action["enabled"] and primary_action["on_click"]:
                        primary_action["on_click"]()
                        continue
                    # Primary Action이 없으면 카드 사용 (PLAYER_TURN일 때만)
                    elif (
                        self.selected_card_index is not None
                        and self.phase == PHASE_PLAYER_TURN
                    ):
                        self.use_selected_card()

    def run(self):
        """메인 게임 루프 (Error Boundary 강화)"""
        try:
            while self.running:
                try:
                    self.handle_events()
                    self.update()  # 게임 상태 업데이트
                    self.render()
                    self.clock.tick(FPS)
                except Exception as frame_error:
                    # 프레임 단위 에러 처리
                    self.handle_error(frame_error, "frame_error")

        except Exception as e:
            # 치명적 에러 처리
            self.handle_error(e, "fatal_error")

        finally:
            pygame.quit()
            sys.exit()

    def handle_error(self, error: Exception, error_type: str):
        """에러 처리 (스냅샷 + 로그 + 화면 표시)"""
        error_trace = traceback.format_exc()

        # 에러 로그 기록
        self.logger.log(
            "ERROR",
            error_type,
            str(error),
            {
            "phase": self.phase,
            "state": str(self.state),
            "chapter": self.chapter,
            "encounter_index": self.encounter_index,
            "turn": self.turn,
                "traceback": error_trace,
            },
        )

        # 스냅샷 저장
        try:
            self.dump_snapshot(f"error_{error_type}")
        except:
            pass

        # 에러 파일 저장 (스냅샷 + 최근 로그 200줄)
        error_file = os.path.join(
            "logs", f"error_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
        )
        try:
            with open(error_file, "w", encoding="utf-8") as f:
                f.write(f"=== ERROR REPORT ===\n")
                f.write(f"Type: {error_type}\n")
                f.write(f"Time: {datetime.now().isoformat()}\n")
                f.write(f"Phase: {self.phase}\n")
                f.write(f"State: {self.state}\n")
                f.write(f"Chapter: {self.chapter}, Encounter: {self.encounter_index}\n")
                f.write(f"Turn: {self.turn}\n")
                f.write(f"\n=== STACKTRACE ===\n{error_trace}\n")
                f.write(f"\n=== SNAPSHOT ===\n")
                try:
                    snapshot = self.snapshot_state()
                    f.write(json.dumps(snapshot, ensure_ascii=False, indent=2))
                except Exception as snapshot_error:
                    f.write(f"스냅샷 생성 실패: {str(snapshot_error)}\n")
                    f.write(f"에러 타입: {type(snapshot_error).__name__}\n")
                f.write(f"\n\n=== RECENT LOGS (200 lines) ===\n")
                recent_logs = self.logger.get_recent_logs(200)
                for log_entry in recent_logs:
                    f.write(json.dumps(log_entry, ensure_ascii=False) + "\n")
        except Exception as save_error:
            print(f"[ERROR] 에러 파일 저장 실패: {save_error}", file=sys.stderr)

        # 에러 화면 표시
        try:
            error_surface = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
            error_surface.fill(COLOR_RED)
            error_text = f"오류 발생: {str(error)}"
            self.draw_text(
                error_surface,
                error_text,
                FONT_LARGE,
                COLOR_WHITE,
                SCREEN_WIDTH // 2,
                SCREEN_HEIGHT // 2 - 50,
                center=True,
            )
            self.draw_text(
                error_surface,
                f"에러 파일: {error_file}",
                FONT_SMALL,
                COLOR_WHITE,
                SCREEN_WIDTH // 2,
                SCREEN_HEIGHT // 2,
                center=True,
            )
            self.draw_text(
                error_surface,
                "5초 후 종료됩니다...",
                FONT_SMALL,
                COLOR_WHITE,
                SCREEN_WIDTH // 2,
                SCREEN_HEIGHT // 2 + 50,
                center=True,
            )
            self.screen.blit(error_surface, (0, 0))
            pygame.display.flip()
            pygame.time.wait(5000)
        except:
            pass


# 메인 함수
def main():
    """게임 시작"""
    # 커맨드 라인 인자 파싱 (seed 고정 옵션)
    parser = argparse.ArgumentParser(
        description="구운록 (Guunrok) - 무협 카드 배틀 게임"
    )
    parser.add_argument(
        "--seed", type=int, default=None, help="랜덤 시드 고정 (재현용)"
    )
    args = parser.parse_args()

    # 시드 설정
    if args.seed is not None:
        random.seed(args.seed)
        print(f"랜덤 시드 고정: {args.seed}")

    print("구운록 (Guunrok) 게임을 시작합니다...")
    print("조작법:")
    print("  - 마우스 클릭: 카드 선택/사용")
    print("  - 스페이스바: 턴 종료")
    print("  - 엔터: 선택된 카드 사용")
    print("  - F9: 현재 상태 스냅샷 저장")
    print("  - F2: 디버그 오버레이 토글")
    print("  - F3: UI 클릭 영역 표시")
    print("  - ESC 또는 창 닫기: 게임 종료")
    print()

    game = Game()
    game.run()


if __name__ == "__main__":
    main()
