import random
from typing import Tuple, List


class Enemy:
    """녹림 도적단의 기본 클래스"""

    def __init__(self, name: str, max_hp: int, attack_power: int):
        self.name = name
        self.max_hp = max_hp
        self.hp = max_hp
        self.attack_power = attack_power
        self.attack_debuff = 0
        self.description = ""
        self.encounter_story = ""

        # [!] 여기 아래 2줄을 꼭 추가해주세요!
        self.xp_reward = 10  # 기본 경험치
        self.gold_reward = 10  # 기본 돈
        # LORE_NOKRIM 설정 반영: 적들의 행동 패턴
        self.idle_behaviors = [
            "막걸리를 마시고 딸꾹질을 한다.",
            "수레를 털다가 당신의 짐보따리를 곁눈질한다.",
            "칼에 묻은 피를 닦으며 비릿하게 웃는다.",
            "신발이 비싸 보이는군. 내놔!",
        ]

    def get_random_idle(self) -> str:
        return random.choice(self.idle_behaviors)

    def is_alive(self) -> bool:
        return self.hp > 0

    def take_damage(self, damage: int) -> int:
        self.hp = max(0, self.hp - damage)
        return damage

    def attack(self, player) -> Tuple[int, str]:
        """기존의 맛깔나는 대사 시스템 유지"""
        damage = max(1, self.attack_power - self.attack_debuff)
        actual_damage = player.take_damage(damage)
        self.attack_debuff = max(0, self.attack_debuff - 1)

        hp_ratio = player.hp / player.max_hp if player.max_hp > 0 else 0
        weapon = random.choice(["도끼", "철퇴", "대도"])

        if hp_ratio > 0.7:
            msg = f"{self.name}이(가) {weapon}를 휘둘렀다. 가소로운 공격이다. ({actual_damage} 피해)"
        elif hp_ratio > 0.3:
            msg = f"{self.name}의 {weapon} 공격이 명중했다! ({actual_damage} 피해)"
        else:
            msg = f"{self.name}이(가) {weapon}로 강타했다! 피가 시야를 가린다. ({actual_damage} 피해)"

        return actual_damage, msg


# 1. 녹림 졸개 (Minion)
class NokrimMinion(Enemy):
    def __init__(self):
        super().__init__("녹림 졸개", 30, 5)
        self.description = "녹림의 일반 도적."
        self.encounter_story = "졸개들이 길을 막고 외칩니다. '통행세는 팔 하나다!'"


# 2. 녹림 장로 (Elite) - 특수 기술 사용
class NokrimElder(Enemy):
    def __init__(self):
        super().__init__("녹림 장로", 65, 12)
        self.description = "잔혹한 무공을 구사하는 장로."
        self.special_cooldown = 0
        # [!] 장로는 강하니까 보상을 더 줍니다
        self.xp_reward = 30
        self.gold_reward = 50

    def take_turn(self, player) -> Tuple[int, str]:
        """LORE_NOKRIM: 조법과 독공 사용"""
        if self.special_cooldown <= 0:
            self.special_cooldown = 2
            roll = random.random()
            if roll < 0.5:  # 조법: 방어 무시
                dmg = self.attack_power
                player.hp -= dmg
                return (
                    dmg,
                    f"{self.name}의 조법! 방어를 무시하고 살점을 뜯어 {dmg} 피해를 입혔다!",
                )
            else:  # 독공: 방어력 감소
                player.defense = max(0, player.defense - 5)
                dmg, _ = self.attack(player)
                return dmg, f"{self.name}의 독공! 방어력을 깎고 {dmg} 피해를 입혔다!"

        self.special_cooldown -= 1
        return self.attack(player)


# 3. 녹림왕 마천광 (Boss)
class MaCheonGwang(Enemy):
    def __init__(self):
        super().__init__("마천광", 130, 18)
        self.description = "녹림 도적단의 최종 보스."
        self.special_cooldown = 0
        self.xp_reward = 100
        self.gold_reward = 300

    def take_turn(self, player) -> Tuple[int, str]:
        """보스 전용 패턴: 사슬낫과 강력한 일격"""
        if self.special_cooldown <= 0:
            self.special_cooldown = 3
            # 사슬낫: 기절(에너지 감소) 효과
            player.energy = max(0, player.energy - 2)
            dmg = self.attack_power + 5
            player.take_damage(dmg)
            return (
                dmg,
                f"마천광의 사슬낫! 당신을 휘감아 내공을 흩트리고 {dmg} 피해를 입혔다!",
            )

        self.special_cooldown -= 1
        return self.attack(player)


class NokrimBandit(Enemy):
    def __init__(self):
        super().__init__("녹림 도적", 30, 5)
        self.description = "산속에서 출몰하는 흔한 도적입니다."

        # [!] 여기에 추가
        self.xp_reward = 15
        self.gold_reward = 20
