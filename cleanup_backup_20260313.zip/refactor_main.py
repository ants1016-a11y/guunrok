#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
main.py 리팩토링 스크립트
"""

import re

# main.py 읽기
with open('main.py', 'r', encoding='utf-8') as f:
    content = f.read()

# Game 클래스 시작과 끝 찾기
game_start = content.find('class Game:')
if game_start == -1:
    print('Game class not found')
    exit(1)

# main 함수 시작 찾기
main_start = content.find('\n# 메인 함수\n')
if main_start == -1:
    main_start = content.find('\ndef main():')

# Game 클래스 부분 추출
game_class = content[game_start:main_start]

# draw_text, draw_health_bar, draw_card 메서드 제거
# 메서드 정의 패턴 찾기 (들여쓰기 4칸)
pattern = r'    def (draw_text|draw_health_bar|draw_card)\([^)]*\):.*?(?=\n    def |\nclass |\Z)'
game_class = re.sub(pattern, '', game_class, flags=re.DOTALL)

# self.draw_text -> draw_text, self.draw_health_bar -> draw_health_bar, self.draw_card -> draw_card
game_class = re.sub(r'self\.draw_text\(', 'draw_text(', game_class)
game_class = re.sub(r'self\.draw_health_bar\(', 'draw_health_bar(', game_class)
# draw_card는 player_energy 파라미터 추가 필요
game_class = re.sub(r'draw_card\(([^,]+),([^,]+),([^,]+),([^,]+),([^,]+),([^,]+),selected=([^)]+)\)', r'draw_card(\1,\2,\3,\4,\5,\6,selected=\7,player_energy=self.player.energy)', game_class)
game_class = re.sub(r'draw_card\(([^,]+),([^,]+),([^,]+),([^,]+),([^,]+),([^)]+)\)', r'draw_card(\1,\2,\3,\4,\5,\6,player_energy=self.player.energy)', game_class)

# main 함수 부분 추출
main_func = content[main_start:]

# 새로운 main.py 생성
new_content = '''#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
구운록 (Guunrok) - 무협 카드 배틀 게임
=====================================

실행 방법:
1. Pygame 설치: pip install pygame
2. 실행: ./dev/run.sh (권장)
   - 이 스크립트는 실행 전 자동으로 코드 포맷팅 및 문법 검사를 수행합니다.
   - 직접 python main.py로 실행하지 마세요.

게임 설명:
- 회귀한 둔재가 되어 녹림 도적들과 전투를 벌이는 턴제 카드 배틀 게임
- 카드를 선택하여 사용하고, 턴 종료 버튼으로 턴을 넘깁니다
- 적을 모두 물리치면 승리합니다
"""

import pygame
import sys
import random
import os
import math
import json
import traceback
import time
import argparse
from datetime import datetime
from collections import deque
from typing import List, Optional, Tuple, Dict, Any

# Import from separated modules
from settings import *
from ui import draw_text, draw_health_bar, draw_card
from cards import (
    Card,
    CardType,
    CARD_REGISTRY,
    register_card,
    get_card_by_id,
    effect_samjae_gong,
    effect_yukhap_gwon,
    effect_bokho_jang,
    effect_pocheon_sam,
    effect_yuun_ji,
)
from player import Player
from enemies import Enemy, Minion, Elite, Boss
from managers import StoryManager, StoryLog, DebugLogger

''' + game_class + main_func

# 백업
with open('main.py.bak', 'w', encoding='utf-8') as f:
    f.write(content)

# 새 파일 작성
with open('main.py', 'w', encoding='utf-8') as f:
    f.write(new_content)

print('main.py 리팩토링 완료')
